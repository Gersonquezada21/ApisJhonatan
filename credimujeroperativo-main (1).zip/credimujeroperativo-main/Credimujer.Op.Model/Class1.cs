﻿using System;

namespace Credimujer.Op.Model
{
    public class Class1
    {
    }
}
