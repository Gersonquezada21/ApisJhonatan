﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Op.Model.Socia
{
    public class CatalogoModel
    {
        public bool ObtenerEstadoCivil { get; set; }
        public bool ObtenerGradoInstruccion { get; set; }
        public bool ObtenerSituacionDomicilio { get; set; }
        public bool ObtenerAfirmacion { get; set; }
        public bool ObtenerEntidadFinanciera { get; set; }
        public bool ObtenerDepartamento { get; set; }
        public bool ObtenerSucursal { get; set; }
    }
}
