﻿namespace Credimujer.Op.Model.Base
{
    public class PaginationModel
    {
        public int Page { get; set; }
        public int PageSize { get; set; }
    }
}
