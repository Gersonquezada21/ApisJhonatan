﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Op.Common
{
    public class AuthenticateScheme
    {
        public const string Security = "CrediMujerSeguridad";
        public const string PersonalOperativo = "PersonalOperativo";
    }
}
