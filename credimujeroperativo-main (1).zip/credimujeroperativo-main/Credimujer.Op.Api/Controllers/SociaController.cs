﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using Credimujer.Op.Application.Implementations.Socia;
using Credimujer.Op.Application.Interfaces;
using Credimujer.Op.Common;
using Credimujer.Op.Common.Base;
using Credimujer.Op.Common.Exceptions;
using Credimujer.Op.Dto.Base;
using Credimujer.Op.Dto.Socia.Busqueda;
using Credimujer.Op.Dto.Socia.Registro;
using Credimujer.Op.Model.Service.Iam;
using Credimujer.Op.Model.Socia;
using Credimujer.Op.Model.Socia.Busqueda;
using Credimujer.Op.Model.Socia.Registrar;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Credimujer.Op.Api.Controllers
{
    [Authorize(AuthenticationSchemes = AuthenticateScheme.PersonalOperativo)]
    [Route("Socia")]
    [ApiController]
    public class SociaController
    {
        private readonly Lazy<ISociaApplication> _sociaApplication;
        private readonly Lazy<ICommonApplication> _commonApplication;

        public SociaController(ILifetimeScope lifetimeScope)
        {
            _sociaApplication = new Lazy<ISociaApplication>(() => lifetimeScope.Resolve<ISociaApplication>());
            _commonApplication = new Lazy<ICommonApplication>(() => lifetimeScope.Resolve<ICommonApplication>());
        }

        private ISociaApplication SociaApplication => _sociaApplication.Value;
        private ICommonApplication CommonApplication => _commonApplication.Value;

        [HttpGet("catalogo")]
        public async Task<JsonResult> Catalogo([FromQuery] CatalogoModel model)
        {
            ResponseDto response;
            try
            {
                response = await SociaApplication.Catalogo(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDto { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDto { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDto { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpPost("RegistrarSocia")]
        public async Task<JsonResult> RegistrarSocia([FromBody] NuevaSociaModel model)
        {
            ResponseDto response;
            try
            {
                response = await SociaApplication.RegistrarSocia(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDto { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDto { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDto { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpPost("AprobarAccesoSocia")]
        public async Task<JsonResult> AprobarAccesoSocia([FromBody] RegistrarUsuarioModel model)
        {
            ResponseDto response;
            try
            {
                response = await SociaApplication.AprobarAccesoSocia(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDto { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDto { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDto { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpPost("BusquedaSocia")]
        public async Task<JsonResult> BusquedaSocia([FromBody] FiltroSociaParaAprobarModel model)
        {
            ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>> response;
            try
            {
                response = await SociaApplication.BusquedaSocia(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>> { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
                //Logger.Warning(ex.TransactionId, ex.Message, ex);
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>> { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
                //Logger.Error(ex.TransactionId, ex.Message, ex);
            }
            catch (Exception ex)
            {
                response = new ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>> { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.Message };
                //Logger.Error(response.TransactionId, ex.Message, ex);
            }

            return new JsonResult(response);
        }

        [HttpGet("ObtenerSociaPorId/{sociaId}")]
        public async Task<JsonResult> ObtenerSociaPorId(int sociaId)
        {
            ResponseDto response;
            try
            {
                response = await SociaApplication.ObtenerSociaPorId(sociaId);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDto { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDto { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDto { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpPost("ActualizarDatoPersonal")]
        public async Task<JsonResult> ActualizarDatoPersonal([FromBody] ActualizarDatoPersonalDto model)
        {
            ResponseDto response;
            try
            {
                response = await SociaApplication.ActualizarDatoPersonal(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDto { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDto { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDto { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpGet("ObtenerProvincia/{codigoDepartamento}")]
        public async Task<JsonResult> ObtenerProvincia(string codigoDepartamento)
        {
            ResponseDto response;
            try
            {
                response = await CommonApplication.ObtenerProvincia(codigoDepartamento);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDto { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDto { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDto { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpGet("ObtenerDistrito/{codigoDepartamento}/{codigoProv}")]
        public async Task<JsonResult> ObtenerDistrito(string codigoDepartamento, string codigoProv)
        {
            ResponseDto response;
            try
            {
                response = await CommonApplication.ObtenerDistrito(codigoDepartamento, codigoProv);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDto { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDto { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDto { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }
        [HttpGet("BusquedaBancoComunal/{descripcion}")]
        public async Task<JsonResult> BusquedaBancoComunal(string descripcion)
        {
            ResponseDto response;
            try
            {
                response = await SociaApplication.BusquedaBancoComunal(descripcion);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDto { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDto { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDto { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }
    }
}