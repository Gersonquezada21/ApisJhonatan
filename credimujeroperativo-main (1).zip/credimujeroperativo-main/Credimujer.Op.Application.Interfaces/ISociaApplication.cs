﻿using Credimujer.Op.Common.Base;
using Credimujer.Op.Dto.Base;
using Credimujer.Op.Dto.Socia.Busqueda;
using Credimujer.Op.Model.Socia.Busqueda;
using System.Threading.Tasks;
using Credimujer.Op.Dto.Socia.Registro;
using Credimujer.Op.Model.Socia;
using Credimujer.Op.Model.Socia.Registrar;
using Credimujer.Op.Model.Service.Iam;

namespace Credimujer.Op.Application.Interfaces
{
    public interface ISociaApplication
    {
        Task<ResponseDto> Catalogo(CatalogoModel model);

        Task<ResponseDto> RegistrarSocia(NuevaSociaModel model);

        Task<ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>>> BusquedaSocia(
            FiltroSociaParaAprobarModel model);

        Task<ResponseDto> ObtenerSociaPorId(int sociaId);

        Task<ResponseDto> ActualizarDatoPersonal(ActualizarDatoPersonalDto model);

        Task<ResponseDto> AprobarAccesoSocia(RegistrarUsuarioModel model);
        Task<ResponseDto> BusquedaBancoComunal(string descripcion);
    }
}