﻿namespace Credimujer.Op.Domail.Models.Entities
{
    public class DepartamentoEntity
    {
        public string Codigo { get; set; }
        public string Descripcion { get; set; }

    }
}
