﻿using Credimujer.Op.Domail.Models.Base;
using System.Collections.Generic;

namespace Credimujer.Op.Domail.Models.Entities
{
    public class CatalogoDetalleEntity : BaseEntity
    {
        public CatalogoDetalleEntity()
        {
            SociaEstado = new List<SociaEntity>();
            SociaEstadoCivil = new List<FormularioEntity>();
            SociaGradoInstruccion = new List<FormularioEntity>();
            SociaSituacionDomicilio = new List<FormularioEntity>();
            SociaEntidadBancaria = new List<FormularioEntity>();
            PreSolicitudEstado = new List<PreSolicitudEntity>();
            PreSolicitudEntidadBancaria = new List<PreSolicitudEntity>();
            PreSolicitudTipoCredito = new List<PreSolicitudEntity>();
            SociaSucursal = new List<SociaEntity>();
            BancoComunalSucursal = new List<BancoComunalEntity>();
        }

        public int Id { get; set; }
        public int CatalogoId { get; set; }
        public string Codigo { get; set; }
        public string Valor { get; set; }
        public string Descripcion { get; set; }
        public int Orden { get; set; }

        public virtual CatalogoEntity Catalogo { get; set; }
        public virtual ICollection<SociaEntity> SociaEstado { get; set; }
        public virtual ICollection<SociaEntity> SociaSucursal { get; set; }
        public virtual ICollection<FormularioEntity> SociaEstadoCivil { get; set; }
        public virtual ICollection<FormularioEntity> SociaGradoInstruccion { get; set; }
        public virtual ICollection<FormularioEntity> SociaSituacionDomicilio { get; set; }
        public virtual ICollection<FormularioEntity> SociaEntidadBancaria { get; set; }
        public virtual ICollection<PreSolicitudEntity> PreSolicitudEstado { get; set; }
        public virtual ICollection<PreSolicitudEntity> PreSolicitudEntidadBancaria { get; set; }
        public virtual ICollection<PreSolicitudEntity> PreSolicitudTipoCredito { get; set; }
        public virtual ICollection<BancoComunalEntity> BancoComunalSucursal { get; set; }
    }
}
