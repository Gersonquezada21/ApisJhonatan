﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Op.Domail.Models.Base;

namespace Credimujer.Op.Domail.Models.Entities
{
    public class AnilloGrupalEntity : BaseEntity
    {
        public AnilloGrupalEntity()
        {
            Formulario = new List<FormularioEntity>();
        }

        public int Id { get; set; }
        public string Codigo { get; set; }
        public string BancoComunalCodigo { get; set; }
        public string Descripcion { get; set; }
        public virtual BancoComunalEntity BancoComunal { get; set; }
        public virtual ICollection<FormularioEntity> Formulario { get; set; }
    }
}
