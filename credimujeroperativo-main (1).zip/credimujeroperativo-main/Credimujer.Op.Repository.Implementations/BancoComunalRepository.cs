﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Op.Domail.Models.Entities;
using Credimujer.Op.Dto.Base;
using Credimujer.Op.Repository.Implementations.Data;
using Credimujer.Op.Repository.Implementations.Data.Base;
using Credimujer.Op.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Op.Repository.Implementations
{
    public class BancoComunalRepository : BaseRepository<BancoComunalEntity>, IBancoComunalRepository
    {
        private readonly DataContext _context;

        public BancoComunalRepository(DataContext context) : base(context)
        {
            this._context = context;
        }

        public async Task<List<DropdownDto>> BusquedaPorDescripcion(string descripcion)
        {
            return await _context.BancoComunal.Where(p => p.EstadoFila && p.Descripcion.Contains(descripcion))
                .Select(s => new DropdownDto()
                {
                    Code = s.Codigo,
                    Description = s.Descripcion
                })
                .Take(30).ToListAsync();
        }
    }
}
