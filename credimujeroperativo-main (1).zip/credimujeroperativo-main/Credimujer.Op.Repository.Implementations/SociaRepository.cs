﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Op.Common.Base;
using Credimujer.Op.Domail.Models.Entities;
using Credimujer.Op.Dto.Base;
using Credimujer.Op.Dto.Socia.Busqueda;
using Credimujer.Op.Dto.Socia.Registro;
using Credimujer.Op.Model.Socia.Busqueda;
using Credimujer.Op.Repository.Implementations.Data;
using Credimujer.Op.Repository.Implementations.Data.Base;
using Credimujer.Op.Repository.Implementations.Extensions;
using Credimujer.Op.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Op.Repository.Implementations
{
    public class SociaRepository : BaseRepository<SociaEntity>, ISociaRepository
    {
        private readonly DataContext _context;

        public SociaRepository(DataContext context) : base(context)
        {
            this._context = context;
        }

        public async Task<ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>>> ListadoSociaParaAprobar(FiltroSociaParaAprobarModel model,List<string> sucursal)
        {
            var responseDto = new ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>>();
            var query = _context.Socia.Where(p => p.EstadoFila);
            if (!string.IsNullOrEmpty(model.Dni))
            {
                query = query.Where(p => p.NroDni.Contains(model.Dni));
            }

            if (!string.IsNullOrEmpty(model.ApellidoNombre))
            {
                query = query.Where(p => p.ApellidoPaterno.Contains(model.ApellidoNombre) ||
                                         p.ApellidoMaterno.Contains(model.ApellidoNombre) ||
                                         p.Nombre.Contains(model.ApellidoNombre));
            }

            if (sucursal.Any())
            {
                query = query.Where(p => sucursal.Contains(p.Sucursal.Codigo));
            }

            if (!string.IsNullOrEmpty(model.SucursalCodigo))
            {
                query = query.Where(p => p.Sucursal.Codigo == model.SucursalCodigo);
            }

            var result = query.Select(s => new ListaSociaParaAprobarDto()
            {
                Id = s.Id,
                Nombre = s.Nombre,
                ApellidoPaterno = s.ApellidoPaterno,
                ApellidoMaterno = s.ApellidoMaterno,
                Dni = s.NroDni,
                Estado = s.Estado.Descripcion,
                EstadoCodigo = s.Estado.Codigo

            }).SortBy(model.Order, model.ColumnOrder);
            
            var response = await result.GetPagedAsync(model.Page, model.PageSize);

            responseDto.Data = response;

            return responseDto;
        }

        public async Task<ActualizarDatoPersonalDto> ObtenerPorIdParaActualizarDatoPersonal(int idSocia)
        {
            return await _context.Socia.Where(p => p.EstadoFila && p.Id==idSocia)
                    .Select(s=>new ActualizarDatoPersonalDto()
                    {
                        Id = s.Id,
                        Dni = s.NroDni,
                        Nombre = s.Nombre,
                        ApellidoPaterno = s.ApellidoPaterno,
                        ApellidoMaterno = s.ApellidoMaterno
                    }).FirstOrDefaultAsync()
                ;
        }
        public async Task<SociaEntity> ObtenerConFormularioPorIdYEstado(int idSocia,string estado)
        {
            return await _context.Socia.Where(p => p.EstadoFila && p.Id == idSocia
                    && p.Estado.Codigo==estado
                    )
                    .Select(s => new SociaEntity()
                    {
                        Id = s.Id,
                        NroDni = s.NroDni,
                        Nombre = s.Nombre,
                        ApellidoPaterno = s.ApellidoPaterno,
                        ApellidoMaterno = s.ApellidoMaterno,
                        Celular = s.Celular,
                        EntidadBancario = s.EntidadBancario,
                        NroCuenta = s.NroCuenta,
                        SucursalId = s.SucursalId,
                        EstadoId = s.EstadoId,
                        CodigoCliente = s.CodigoCliente,
                        Formulario = s.Formulario.Where(p=>p.EstadoFila).ToList()
                    }).FirstOrDefaultAsync()
                ;
        }
    }
}
