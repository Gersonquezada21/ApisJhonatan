﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Credimujer.Op.Domail.Models.Entities;
using Credimujer.Op.Dto.Base;
using Credimujer.Op.Repository.Implementations.Data;
using Credimujer.Op.Repository.Implementations.Data.Base;
using Credimujer.Op.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Op.Repository.Implementations
{
    public class CatalogoDetalleRepository : BaseRepository<CatalogoDetalleEntity>, ICatalogoDetalleRepository
    {
        private readonly DataContext _context;

        public CatalogoDetalleRepository(DataContext context) : base(context)
        {
            this._context = context;
        }
        public async Task<List<DropdownDto>> ListarPorCatalogoCodigoParaDropDown(string codigo)
        {
            return await _context.CatalogoDetalle.Where(p => p.EstadoFila
                                                             && p.Catalogo.Codigo == codigo

                )
                .Select(s => new DropdownDto()
                {
                    Id = s.Id,
                    Code = s.Codigo,
                    Description = s.Descripcion
                })
                .ToListAsync();
        }
        public async Task<DropdownDto> ObtenerPorCodigoConEstadoActivo(string codigo)
        {
            return await _context.CatalogoDetalle.Where(p => p.EstadoFila && p.Codigo == codigo)
                .Select(s => new DropdownDto()
                {
                    Id = s.Id,
                    Code = s.Codigo,
                    Description = s.Descripcion
                })
                .FirstOrDefaultAsync();
        }
    }
}
