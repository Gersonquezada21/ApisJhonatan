﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Op.Domail.Models.Entities;
using Credimujer.Op.Repository.Implementations.Configurations.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Op.Repository.Implementations.Configurations
{
    public class AnilloGrupalConfiguration : EntityConfiguration<AnilloGrupalEntity>
    {
        public AnilloGrupalConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<AnilloGrupalEntity>();
            entityBuilder.ToTable("ASO_ANILLO_GRUPAL");
            entityBuilder.HasKey(c => c.Codigo);
            entityBuilder.Property(c => c.Id).HasColumnName("IN_ID");
            entityBuilder.Property(c => c.Codigo).HasColumnName("VC_CODIGO");
            entityBuilder.Property(c => c.BancoComunalCodigo).HasColumnName("VC_BANCO_COMUNAL_CODIGO");
            entityBuilder.Property(c => c.Descripcion).HasColumnName("VC_DESCRIPCION");
            entityBuilder.HasOne(c => c.BancoComunal).WithMany(m => m.AnilloGrupal)
                .HasForeignKey(f => f.BancoComunalCodigo);
            Configure(entityBuilder);
        }
    }
}
