﻿using System;

namespace Credimujer.Op.Caching
{
    public class Class1
    {
    }
}
