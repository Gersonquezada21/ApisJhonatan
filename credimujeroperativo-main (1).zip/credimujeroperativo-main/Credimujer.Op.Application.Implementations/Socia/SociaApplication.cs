﻿using Autofac;
using Credimujer.Op.Application.Interfaces;
using Credimujer.Op.Common;
using Credimujer.Op.Common.Base;
using Credimujer.Op.Model.Socia.Registrar;
using Credimujer.Op.Repository.Interfaces;
using Credimujer.Op.Repository.Interfaces.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Credimujer.Op.Common.Exceptions;
using Credimujer.Op.Common.Resources;
using Credimujer.Op.Domail.Models.Entities;
using Credimujer.Op.Dto.Base;
using Credimujer.Op.Dto.Socia;
using Credimujer.Op.Dto.Socia.Busqueda;
using Credimujer.Op.Dto.Socia.Registro;
using Credimujer.Op.Model.Socia;
using Credimujer.Op.Model.Socia.Busqueda;
using Credimujer.Op.Model.Service.Iam;
using Credimujer.Op.Service.Interfaces;
using System.Linq;

namespace Credimujer.Op.Application.Implementations.Socia
{
    public class SociaApplication : ISociaApplication
    {
        private readonly Lazy<IUnitOfWork> _unitOfWork;
        private readonly AppSetting _setting;
        private readonly Lazy<IHttpContextAccessor> _httpContext;
        private readonly Lazy<IIamService> _iamService;

        public SociaApplication(IOptions<AppSetting> settings, ILifetimeScope lifetimeScope)
        {
            _setting = settings.Value;
            _unitOfWork = new Lazy<IUnitOfWork>(() => lifetimeScope.Resolve<IUnitOfWork>());
            _httpContext = new Lazy<IHttpContextAccessor>(() => lifetimeScope.Resolve<IHttpContextAccessor>());
            _iamService = new Lazy<IIamService>(() => lifetimeScope.Resolve<IIamService>());
        }

        private ClaimsPrincipal UserIdentity => _httpContext.Value.HttpContext.User;
        private IUnitOfWork UnitOfWork => _unitOfWork.Value;
        private ISociaRepository SociaRepository => UnitOfWork.Repository<ISociaRepository>();

        private ICatalogoDetalleRepository CatalogoDetalleRepository =>
            UnitOfWork.Repository<ICatalogoDetalleRepository>();

        private IDepartamentoRepository DepartamentoRepository => UnitOfWork.Repository<IDepartamentoRepository>();

        private IIamService IamService => UnitOfWork.Repository<IIamService>();
        private IBancoComunalRepository BancoComunalRepository => UnitOfWork.Repository<IBancoComunalRepository>();
        public async Task<ResponseDto> Catalogo(CatalogoModel model)
        {
            var comunDto = new CatalogoDto();
            if (model.ObtenerEstadoCivil)
                comunDto.EstadoCivil =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.EstadoCivil);
            if (model.ObtenerGradoInstruccion)
                comunDto.GradoInstruccion =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo
                        .GradoInstruccion);
            if (model.ObtenerAfirmacion)
                comunDto.Afirmacion =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.Afirmacion);
            if (model.ObtenerDepartamento)
                comunDto.Departamento = await DepartamentoRepository.ListarDropdown();
            if (model.ObtenerEntidadFinanciera)
                comunDto.EntidadFinanciera =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo
                        .EntidadFinanciera);
            if (model.ObtenerSituacionDomicilio)
                comunDto.SituacionDomicilio =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo
                        .SituacionDomicilio);
            if (model.ObtenerSucursal)
                comunDto.Sucursal =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo
                        .Sucursal);
            return new ResponseDto()
            {
                Data = comunDto
            };
        }

        public async Task<ResponseDto> RegistrarSocia(NuevaSociaModel model)
        {
            var resultExist = await SociaRepository.Any(p => p.EstadoFila && p.NroDni == model.Dni);
            if (resultExist)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Socia ya se encuentra Registrada");
            var estado =
                await CatalogoDetalleRepository.ObtenerPorCodigoConEstadoActivo(Constants.Core.Catalogo.DetEstadoSocia
                    .PendienteConfirmacion);
            var entity = new SociaEntity()
            {
                NroDni = model.Dni,
                Nombre = model.Nombre,
                ApellidoPaterno = model.ApellidoPaterno,
                ApellidoMaterno = model.ApellidoMaterno,
                Celular = model.Celular,
                EstadoId = (int)estado.Id,
                Formulario = new List<FormularioEntity>()
                {
                    new()
                    {
                        EstadoCivilId = model.EstadoCivilId,
                        NroDependiente = model.NroDependiente,
                        ActividadEconomica = model.ActividadEconomica,
                        Ubicacion = model.Ubicacion,
                        Direccion = model.Direccion,
                        Referencia = model.Referencia,
                        NroCuenta = model.NroCuenta,
                        Representante = model.Representante,
                        UbicacionNegocio = model.UbicacionNegocio,
                        DireccionNegocio = model.DireccionNegocio,
                        ReferenciaNegocio = model.ReferenciaNegocio,
                        GradoInstruccionId = model.GradoInstruccionId,
                        SituacionDomicilioId = model.SituacionDomicilioId,
                        EntidadBancariaId = model.EntidadBancariaId,
                    }
                }
            };
            await UnitOfWork.Set<SociaEntity>().AddAsync(entity);
            await UnitOfWork.SaveChangesAsync();
            return new ResponseDto() { Message = CommonResource.register_ok };
        }

        public async Task<ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>>> BusquedaSocia(FiltroSociaParaAprobarModel model)
        {
            ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>> result;

            if (string.IsNullOrEmpty(model.SucursalCodigo))
            {
                var listaSucursal = ObtenerSucursal();
                result = await SociaRepository.ListadoSociaParaAprobar(model, listaSucursal);
            }
            else
            {
                result=await SociaRepository.ListadoSociaParaAprobar(model, new List<string>());
            }

            
            return result;
        }

        public async Task<ResponseDto> AprobarAccesoSocia(RegistrarUsuarioModel model)
        {
            var obtenerSocia = await SociaRepository.FirstOrDefault(p => p.Id == model.Id && p.EstadoFila && p.Estado.Codigo == Constants.Core.Catalogo.DetEstadoSocia.PendienteConfirmacion);
            if (obtenerSocia == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "No se encontro registro.");
            model.Nombre = obtenerSocia.Nombre;
            model.ApellidoPaterno = obtenerSocia.ApellidoPaterno;
            model.ApellidoMaterno = obtenerSocia.ApellidoMaterno;
            model.Celular = obtenerSocia.Celular;
            model.Dni = obtenerSocia.NroDni;

            var listaEstado = await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.EstadoSocia);

            //var estado = await CatalogoDetalleRepository.ObtenerPorCodigoConEstadoActivo(Constants.Core.Catalogo.DetEstadoSocia.Activa);

            obtenerSocia.EstadoId = (int)listaEstado.First(f => f.Code == model.Estado).Id;
            obtenerSocia.BancoComunalCodigo = model.BancoComunal;
            UnitOfWork.Set<SociaEntity>().Update(obtenerSocia);

            var response = await IamService.RegistrarUsuarioTipoSocia(model);
            if (response.Status == Constants.SystemStatusCode.Ok)
                await UnitOfWork.SaveChangesAsync();

            return response;
        }

        public async Task<ResponseDto> ObtenerSociaPorId(int sociaId)
        {
            var result = await SociaRepository.ObtenerPorIdParaActualizarDatoPersonal(sociaId);
            if (result == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "No se encontro registro.");

            return new ResponseDto()
            {
                Data = result
            };
        }

        public async Task<ResponseDto> ActualizarDatoPersonal(ActualizarDatoPersonalDto model)
        {
            var result = await SociaRepository.FirstOrDefault(p => p.EstadoFila && p.Id == model.Id);
            if (result == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "No se actulizó porque socia no se encuentra registrada.");
            result.NroDni = model.Dni;
            result.Nombre = model.Nombre;
            result.ApellidoPaterno = model.ApellidoPaterno;
            result.ApellidoMaterno = model.ApellidoMaterno;
            UnitOfWork.Set<SociaEntity>().Update(result);
            await UnitOfWork.SaveChangesAsync();
            return new ResponseDto() { Message = CommonResource.update_ok };
        }

        public async Task<ResponseDto> BusquedaBancoComunal(string descripcion)
        {
            var result = await BancoComunalRepository.BusquedaPorDescripcion(descripcion);
            return new ResponseDto()
            {
                Data = result
            };

        }

        private List<string> ObtenerSucursal()
        {
            var data=UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.Sucursal);

            return data != null ? data.Value.Split(",").ToList() : new List<string>();
        }
    }
}