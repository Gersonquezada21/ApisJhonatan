﻿using System.Collections.Generic;
using Credimujer.Op.Common.Base;
using Credimujer.Op.Domail.Models.Entities;
using Credimujer.Op.Dto.Base;
using Credimujer.Op.Dto.Socia.Busqueda;
using Credimujer.Op.Model.Socia.Busqueda;
using Credimujer.Op.Repository.Interfaces.Data;
using System.Threading.Tasks;
using Credimujer.Op.Dto.Socia.Registro;

namespace Credimujer.Op.Repository.Interfaces
{
    public interface ISociaRepository : IBaseRepository<SociaEntity>
    {
        Task<ResponseDto<PaginationResultDTO<ListaSociaParaAprobarDto>>> ListadoSociaParaAprobar(FiltroSociaParaAprobarModel model, List<string> sucursal);
        Task<ActualizarDatoPersonalDto> ObtenerPorIdParaActualizarDatoPersonal(int idSocia);
        Task<SociaEntity> ObtenerConFormularioPorIdYEstado(int idSocia, string estado);
    }
}
