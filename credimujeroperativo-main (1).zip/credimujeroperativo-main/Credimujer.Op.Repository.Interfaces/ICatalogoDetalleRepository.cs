﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Credimujer.Op.Domail.Models.Entities;
using Credimujer.Op.Dto.Base;
using Credimujer.Op.Repository.Interfaces.Data;

namespace Credimujer.Op.Repository.Interfaces
{
    public interface ICatalogoDetalleRepository : IBaseRepository<CatalogoDetalleEntity>
    {
        Task<List<DropdownDto>> ListarPorCatalogoCodigoParaDropDown(string codigo);
        Task<DropdownDto> ObtenerPorCodigoConEstadoActivo(string codigo);
    }
}
