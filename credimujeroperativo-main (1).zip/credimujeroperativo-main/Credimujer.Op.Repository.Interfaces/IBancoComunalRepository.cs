﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Op.Dto.Base;

namespace Credimujer.Op.Repository.Interfaces
{
    public interface IBancoComunalRepository
    {
        Task<List<DropdownDto>> BusquedaPorDescripcion(string descripcion);

    }
}
