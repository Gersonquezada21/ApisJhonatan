﻿using Autofac;
using Credimujer.Asociado.Application.Interfaces;
using Credimujer.Asociado.Common;
using Credimujer.Asociado.Common.Base;
using Credimujer.Asociado.Common.Exceptions;
using Credimujer.Asociado.Common.Resources;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Dto.Socia;
using Credimujer.Asociado.Model.Socia;
using Credimujer.Asociado.Model.Socia.Registro;
using Credimujer.Asociado.Repository.Interfaces;
using Credimujer.Asociado.Repository.Interfaces.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Application.Implementations
{
    public class SociaApplication : ISociaApplication
    {
        private readonly Lazy<IUnitOfWork> _unitOfWork;
        private readonly Lazy<IUnitOfWorkAdmin> _unitOfWorkAdmin;
        private readonly AppSetting _setting;
        private readonly Lazy<IHttpContextAccessor> _httpContext;

        public SociaApplication(IOptions<AppSetting> settings,
            ILifetimeScope lifetimeScope

        )
        {
            _setting = settings.Value;
            _unitOfWork = new Lazy<IUnitOfWork>(() => lifetimeScope.Resolve<IUnitOfWork>());
            _httpContext = new Lazy<IHttpContextAccessor>(() => lifetimeScope.Resolve<IHttpContextAccessor>());
            _unitOfWorkAdmin = new Lazy<IUnitOfWorkAdmin>(() => lifetimeScope.Resolve<IUnitOfWorkAdmin>());
        }

        #region Properties

        public IUnitOfWork UnitOfWork => _unitOfWork.Value;
        public IUnitOfWorkAdmin UnitOfWorkAdmin => _unitOfWorkAdmin.Value;
        private ClaimsPrincipal UserIdentity => _httpContext.Value.HttpContext.User;

        private ICatalogoDetalleRepository CatalogoDetalleRepository =>
            UnitOfWork.Repository<ICatalogoDetalleRepository>();

        private ISociaRepository SociaRepository => UnitOfWork.Repository<ISociaRepository>();
        private IFormularioRepository FormularioRepository => UnitOfWork.Repository<IFormularioRepository>();
        private IDepartamentoRepository DepartamentoRepository => UnitOfWork.Repository<IDepartamentoRepository>();
        private IProvinciaRepository ProvinciaRepository => UnitOfWork.Repository<IProvinciaRepository>();
        private IDistritoRepository DistritoRepository => UnitOfWork.Repository<IDistritoRepository>();

        private ISFD_SOCIACOMPLETARepository IsfdSociacompletaRepository =>
            UnitOfWorkAdmin.Repository<ISFD_SOCIACOMPLETARepository>();

        #endregion Properties

        public async Task<ResponseDTO> CargarDatoComun(CargarDataComunModel model)
        {
            var comunDto = new CargaDataComunDto();
            if (model.ObtenerEstadoCivil)
                comunDto.EstadoCivil =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.EstadoCivil);
            if (model.ObtenerGradoInstruccion)
                comunDto.GradoInstruccion =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo
                        .GradoInstruccion);
            if (model.ObtenerAfirmacion)
                comunDto.Afirmacion =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.Afirmacion);
            if (model.ObtenerDepartamento)
                comunDto.Departamento = await DepartamentoRepository.ListarDropdown();
            if (model.ObtenerEntidadFinanciera)
                comunDto.EntidadFinanciera =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo
                        .EntidadFinanciera);
            if (model.ObtenerSituacionDomicilio)
                comunDto.SituacionDomicilio =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo
                        .SituacionDomicilio);
            if (model.ObtenerSucursal)
                comunDto.Sucursal= await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.Sucursal);
            return new ResponseDTO()
            {
                Data = comunDto
            };
        }

        public async Task<ResponseDTO> SociaTieneFormulario()
        {
            var usuario = UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.NombreUsuario).Value;
            var sociaTieneFormulario = await SociaRepository.SociaTieneFormulario(usuario);

            return new ResponseDTO()
            {
                Data = new
                {
                    TieneFormulario = sociaTieneFormulario
                }
            };
        }

        public async Task<ResponseDTO> RegistrarFormulario(FormularioModel model)
        {
            var usuario = UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.NombreUsuario).Value;
            var sociaId = await SociaRepository.ObtenerIdPorNroDocumento(usuario);
            if (sociaId == 0)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El usuario no esta registrado como socia.");

            var entidad = new FormularioEntity()
            {
                SociaId = sociaId,
                EstadoCivilId = model.EstadoCivilId,
                GradoInstruccionId = model.GradoInstruccionId,
                Celular = model.Celular,
                NroDependiente = model.NroDependiente,
                ActividadEconomica = model.ActividadEconomica,
                ActividadEconomica2 = model.ActividadEconomica2,
                ActividadEconomica3 = model.ActividadEconomica3,
                Ubicacion = model.Ubicacion,
                Direccion = model.Direccion,
                Referencia = model.Referencia,
                SituacionDomicilioId = model.SituacionDomicilioId,
                //TieneCtaAhorro =string.IsNullOrEmpty(model.NroCuenta)?0:1,
                EntidadBancariaId = model.EntidadBancariaId,
                NroCuenta = model.NroCuenta,
                Representante = model.Representante,
                BancoComunal = model.BancoComunal,
                UbicacionNegocio = model.UbicacionNegocio,
                DireccionNegocio = model.DireccionNegocio,
                ReferenciaNegocio = model.ReferenciaNegocio
            };
            await UnitOfWork.Set<FormularioEntity>().AddAsync(entidad);
            await UnitOfWork.SaveChangesAsync();
            return new ResponseDTO() { Message = CommonResource.register_ok };
        }

        public async Task<ResponseDTO> RegistrarNuevaSocia(SociaModel model)
        {
            var existeSocia = await SociaRepository.Any(p => p.NroDni == model.Dni);
            if (existeSocia)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "Ya se encuentra registrada.");
            var estado = await CatalogoDetalleRepository.ObtenerPorCodigo(Constants.Core.Catalogo.DetEstadoSocia.PendienteConfirmacion);
            var entity = new SociaEntity()
            {
                ApellidoPaterno = model.ApellidoPaterno,
                ApellidoMaterno = model.ApellidoMaterno,
                Nombre = model.Nombre,
                NroDni = model.Dni,
                Celular = model.Celular,
                SucursalId = model.SucursalId,
                EstadoId = estado.Id
            };
            await UnitOfWork.Set<SociaEntity>().AddAsync(entity);
            await UnitOfWork.SaveChangesAsync();
            return new ResponseDTO() { Message = CommonResource.register_ok };
        }

        public async Task<ResponseDTO> CargarDepartamentoDisponible()
        {
            var data = await DepartamentoRepository.ListarDropdown();
            data = data.Where(p => Constants.Core.Departamento.DepartamentoDisponible.Contains(p.Code)).ToList();
            return new ResponseDTO()
            {
                Data = data
            };
        }

        public async Task<ResponseDTO> ObtenerSociaId(string nroDocumento)
        {
            var result = await SociaRepository.ObtenerDatoParaLoginPorNumeroDocumento(nroDocumento);
            if (result == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "Comunicarse con su asesora de crédito.");

            return new ResponseDTO() { Data = result };
        }

        
        public async Task<ResponseDTO> ObtenerPerfilConFormulario()
        {
            var sociaId = int.Parse(UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.SociaId).Value);
            var result = await SociaRepository.ObtenerDatoPersonalPorId(sociaId);
            if (result == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "Socia debe de registrar su Formulario, es obligatorio.");
            return new ResponseDTO() { Data = result };
        }

        public async Task<ResponseDTO> ObtenerFormulario()
        {
            var sociaId = int.Parse(UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.SociaId).Value);
            var result = await FormularioRepository.ObtenerPorSociaId(sociaId);
            if (result == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "Socia debe de registrar su Formulario, es obligatorio.");
            return new ResponseDTO() { Data = result };
        }

        public async Task<ResponseDTO> ActualizarFormulario(FormularioActualizarModel model)
        {
            var sociaId = int.Parse(UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.SociaId).Value);
            var obtenerFormularioActual = await FormularioRepository.GetWhere(p => p.EstadoFila && p.SociaId == sociaId);
            var socia = await SociaRepository.GetById(sociaId);
            if (obtenerFormularioActual == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "Socia debe de registrar su Formulario, es obligatorio.");
            foreach (var r in obtenerFormularioActual)
            {
                r.EstadoFila = false;
            }

            var nuevoFormulario = obtenerFormularioActual.First();
            nuevoFormulario.EstadoFila = true;
            //nuevoFormulario.EstadoCivilId = model.EstadoCivilId;
            nuevoFormulario.Celular = model.Celular;
            socia.Celular = model.Celular;
            //nuevoFormulario.ActividadEconomica = model.ActividadEconomica;
            //nuevoFormulario.Ubicacion = model.Ubicacion;
            //nuevoFormulario.Direccion = model.Direccion;
            //nuevoFormulario.Referencia = model.Referencia;
            //nuevoFormulario.SituacionDomicilioId = model.SituacionDomicilioId;
            nuevoFormulario.EntidadBancariaId = model.EntidadBancaria;
            nuevoFormulario.NroCuenta = model.NroCuenta;
            nuevoFormulario.ActividadPrincipal = model.ActividadPrincipal;
            //nuevoFormulario.UbicacionNegocio = model.UbicacionNegocio;
            //nuevoFormulario.DireccionNegocio = model.DireccionNegocio;
            //nuevoFormulario.ReferenciaNegocio = model.ReferenciaNegocio;

            obtenerFormularioActual.Append(nuevoFormulario);
            UnitOfWork.Set<SociaEntity>().Update(socia);
            UnitOfWork.Set<FormularioEntity>().UpdateRange(obtenerFormularioActual);
            await UnitOfWork.SaveChangesAsync();
            return new ResponseDTO() { Message = CommonResource.update_ok };
        }

        public async Task<ResponseDTO> ResumenProducto()
        {
            var sociaId = int.Parse(UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.SociaId).Value);
            var codigoSocia = await SociaRepository.FirstOrDefault(p => p.EstadoFila && p.Id == sociaId);
            if (codigoSocia != null && codigoSocia.CodigoCliente != null)
            {
                var result = SociaRepository.ResumenProducto(codigoSocia.CodigoCliente);
                return new ResponseDTO() { Data = result };
            }
            return new ResponseDTO();
        }
    }
}