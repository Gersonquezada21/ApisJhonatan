﻿using Autofac;
using Credimujer.Asociado.Application.Interfaces;
using Credimujer.Asociado.Common;
using Credimujer.Asociado.Common.Base;
using Credimujer.Asociado.Common.Resources;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Dto.PreSolicitud;
using Credimujer.Asociado.Model.PreSolicitud;
using Credimujer.Asociado.Model.PreSolicitud.Registro;
using Credimujer.Asociado.Repository.Interfaces;
using Credimujer.Asociado.Repository.Interfaces.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Application.Implementations
{
    public class PreSolicitudApplication : IPreSolicitudApplication
    {
        private readonly Lazy<IUnitOfWork> _unitOfWork;
        private readonly AppSetting _setting;
        private readonly Lazy<IHttpContextAccessor> _httpContext;

        public PreSolicitudApplication(IOptions<AppSetting> settings,
           ILifetimeScope lifetimeScope

       )
        {
            _setting = settings.Value;
            _unitOfWork = new Lazy<IUnitOfWork>(() => lifetimeScope.Resolve<IUnitOfWork>());
            _httpContext = new Lazy<IHttpContextAccessor>(() => lifetimeScope.Resolve<IHttpContextAccessor>());
        }

        #region Properties

        public IUnitOfWork UnitOfWork => _unitOfWork.Value;
        private ClaimsPrincipal UserIdentity => _httpContext.Value.HttpContext.User;
        private IPreSolicitudRepository PreSolicitudRepository => UnitOfWork.Repository<IPreSolicitudRepository>();

        private ICatalogoDetalleRepository CatalogoDetalleRepository =>
            UnitOfWork.Repository<ICatalogoDetalleRepository>();

        #endregion Properties

        public async Task<ResponseDTO> CargarDatoComun(CargarDataComunModel model)
        {
            var comunDto = new CargaDataComunDto();
            if (model.ObtenerEntidadBancaria)
                comunDto.EntidadBancaria = await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.EntidadFinanciera);
            if (model.ObtenerTipoCredito)
                comunDto.TipoCredito = await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.TipoCredito);
            if (model.ObtenerAfirmacion)
                comunDto.Afirmacion =
                    await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.Afirmacion);
            if (model.ObtenerSubTipoCredito)
                comunDto.SubTipoCredito = await CatalogoDetalleRepository.ListarPorCatalogoCodigoParaDropDown(Constants.Core.Catalogo.SubTipoCredito);
            return new ResponseDTO()
            {
                Data = comunDto
            };
        }

        public async Task<ResponseDTO> ListarPreSolicitudPorSocia()
        {
            var sociaId = int.Parse(UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.SociaId).Value);
            var result = await PreSolicitudRepository.ListarPorSociaId(sociaId);
            return new ResponseDTO
            {
                Data = result
            };
        }

        public async Task<ResponseDTO> RegistrarPreSolicitud(PreSolicitudModel model)
        {
            var sociaId = int.Parse(UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.SociaId).Value);
            var cantPreSolicitud = await PreSolicitudRepository.CountWhere(p => p.SociaId == sociaId && p.EstadoFila);
            var entity = new PreSolicitudEntity()
            {
                Nro = cantPreSolicitud + 1,
                SociaId = sociaId,
                EntidadBancariaId = model.EntidadBancariaId,
                Plazo = model.Plazo,
                PlazoGracia = model.PlazoGracia,
                Monto = model.Monto,
                TipoCreditoId = model.TipoCreditoId,
                SubTipoCreditoId = model.SubTipoCreditoId,
            };
            await UnitOfWork.Set<PreSolicitudEntity>().AddAsync(entity);
            await UnitOfWork.SaveChangesAsync();
            return new ResponseDTO { Message = CommonResource.register_ok };
        }

        public async Task<ResponseDTO> ListaUltimaPresolicitud()
        {
            var sociaId = int.Parse(UserIdentity.FindFirst(Constants.Core.UserAsociadoClaims.SociaId).Value);
            var result = await PreSolicitudRepository.ListarPresolicitudPorMesYSocia(sociaId);
            return new ResponseDTO
            {
                Data = result
            };
        }
    }
}