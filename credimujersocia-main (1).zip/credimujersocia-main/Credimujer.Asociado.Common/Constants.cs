﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Common
{
    public class Constants
    {
        public struct SystemStatusCode
        {
            public const int Ok = 0;
            public const int Required = 1;
            public const int TechnicalError = -1;
            public const int FunctionalError = -2;
        }

        public struct DateTimeFormats
        {
            public const string DD_MM_YYYY = "dd-MM-yyyy";
            public const string DD_MM_YYYY_HH_MM_SS = "dd/MM/yyyy HH:mm:ss";
            public const string DD_MM_YYYY_HH_MM_TT_12 = "dd/MM/yyyy hh:mm tt";
            public const string DD_MM_YYYY_HH_MM_SS_TT_12 = "dd/MM/yyyy hh:mm:ss tt";
            public const string DD_MM_YYYY_HH_MM_24 = "dd/MM/yyyy HH:mm";
            public const string DD_MM_YYYY_HH_MM_SS_FFF = "yyyyMMddHHmmssFFF";
            public const string DD_MM_YYY_HH_MM_SS = "ddMMyyyHHmmss";
            public const string YYYY_MM_DD = "yyyyMMdd";
        }

        public struct Core
        {
            public struct Audit
            {
                public const string CreationUser = "UsuarioCreacion";
                public const string CreationDate = "FechaCreacion";
                public const string ModificationUser = "UsuarioModificacion";
                public const string ModificationDate = "FechaModificacion";
                public const string RowStatu = "EstadoFila";
                public const string System = "CrediMujerSystem";
            }

            public struct UserAsociadoClaims
            {
                public const string NombreUsuario = "NombreUsuario";
                public const string NombreCompleto = "NombreCompleto";
                public const string GuiId = "GuiId";//en caso el usuario se logea en 2 dispositivos.
                public const string SociaId = "SociaId";
            }

            public struct Catalogo
            {
                public const string EstadoCivil = "ESTCIVIL";
                public const string GradoInstruccion = "GRADOINS";
                public const string SituacionDomicilio = "SITDOMIC";
                public const string Afirmacion = "SINO";
                public const string EntidadFinanciera = "ENTIFINAN";
                public const string EstadoSocia = "ESTADOSOC";
                public const string TipoCredito = "TIPCRED";
                public const string SubTipoCredito = "SUBTIPCRE";
                public const string Sucursal = "SUC";
                public struct DetEstadoSocia
                {
                    public const string Activa = "ACTIVO";
                    public const string PendienteConfirmacion = "PENDIEN";
                }
            }

            public static class Departamento
            {
                public static List<string> DepartamentoDisponible = new()
                {
                    "01",
                    "02",
                    "06",
                    "13",
                    "14",
                    "21",
                    "16",
                    "22",
                    "10",
                    "25"
                };
            }
        }
    }
}