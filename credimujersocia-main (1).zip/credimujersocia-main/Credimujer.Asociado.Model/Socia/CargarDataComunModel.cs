﻿namespace Credimujer.Asociado.Model.Socia
{
    public class CargarDataComunModel
    {
        public bool ObtenerEstadoCivil { get; set; }
        public bool ObtenerGradoInstruccion { get; set; }
        public bool ObtenerSituacionDomicilio { get; set; }
        public bool ObtenerAfirmacion { get; set; }
        public bool ObtenerEntidadFinanciera { get; set; }
        public bool ObtenerDepartamento { get; set; }
        public bool ObtenerSucursal { get; set; }
    }
}
