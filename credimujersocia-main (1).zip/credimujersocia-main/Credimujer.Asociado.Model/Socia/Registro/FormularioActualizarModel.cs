﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Model.Socia.Registro
{
    public class FormularioActualizarModel
    {
        //public int EstadoCivilId { get; set; }
        public string Celular { get; set; }
        //public string ActividadEconomica { get; set; }
        //public string Ubicacion { get; set; }
        //public string Direccion { get; set; }
        //public string Referencia { get; set; }
        //public int SituacionDomicilioId { get; set; }
        public int? EntidadBancaria { get; set; }
        public string NroCuenta { get; set; }
        public string ActividadPrincipal { get; set; }

        //public string UbicacionNegocio { get; set; }
        //public string DireccionNegocio { get; set; }
        //public string ReferenciaNegocio { get; set; }
    }
}
