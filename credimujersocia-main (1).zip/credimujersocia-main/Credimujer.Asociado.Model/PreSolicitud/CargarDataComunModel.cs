﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Model.PreSolicitud
{
    public class CargarDataComunModel
    {
        public bool ObtenerEntidadBancaria { get; set; }
        public bool ObtenerTipoCredito { get; set; }
        public bool ObtenerAfirmacion { get; set; }
        public bool ObtenerSubTipoCredito { get; set; }
    }
}