﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Model.PreSolicitud.Registro
{
    public class PreSolicitudModel
    {
        public decimal Monto { get; set; }
        public int Plazo { get; set; }
        public int? PlazoGracia { get; set; }
        public int EntidadBancariaId { get; set; }
        public int TipoCreditoId { get; set; }
        public int? SubTipoCreditoId { get; set; }
    }
}