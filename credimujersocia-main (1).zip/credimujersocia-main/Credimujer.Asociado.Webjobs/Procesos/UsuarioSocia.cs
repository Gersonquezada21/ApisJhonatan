﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using Credimujer.Asociado.Repository.Implementations;
using Credimujer.Asociado.Repository.Interfaces;
using Credimujer.Asociado.Repository.Interfaces.Data;
using Microsoft.Extensions.Configuration;

namespace Credimujer.Asociado.Webjobs.Procesos
{
    public static class UsuarioSocia
    {
        public static async Task ActualizarUsuario(IConfiguration config, string transactionId,
            ILifetimeScope lifetimeScope)
        {
            var unitOfWork = new Lazy<IUnitOfWorkAdmin>(() => lifetimeScope.Resolve<IUnitOfWorkAdmin>());
            var unitOfWorkSocia = new Lazy<IUnitOfWork>(() => lifetimeScope.Resolve<IUnitOfWork>());
            var socia = unitOfWork.Value.Repository<ISFD_SOCIACOMPLETARepository>();
            var sociaMigrada = unitOfWorkSocia.Value.Repository<ISociaRepository>();

            var listaDuplicatos = await socia.ObtenerDuplicados();
            var listaSocias = await socia.ObtenerTodos();
            var listaSociasMigradas = await sociaMigrada.GetAll();

            var listaParaMigrar =listaSocias.GroupJoin(listaSociasMigradas,
                l => l.NroDni, m => m.NroDni, (l, m) => new { l, m }
            ).SelectMany(x => x.m.DefaultIfEmpty(), (l,m) => l.l);

            var existe = listaParaMigrar.Where(p => p.NroDni == "19060794");
            Console.Out.WriteLine("***************************************************");
            Console.Out.WriteLine($"Inicio de migración de socias continuas");
            listaParaMigrar.ToList().ForEach(f =>
            {

                Console.Out.WriteLine($"Socia");
                Console.Out.WriteLine($"        CodSocia:{f.NroDni}");
            });


        }
    }
}
