﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Credimujer.Asociado.Common;
using Credimujer.Asociado.Repository.Implementations.Data;
using Credimujer.Asociado.Repository.Implementations.Data.Base;
using Credimujer.Asociado.Repository.Interfaces.Data;
using Credimujer.Asociado.Webjobs.Procesos;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyModel;

namespace Credimujer.Asociado.Webjobs
{
    class Program
    {
        public static IConfiguration config { get; set; }
        static async Task Main(string[] args)
        {
            var transactionId = DateTime.Now.ToString(Constants.DateTimeFormats.DD_MM_YYYY_HH_MM_SS_FFF);
             

             try
             {
                 var container = RegisterDependency();
                 var process = config.GetSection("AppSettings:ConnectionStrings:DefaultConnectionAdmin").Get<string>();
                await UsuarioSocia.ActualizarUsuario(config, transactionId, container);
             }
             catch (Exception e)
             {
                     Console.WriteLine($"SE PRODUJO UN ERROR EN EL PROCESO BATCH {e.Message}");
             }
        }
        private static IConfiguration LoadConfiguration()
        {

            var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            string appSettingName = string.Empty;
            if (env == "Production")
                appSettingName = ".Production";

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile($"appsettings{appSettingName}.json", optional: true)

                .AddEnvironmentVariables();

            return builder.Build();
        }
        private static IContainer RegisterDependency()
        {
            var assemblies = new List<Assembly>();
            var dependencies = DependencyContext.Default.RuntimeLibraries;
            foreach (var library in dependencies)
            {
                if (library.Name.StartsWith("Credimujer"))
                {
                    var assembly = Assembly.Load(new AssemblyName(library.Name));
                    assemblies.Add(assembly);
                }
            }

            var assembliesArray = assemblies.ToArray();
            ContainerBuilder builder = new ContainerBuilder();
            config = LoadConfiguration();

            var services = new ServiceCollection();
            var appSettingsSection = config.GetSection("AppSettings");
            var appSettings = appSettingsSection.Get<AppSetting>();
            services.Configure<AppSetting>(appSettingsSection);
            services.AddSingleton(cfg => cfg.GetService<IOptions<AppSetting>>().Value);


            builder.Populate(services);

            builder.RegisterAssemblyTypes(assembliesArray).Where(t => t.Name.EndsWith("Service")).AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterAssemblyTypes(assembliesArray).Where(t => t.Name.EndsWith("Repository")).AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterAssemblyTypes(assembliesArray).Where(t => t.Name.EndsWith("Application")).AsImplementedInterfaces().InstancePerLifetimeScope();

            Autofac.IContainer container = null;
            builder.Register(c => container).AsSelf().SingleInstance();

            builder.RegisterGeneric(typeof(BaseRepository<>)).As(typeof(IBaseRepository<>)).InstancePerDependency();
            builder.RegisterType<UnitOfWork>().As<IUnitOfWork>().InstancePerLifetimeScope();

            builder.RegisterGeneric(typeof(BaseRepositoryAdmin<>)).As(typeof(IBaseRepositoryAdmin<>)).InstancePerDependency();
            builder.RegisterType<UnitOfWorkAdmin>().As<IUnitOfWorkAdmin>().InstancePerLifetimeScope();
            
            builder.RegisterType<HttpContextAccessor>().As<IHttpContextAccessor>().SingleInstance();


            //builder.RegisterType<Logger>()
            //    .As<ILoggerApplication>()
            //    .WithParameter(new NamedParameter("projectName", System.Reflection.Assembly.GetEntryAssembly().GetName().Name))
            //    .SingleInstance();



            //builder.RegisterType<Ferreycorp.Extension.Logging.Logging>().As<ILogging>().SingleInstance();

            return builder.Build();
        }
    }
}
