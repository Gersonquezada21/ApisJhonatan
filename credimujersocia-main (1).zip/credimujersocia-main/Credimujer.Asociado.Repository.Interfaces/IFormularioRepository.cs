﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Dto.Socia;
using Credimujer.Asociado.Repository.Interfaces.Data;

namespace Credimujer.Asociado.Repository.Interfaces
{
    public interface IFormularioRepository:IBaseRepository<FormularioEntity>
    {
        Task<DatoFormularioDto> ObtenerPorSociaId(int sociaId);
    }
}
