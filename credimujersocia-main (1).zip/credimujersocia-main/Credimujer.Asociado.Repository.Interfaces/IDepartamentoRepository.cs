﻿using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Dto.Base;
using Credimujer.Asociado.Repository.Interfaces.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Repository.Interfaces
{
    public interface IDepartamentoRepository:IBaseRepository<DepartamentoEntity>
    {
        Task<List<DropdownDto>> ListarDropdown();
    }
}
