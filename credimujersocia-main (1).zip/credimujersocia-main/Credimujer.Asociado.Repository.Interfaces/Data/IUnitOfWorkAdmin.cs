﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Interfaces.Data
{
    public interface IUnitOfWorkAdmin : IDisposable
    {

        void Dispose();
        void SaveChanges();
        Task SaveChangesAsync();
        void Dispose(bool disposing);
        T Repository<T>() where T : class;
        DbSet<TEntity> Set<TEntity>() where TEntity : class;
        DbContext Get();
    }
}
