﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Dto.Base;
using Credimujer.Asociado.Dto.Base.Catalogo;
using Credimujer.Asociado.Repository.Interfaces.Data;

namespace Credimujer.Asociado.Repository.Interfaces
{
    public interface ICatalogoDetalleRepository:IBaseRepository<CatalogoDetalleEntity>
    {
        Task<CatalogoDetalleDto> ObtenerPorCodigo(string codigo);
        Task<List<CatalogoDetalleDto>> ListarPorListaCodigo(List<string> listaCodigo);
        Task<List<CatalogoDetalleDto>> ListarPorCatalogoCodigo(string codigo);
        Task<List<CatalogoDetalleDto>> ListarPorListaCatalogoCodigo(List<string> listaCodigo);

        Task<List<DropdownDto>> ListarPorCatalogoCodigoParaDropDown(string codigo);
    }
}
