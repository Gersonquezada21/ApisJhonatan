﻿using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Interfaces.Data;

namespace Credimujer.Asociado.Repository.Interfaces
{
    public interface ICatalogoRepository:IBaseRepository<CatalogoEntity>
    {
        
    }
}
