﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Interfaces.Data;

namespace Credimujer.Asociado.Repository.Interfaces
{
    public interface IProvinciaRepository:IBaseRepository<ProvinciaEntity>

    {

    }
}
