﻿using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Interfaces.Configuration.Base
{
    public interface IEntityConfiguration<T> : IEntityTypeConfiguration<T> where T : class
    {
        
    }
}
