﻿using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Dto.PreSolicitud;
using Credimujer.Asociado.Repository.Interfaces.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Repository.Interfaces
{
    public interface IPreSolicitudRepository : IBaseRepository<PreSolicitudEntity>
    {
        Task<List<MostrarPresolicitudDto>> ListarPorSociaId(int id);
        Task<List<MostrarUltimaPresolicitudDto>> ListarPresolicitudPorMesYSocia(int id);
    }
}