﻿using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Domain.Models.Entities.Procedure;
using Credimujer.Asociado.Dto.ServicioInterno.ServicioSocia;
using Credimujer.Asociado.Dto.Socia;
using Credimujer.Asociado.Repository.Interfaces.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Repository.Interfaces
{
    public interface ISociaRepository : IBaseRepository<SociaEntity>
    {
        Task<bool> SociaTieneFormulario(string nroDni);

        Task<int> ObtenerIdPorNroDocumento(string nroDni);

        List<SPVisualizarSolicitudes> visualizarSolicitud(string codigoSocia);

        Task<DatoPersonalDto> ObtenerDatoPersonalPorId(int idSocia);

        Task<SociaIdYExisteFormularioDto> ObtenerDatoParaLoginPorNumeroDocumento(string nroDocumento);

        List<ResumenProductoDto> ResumenProducto(string codigoSocia);
    }
}