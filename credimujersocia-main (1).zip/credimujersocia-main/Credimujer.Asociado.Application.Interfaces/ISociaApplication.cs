﻿using Credimujer.Asociado.Common.Base;
using System.Threading.Tasks;
using Credimujer.Asociado.Model.Socia;
using Credimujer.Asociado.Model.Socia.Registro;

namespace Credimujer.Asociado.Application.Interfaces
{
    public interface ISociaApplication
    {
        Task<ResponseDTO> CargarDatoComun(CargarDataComunModel model);

        Task<ResponseDTO> SociaTieneFormulario();

        Task<ResponseDTO> RegistrarFormulario(FormularioModel model);

        Task<ResponseDTO> RegistrarNuevaSocia(SociaModel model);

        Task<ResponseDTO> CargarDepartamentoDisponible();

        Task<ResponseDTO> ObtenerSociaId(string nroDocumento);

        Task<ResponseDTO> ObtenerPerfilConFormulario();

        Task<ResponseDTO> ObtenerFormulario();

        Task<ResponseDTO> ActualizarFormulario(FormularioActualizarModel model);

        Task<ResponseDTO> ResumenProducto();
    }
}