﻿using Credimujer.Asociado.Common.Base;
using Credimujer.Asociado.Model.PreSolicitud;
using Credimujer.Asociado.Model.PreSolicitud.Registro;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Application.Interfaces
{
    public interface IPreSolicitudApplication
    {
        Task<ResponseDTO> ListarPreSolicitudPorSocia();

        Task<ResponseDTO> RegistrarPreSolicitud(PreSolicitudModel model);

        Task<ResponseDTO> CargarDatoComun(CargarDataComunModel model);
        Task<ResponseDTO> ListaUltimaPresolicitud();
    }
}