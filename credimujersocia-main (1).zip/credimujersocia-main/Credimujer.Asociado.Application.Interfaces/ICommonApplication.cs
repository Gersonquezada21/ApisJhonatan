﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Common.Base;

namespace Credimujer.Asociado.Application.Interfaces
{
    public interface ICommonApplication
    {
        Task<ResponseDTO> ObtenerProvincia(string codigoDepartamento);
        Task<ResponseDTO> ObtenerDistrito(string codigoDepartamento, string codigoProv);
    }
}
