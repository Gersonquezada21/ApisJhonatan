﻿using System.Collections.Generic;
using Credimujer.Asociado.Domain.Models.Base;

namespace Credimujer.Asociado.Domain.Models.Entities
{
    public class CatalogoDetalleEntity : BaseEntity
    {
        public CatalogoDetalleEntity()
        {
            SociaEstado = new List<SociaEntity>();
            SociaSucursal = new List<SociaEntity>();
            SociaEstadoCivil = new List<FormularioEntity>();
            SociaGradoInstruccion = new List<FormularioEntity>();
            SociaSituacionDomicilio = new List<FormularioEntity>();
            SociaEntidadBancaria = new List<FormularioEntity>();
            PreSolicitudEstado = new List<PreSolicitudEntity>();
            PreSolicitudEntidadBancaria = new List<PreSolicitudEntity>();
            PreSolicitudTipoCredito = new List<PreSolicitudEntity>();
            PreSolicitudSubTipoCredito = new List<PreSolicitudEntity>();
        }

        public int Id { get; set; }
        public int CatalogoId { get; set; }
        public string Codigo { get; set; }
        public string Valor { get; set; }
        public string Descripcion { get; set; }
        public int Orden { get; set; }

        public virtual CatalogoEntity Catalogo { get; set; }
        public virtual ICollection<SociaEntity> SociaEstado { get; set; }
        public virtual ICollection<SociaEntity> SociaSucursal { get; set; }
        public virtual ICollection<FormularioEntity> SociaEstadoCivil { get; set; }
        public virtual ICollection<FormularioEntity> SociaGradoInstruccion { get; set; }
        public virtual ICollection<FormularioEntity> SociaSituacionDomicilio { get; set; }
        public virtual ICollection<FormularioEntity> SociaEntidadBancaria { get; set; }

        public virtual ICollection<PreSolicitudEntity> PreSolicitudEstado { get; set; }
        public virtual ICollection<PreSolicitudEntity> PreSolicitudEntidadBancaria { get; set; }
        public virtual ICollection<PreSolicitudEntity> PreSolicitudTipoCredito { get; set; }
        public virtual ICollection<PreSolicitudEntity> PreSolicitudSubTipoCredito { get; set; }
    }
}