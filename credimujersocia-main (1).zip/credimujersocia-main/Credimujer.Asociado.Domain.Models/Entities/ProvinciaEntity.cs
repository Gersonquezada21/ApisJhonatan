﻿namespace Credimujer.Asociado.Domain.Models.Entities
{
    public class ProvinciaEntity
    {
        public string Codigo { get; set; }
        public string DepartamentoCodigo { get; set; }
        public string Descripcion { get; set; }
    }
}
