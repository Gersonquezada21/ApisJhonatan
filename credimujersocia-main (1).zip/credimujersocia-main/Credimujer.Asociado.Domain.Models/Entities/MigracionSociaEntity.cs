﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Domain.Models.Entities
{
    public class MigracionSociaEntity
    {
        public string CodSocia { get; set; }
        public string NroDni { get; set; }
    }
}
