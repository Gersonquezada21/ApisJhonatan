﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Domain.Models.Entities.Procedure
{
    [Keyless]
    public class SPResumenProducto
    {
        public DateTime FEC_DESEMBOLSO { get; set; }
        public string tipo { get; set; }
        public decimal TotalPagar { get; set; }
        public string Cuota { get; set; }
        public DateTime FEC_VENCIM { get; set; }
        public string Estado { get; set; }
    }
}