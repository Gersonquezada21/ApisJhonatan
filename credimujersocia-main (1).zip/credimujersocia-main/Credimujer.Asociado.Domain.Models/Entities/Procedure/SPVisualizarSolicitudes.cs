﻿using Microsoft.EntityFrameworkCore;
using System;

namespace Credimujer.Asociado.Domain.Models.Entities.Procedure
{
    [Keyless]
    public class SPVisualizarSolicitudes
    {
        public int NUM_PRO_CRE { get; set; }
        public string MAE_GRP { get; set; }
        public DateTime FEC_REGISTRO { get; set; }
        public decimal MTO_APROBADO { get; set; }
        public decimal MTO_DESEMBOLSADO { get; set; }
        public string TIP_SITUACION { get; set; }
        public string cod_ciclo_fk { get; set; }
        public string NOM_ABC { get; set; }
        public DateTime FEC_DESEMB { get; set; }
        public string TARIFA { get; set; }
        public string ENTI_DESEMB { get; set; }
    }
}
