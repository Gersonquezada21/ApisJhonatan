﻿using Credimujer.Asociado.Domain.Models.Base;

namespace Credimujer.Asociado.Domain.Models.Entities
{
    public class PreSolicitudEntity : BaseEntity
    {
        public int Id { get; set; }
        public int Nro { get; set; }
        public int SociaId { get; set; }
        public int EntidadBancariaId { get; set; }
        public int Plazo { get; set; }
        public int? PlazoGracia { get; set; }
        public decimal Monto { get; set; }
        public int? EstadoId { get; set; }
        public int? TipoCreditoId { get; set; }
        public int? SubTipoCreditoId { get; set; }
        public virtual CatalogoDetalleEntity Estado { get; set; }
        public virtual CatalogoDetalleEntity EntidadBancaria { get; set; }
        public virtual CatalogoDetalleEntity TipoCredito { get; set; }
        public virtual CatalogoDetalleEntity SubTipoCredito { get; set; }
        public virtual SociaEntity Socia { get; set; }
    }
}