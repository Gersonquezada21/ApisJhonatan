﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace Credimujer.Asociado.Domain.Models.Entities
{
    public class SFD_SOCIACOMPLETAEntity
    {
        public string CodSocia { get; set; }
        public string CodSucursal { get; set; }
        public string NroDni { get; set; }
        public string Nombres { get; set; }
        public string Apaterno { get; set; }
        public string Amaterno { get; set; }
        public string Sexo { get; set; }
        public string Ecivil { get; set; }
        public string CodCiiu { get; set; }
        public string DesCiiu { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string NacCodDepa { get; set; }
        public string NacDesDepa { get; set; }
        public string NacCodProvi { get; set; }
        public string NacDesProvi { get; set; }
        public string NacLugar { get; set; }
        public DateTime FechaIns { get; set; }
        public DateTime FechaInicio { get; set; }
        public string LabCodDepa { get; set; }
        public string LabDesDepa { get; set; }
        public string LabCodProvi { get; set; }
        public string LabDesProvi { get; set; }
        public string LabCodDistri { get; set; }
        public string LabDesDistri { get; set; }
        public string LabCodLocal { get; set; }
        public string LabDesLocal { get; set; }
        public string LabDireccion { get; set; }
        public string LabNombreNegocio { get; set; }
        public string DirecCodDepa { get; set; } 
        public string DirecDepartamento { get; set; }
        public string DirecCodProvi { get; set; }
        public string DirecProvincia { get; set; }
        public string DirecCodDistrito { get; set; }
        public string DirecDistrito { get; set; }
        public string DirecCodLoca { get; set; }
        public string DirecLocalidad { get; set; }
        public string DirNombreCalle { get; set; }
        public string EstadoBaja { get; set; }
        public string CodAsesor { get; set; }
        public string NomAsesor { get; set; }
        public string ClaseSoc { get; set; }
        public string SecEcoAjus { get; set; }
        public int Edad { get; set; }
        public string ApeNombre { get; set; }
        public string SececoNro { get; set; }
        public string CodPromotora { get; set; }
        public string Nompromotora { get; set; }
        public int Codgrado { get; set; }
        public string DesGrado { get; set; }
        public string ConciiuCredi { get; set; }
        public string Celular { get; set; }
        public string NomSucursal { get; set; }
        public string NroDep { get; set; }
        public string TelefFijo { get; set; }
    }
}
