﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using Credimujer.Asociado.Application.Interfaces;
using Credimujer.Asociado.Common;
using Credimujer.Asociado.Common.Base;
using Credimujer.Asociado.Common.Exceptions;
using Credimujer.Asociado.Model.Socia;
using Credimujer.Asociado.Model.Socia.Registro;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Credimujer.Asociado.Api.Controllers
{
    //[Authorize(AuthenticationSchemes = AuthenticateScheme.CrediMujerAsociado)]
    [Route("Socia")]
    [ApiController]
    public class SociaController
    {
        private readonly Lazy<ISociaApplication> _sociaApplication;
        private readonly Lazy<ICommonApplication> _commonApplication;

        public SociaController(ILifetimeScope lifetimeScope, IOptions<AppSetting> appSettings)
        {
            _sociaApplication = new Lazy<ISociaApplication>(() => lifetimeScope.Resolve<ISociaApplication>());
            _commonApplication = new Lazy<ICommonApplication>(() => lifetimeScope.Resolve<ICommonApplication>());
        }

        #region properties

        private ISociaApplication SociaApplication => _sociaApplication.Value;
        private ICommonApplication CommonApplication => _commonApplication.Value;

        #endregion properties

        [HttpGet("CargarDatoComun")]
        public async Task<JsonResult> CargarDatoComun([FromQuery] CargarDataComunModel model)
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.CargarDatoComun(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpGet("SociaTieneFormulario")]
        public async Task<JsonResult> SociaTieneFormulario()
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.SociaTieneFormulario();
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpPost("RegistrarFormulario")]
        public async Task<JsonResult> RegistrarFormulario(FormularioModel model)
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.RegistrarFormulario(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpGet("ObtenerProvincia/{codigoDepartamento}")]
        public async Task<JsonResult> ObtenerProvincia(string codigoDepartamento)
        {
            ResponseDTO response;
            try
            {
                response = await CommonApplication.ObtenerProvincia(codigoDepartamento);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpGet("ObtenerDistrito/{codigoDepartamento}/{codigoProv}")]
        public async Task<JsonResult> ObtenerDistrito(string codigoDepartamento, string codigoProv)
        {
            ResponseDTO response;
            try
            {
                response = await CommonApplication.ObtenerDistrito(codigoDepartamento, codigoProv);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [AllowAnonymous]
        [HttpPost("RegistrarSocia")]
        public async Task<JsonResult> RegistrarSocia(SociaModel model)
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.RegistrarNuevaSocia(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [AllowAnonymous]
        [HttpGet("DepartamentoDisponibles")]
        public async Task<JsonResult> DepartamentoDisponibles()
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.CargarDepartamentoDisponible();
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpGet("ObtenerPerfilConFormulario")]
        public async Task<JsonResult> ObtenerPerfilConFormulario()
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.ObtenerPerfilConFormulario();
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpGet("ObtenerFormulario")]
        public async Task<JsonResult> ObtenerFormulario()
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.ObtenerFormulario();
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpPost("ActualizarFormulario")]
        public async Task<JsonResult> ActualizarFormulario(FormularioActualizarModel model)
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.ActualizarFormulario(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpGet("ResumenProducto")]
        public async Task<JsonResult> ResumenProducto()
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.ResumenProducto();
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }
    }
}