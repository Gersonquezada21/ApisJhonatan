﻿using Autofac;
using Credimujer.Asociado.Api.Attributes;
using Credimujer.Asociado.Application.Interfaces;
using Credimujer.Asociado.Common;
using Credimujer.Asociado.Common.Base;
using Credimujer.Asociado.Common.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Api.Controllers.ServicioInterno
{
    [Route("ServicioSocia")]
    [ApiKey]
    public class ServicioSociaController
    {
        private readonly Lazy<ISociaApplication> _sociaApplication;
        public ServicioSociaController(ILifetimeScope lifetimeScope, IOptions<AppSetting> appSettings)
        {
            _sociaApplication = new Lazy<ISociaApplication>(() => lifetimeScope.Resolve<ISociaApplication>());
            
        }
        private ISociaApplication SociaApplication => _sociaApplication.Value;
        [HttpGet("ObtenerSociaId")]
        public async Task<JsonResult> ObtenerSociaId(string nroDocumento)
        {
            ResponseDTO response;
            try
            {
                response = await SociaApplication.ObtenerSociaId(nroDocumento);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };

            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };

            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };

            }
            return new JsonResult(response);
        }

    }
}
