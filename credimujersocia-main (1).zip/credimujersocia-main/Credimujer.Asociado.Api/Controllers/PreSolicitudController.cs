﻿using Autofac;
using Credimujer.Asociado.Application.Interfaces;
using Credimujer.Asociado.Common;
using Credimujer.Asociado.Common.Base;
using Credimujer.Asociado.Common.Exceptions;
using Credimujer.Asociado.Model.PreSolicitud;
using Credimujer.Asociado.Model.PreSolicitud.Registro;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Api.Controllers
{
    [Authorize(AuthenticationSchemes = AuthenticateScheme.CrediMujerAsociado)]
    [Route("Presolicitud")]
    [ApiController]
    public class PreSolicitudController
    {
        private readonly Lazy<ICommonApplication> _commonApplication;
        private readonly Lazy<IPreSolicitudApplication> _preSolicitudApplication;

        public PreSolicitudController(ILifetimeScope lifetimeScope, IOptions<AppSetting> appSettings)
        {
            _preSolicitudApplication = new Lazy<IPreSolicitudApplication>(() => lifetimeScope.Resolve<IPreSolicitudApplication>());
            _commonApplication = new Lazy<ICommonApplication>(() => lifetimeScope.Resolve<ICommonApplication>());
        }

        #region properties

        private IPreSolicitudApplication PreSolicitudApplication => _preSolicitudApplication.Value;
        private ICommonApplication CommonApplication => _commonApplication.Value;

        #endregion properties

        [HttpGet("CargarDatoComun")]
        public async Task<JsonResult> CargarDatoComun([FromQuery] CargarDataComunModel model)
        {
            ResponseDTO response;
            try
            {
                response = await PreSolicitudApplication.CargarDatoComun(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpPost("Registrar")]
        public async Task<JsonResult> Registrar(PreSolicitudModel model)
        {
            ResponseDTO response;
            try
            {
                response = await PreSolicitudApplication.RegistrarPreSolicitud(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpGet("Consultar")]
        public async Task<JsonResult> ListarPreSolicitudPorSocia()
        {
            ResponseDTO response;
            try
            {
                response = await PreSolicitudApplication.ListarPreSolicitudPorSocia();
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }
        [HttpGet("ListarUltimaPresolicitud")]
        public async Task<JsonResult> ListarUltimaPresolicitud()
        {
            ResponseDTO response;
            try
            {
                response = await PreSolicitudApplication.ListaUltimaPresolicitud();
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }
    }
}