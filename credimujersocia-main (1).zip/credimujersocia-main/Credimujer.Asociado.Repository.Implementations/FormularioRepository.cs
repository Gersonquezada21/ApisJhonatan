﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Dto.Socia;
using Credimujer.Asociado.Repository.Implementations.Data;
using Credimujer.Asociado.Repository.Implementations.Data.Base;
using Credimujer.Asociado.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations
{
    public class FormularioRepository: BaseRepository<FormularioEntity>, IFormularioRepository
    {
        private readonly DataContext _context;
        public FormularioRepository(DataContext context) : base(context)
        {
            _context = context;
        }

        public async Task<DatoFormularioDto> ObtenerPorSociaId(int sociaId) {
            return await _context.Formulario.Where(p => p.EstadoFila && p.SociaId == sociaId)
                .Select(s => new DatoFormularioDto {
                    EstadoCivilId =s.EstadoCivilId ,
                    Celular =s.Celular ,
                    ActividadEconomica =s.ActividadEconomica ,
                    DepartamentoCode =s.Ubicacion.Substring(0,2) ,
                    ProvinciaCode = s.Ubicacion.Substring(2, 2),
                    DistritoCode = s.Ubicacion.Substring(4, 2),
                    Direccion =s.Direccion ,
                    Referencia =s.Referencia ,
                    SituacionDomicilioId =s.SituacionDomicilioId ,
                    EntidadBancariaId =s.EntidadBancariaId ,
                    NroCuenta =s.NroCuenta ,

                    DepartamentoNegocioCode = s.UbicacionNegocio.Substring(0, 2),
                    ProvinciaNegocioCode = s.UbicacionNegocio.Substring(2, 2),
                    DistritoNegocioCode = s.UbicacionNegocio.Substring(4, 2),
                    DireccionNegocio =s.DireccionNegocio ,
                    ReferenciaNegocio =s.ReferenciaNegocio ,
                })
                .FirstOrDefaultAsync();
        }
    }
}
