﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Implementations.Data;
using Credimujer.Asociado.Repository.Implementations.Data.Base;
using Credimujer.Asociado.Repository.Interfaces;

namespace Credimujer.Asociado.Repository.Implementations
{
    public class MigracionSociaRepository : BaseRepository<MigracionSociaEntity>, IMigracionSociaRepository
    {
        private readonly DataContext _context;
        public MigracionSociaRepository(DataContext context) : base(context)
        {
            _context = context;
        }
    }
}
