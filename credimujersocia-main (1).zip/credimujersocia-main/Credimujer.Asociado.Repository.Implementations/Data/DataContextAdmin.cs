﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Implementations.Configurations;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations.Data
{
    public class DataContextAdmin : DbContext
    {
        public DataContextAdmin(DbContextOptions<DataContextAdmin> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {

            builder.ApplyConfiguration(new SFD_SOCIACOMPLETAConfiguration());


        }
        public DbSet<SFD_SOCIACOMPLETAEntity> SFD_SOCIACOMPLETA { get; set; }


    }
}
