﻿using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Domain.Models.Entities.Procedure;
using Credimujer.Asociado.Repository.Implementations.Configurations;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {
        }

        public virtual DbSet<SPVisualizarSolicitudes> SPVisualizarSolicitudes { get; set; }
        public virtual DbSet<SPResumenProducto> SPResumenProducto { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfiguration(new SociaConfiguration(builder));
            builder.ApplyConfiguration(new DepartamentoConfiguration());
            builder.ApplyConfiguration(new ProvinciaConfiguration());
            builder.ApplyConfiguration(new DistritoConfiguration());
            builder.ApplyConfiguration(new FormularioConfiguration(builder));
            builder.ApplyConfiguration(new CatalogoConfiguration(builder));
            builder.ApplyConfiguration(new CatalogoDetalleConfiguration(builder));
            builder.ApplyConfiguration(new PreSolicitudConfiguration(builder));
        }

        public DbSet<SociaEntity> Socia { get; set; }
        public DbSet<DepartamentoEntity> Departamento { get; set; }
        public DbSet<ProvinciaEntity> Provincia { get; set; }
        public DbSet<DistritoEntity> Distrito { get; set; }
        public DbSet<FormularioEntity> Formulario { get; set; }
        public DbSet<CatalogoEntity> Catalogo { get; set; }
        public DbSet<CatalogoDetalleEntity> CatalogoDetalle { get; set; }
        public DbSet<PreSolicitudEntity> PreSolicitud { get; set; }
    }
}