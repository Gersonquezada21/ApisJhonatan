﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Implementations.Data;
using Credimujer.Asociado.Repository.Implementations.Data.Base;
using Credimujer.Asociado.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations
{
    public class SFD_SOCIACOMPLETARepository : BaseRepositoryAdmin<SFD_SOCIACOMPLETAEntity>, ISFD_SOCIACOMPLETARepository
    {
        private readonly DataContextAdmin _context;

        public SFD_SOCIACOMPLETARepository(DataContextAdmin context) : base(context)
        {
            _context = context;
        }

        public async Task<List<SFD_SOCIACOMPLETAEntity>> ObtenerDuplicados()
        {
          return  await _context.SFD_SOCIACOMPLETA.Where(p=>p.EstadoBaja=="N")
              .GroupBy(x => x.NroDni)
                .Where(g => g.Count() > 1)
                .Select(y => new SFD_SOCIACOMPLETAEntity()
                {
                    NroDni = y.Key
                })
                .ToListAsync();
        }
        public async Task<List<SFD_SOCIACOMPLETAEntity>> ObtenerTodos()
        {
            return await _context.SFD_SOCIACOMPLETA.Where(p => p.EstadoBaja == "N").ToListAsync();
        }
    }
}
