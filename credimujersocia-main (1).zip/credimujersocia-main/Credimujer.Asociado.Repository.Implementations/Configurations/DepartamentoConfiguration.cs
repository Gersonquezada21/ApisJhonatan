﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Implementations.Configurations.Base;
using Credimujer.Asociado.Repository.Interfaces.Configuration.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations.Configurations
{
    public class DepartamentoConfiguration: IEntityConfiguration<DepartamentoEntity>
    {
        //public DepartamentoConfiguration(ModelBuilder modelBuilder)
        //{
        //    var entityBuilder = modelBuilder.Entity<DepartamentoEntity>();
        //    entityBuilder.ToTable("DEPARTAMENTO");
        //    entityBuilder.HasNoKey();
        //    entityBuilder.Property(c => c.Codigo).HasColumnName("VC_CODIGO");
        //    entityBuilder.Property(c => c.Descripcion).HasColumnName("VC_DESCRIPCION");
            
        //    Configure(entityBuilder);
        //}

        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<DepartamentoEntity> entityBuilder)
        {
            
            entityBuilder.ToTable("DEPARTAMENTO");
            entityBuilder.HasNoKey();
            entityBuilder.Property(c => c.Codigo).HasColumnName("VC_CODIGO");
            entityBuilder.Property(c => c.Descripcion).HasColumnName("VC_DESCRIPCION");

        }
    }
}
