﻿using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Implementations.Configurations.Base;
using Credimujer.Asociado.Repository.Implementations.Data;
using Credimujer.Asociado.Repository.Interfaces.Configuration.Base;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Repository.Implementations.Configurations
{
    public class PreSolicitudConfiguration : EntityConfiguration<PreSolicitudEntity>
    {
        public PreSolicitudConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<PreSolicitudEntity>();
            entityBuilder.ToTable("ASO_PRE_SOLICITUD");
            entityBuilder.HasKey(c => c.Id);
            entityBuilder.Property(c => c.Id).HasColumnName("IN_ID");
            entityBuilder.Property(c => c.Nro).HasColumnName("IN_NRO");
            entityBuilder.Property(c => c.SociaId).HasColumnName("IN_SOCIA_ID");
            entityBuilder.Property(c => c.EntidadBancariaId).HasColumnName("IN_ENTIDAD_BANCARIA_ID");
            entityBuilder.Property(c => c.Plazo).HasColumnName("IN_PLAZO");
            entityBuilder.Property(c => c.PlazoGracia).HasColumnName("IN_PLAZO_GRACIA");
            entityBuilder.Property(c => c.Monto).HasColumnName("DC_MONTO");
            entityBuilder.Property(c => c.EstadoId).HasColumnName("IN_ESTADO");
            entityBuilder.Property(c => c.TipoCreditoId).HasColumnName("IN_TIPO_CREDITO_ID");
            entityBuilder.Property(c => c.SubTipoCreditoId).HasColumnName("IN_SUBTIPO_CREDITO_ID");

            entityBuilder.HasOne(c => c.EntidadBancaria).WithMany(m => m.PreSolicitudEntidadBancaria).HasForeignKey(f => f.EntidadBancariaId);
            entityBuilder.HasOne(c => c.Estado).WithMany(m => m.PreSolicitudEstado).HasForeignKey(f => f.EstadoId);
            entityBuilder.HasOne(c => c.TipoCredito).WithMany(m => m.PreSolicitudTipoCredito).HasForeignKey(f => f.TipoCreditoId);
            entityBuilder.HasOne(c => c.Socia).WithMany(m => m.ListaPreSolicitud).HasForeignKey(f => f.SociaId);
            entityBuilder.HasOne(c => c.SubTipoCredito).WithMany(m => m.PreSolicitudSubTipoCredito).HasForeignKey(f => f.SubTipoCreditoId);
            Configure(entityBuilder);
        }
    }
}