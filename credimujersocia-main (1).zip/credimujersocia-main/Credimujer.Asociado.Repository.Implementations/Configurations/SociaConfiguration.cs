﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Implementations.Configurations.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations.Configurations
{
    public class SociaConfiguration : EntityConfiguration<SociaEntity>
    {
        public SociaConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<SociaEntity>();
            entityBuilder.ToTable("ASO_SOCIA");
            entityBuilder.HasKey(c => c.Id);
            entityBuilder.Property(c => c.Id).HasColumnName("IN_ID");
            entityBuilder.Property(c => c.NroDni).HasColumnName("VC_NRODNI");
            entityBuilder.Property(c => c.ApellidoPaterno).HasColumnName("VC_APELLIDOPAT");
            entityBuilder.Property(c => c.ApellidoMaterno).HasColumnName("VC_APELLIDOMAT");
            entityBuilder.Property(c => c.Nombre).HasColumnName("VC_NOMBRES");
            entityBuilder.Property(c => c.Celular).HasColumnName("VC_CELULAR");
            entityBuilder.Property(c => c.Telefono).HasColumnName("VC_TLF_FIJO");
            entityBuilder.Property(c => c.EntidadBancario).HasColumnName("VC_ENTIDAD_BANCO");
            entityBuilder.Property(c => c.NroCuenta).HasColumnName("VC_NRO_CTA");
            
            entityBuilder.Property(c => c.EstadoId).HasColumnName("IN_ESTADO");
            entityBuilder.Property(c => c.CodigoCliente).HasColumnName("VC_COD_CLI");
            entityBuilder.Property(c => c.SucursalId).HasColumnName("IN_SUCURSAL_ID");
            entityBuilder.HasOne(c => c.Estado).WithMany(m => m.SociaEstado).HasForeignKey(f => f.EstadoId);
            entityBuilder.HasOne(c => c.Sucursal).WithMany(m => m.SociaSucursal).HasForeignKey(f => f.SucursalId);
            Configure(entityBuilder);
        }
    }
}