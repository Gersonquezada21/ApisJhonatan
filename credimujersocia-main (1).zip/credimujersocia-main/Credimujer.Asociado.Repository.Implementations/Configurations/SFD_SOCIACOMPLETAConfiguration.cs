﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Interfaces.Configuration.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations.Configurations
{
    public class SFD_SOCIACOMPLETAConfiguration:IEntityConfiguration<SFD_SOCIACOMPLETAEntity>
    {
        public void Configure(
            Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<SFD_SOCIACOMPLETAEntity> entityBuilder)
        {
            entityBuilder.ToTable("SFD_SOCIACOMPLETA");
            entityBuilder.HasNoKey();
            entityBuilder.Property(c => c.CodSocia).HasColumnName("CODSOCIA");
            entityBuilder.Property(c => c.CodSucursal).HasColumnName("CODSUCURSAL_SOC");
            entityBuilder.Property(c => c.NroDni).HasColumnName("NRODNI");
            entityBuilder.Property(c => c.Nombres).HasColumnName("NOMBRES");
            entityBuilder.Property(c => c.Apaterno).HasColumnName("APATERNO");
            entityBuilder.Property(c => c.Amaterno).HasColumnName("AMATERNO");
            entityBuilder.Property(c => c.Sexo).HasColumnName("SEXO");
            entityBuilder.Property(c => c.Ecivil).HasColumnName("ECIVIL");
            entityBuilder.Property(c => c.CodCiiu).HasColumnName("CODCIIU");
            entityBuilder.Property(c => c.DesCiiu).HasColumnName("DESCIIU");
            entityBuilder.Property(c => c.FechaNacimiento).HasColumnName("FECHANACIMIENTO");
            entityBuilder.Property(c => c.NacCodDepa).HasColumnName("NAC_CODDEPA");
            entityBuilder.Property(c => c.NacDesDepa).HasColumnName("NAC_DESDEPA");
            entityBuilder.Property(c => c.NacCodProvi).HasColumnName("NAC_CODPROVI");
            entityBuilder.Property(c => c.NacDesProvi).HasColumnName("NAC_DESPROVI");
            entityBuilder.Property(c => c.NacLugar).HasColumnName("NAC_LUGAR");
            entityBuilder.Property(c => c.FechaIns).HasColumnName("FECHAINSCRIPCION");
            entityBuilder.Property(c => c.FechaInicio).HasColumnName("FECHAINICIO");
            entityBuilder.Property(c => c.LabCodDepa).HasColumnName("LAB_CODDEPA");
            entityBuilder.Property(c => c.LabDesDepa).HasColumnName("LAB_DESDEPA");
            entityBuilder.Property(c => c.LabCodProvi).HasColumnName("LAB_CODPROVI");
            entityBuilder.Property(c => c.LabDesProvi).HasColumnName("LAB_DESPROVI");
            entityBuilder.Property(c => c.LabCodDistri).HasColumnName("LAB_CODDISTRI");
            entityBuilder.Property(c => c.LabDesDistri).HasColumnName("LAB_DESDISTRI");
            entityBuilder.Property(c => c.LabCodLocal).HasColumnName("LAB_CODLOCAL");
            entityBuilder.Property(c => c.LabDesLocal).HasColumnName("LAB_DESLOCAL");
            entityBuilder.Property(c => c.LabDireccion).HasColumnName("LAB_DIRECCION");
            entityBuilder.Property(c => c.LabNombreNegocio).HasColumnName("LAB_NOMBRENEGOCIO");
            entityBuilder.Property(c => c.DirecCodDepa).HasColumnName("DIREC_CODDEPA");
            entityBuilder.Property(c => c.DirecDepartamento).HasColumnName("DIREC_DEPARTAMENTO");
            entityBuilder.Property(c => c.DirecCodProvi).HasColumnName("DIREC_CODPROVI");
            entityBuilder.Property(c => c.DirecProvincia).HasColumnName("DIREC_PROVINCIA");
            entityBuilder.Property(c => c.DirecCodDistrito).HasColumnName("DIREC_CODDISTRI");
            entityBuilder.Property(c => c.DirecDistrito).HasColumnName("DIREC_DISTRITO");
            entityBuilder.Property(c => c.DirecCodLoca).HasColumnName("DIREC_CODLOCAL");
            entityBuilder.Property(c => c.DirecLocalidad).HasColumnName("DIREC_LOCALIDAD");
            entityBuilder.Property(c => c.DirNombreCalle).HasColumnName("DIR_NOMBRECALLE");
            entityBuilder.Property(c => c.EstadoBaja).HasColumnName("ESTADOBAJA");
            entityBuilder.Property(c => c.CodAsesor).HasColumnName("CODASESOR");
            entityBuilder.Property(c => c.NomAsesor).HasColumnName("NOMASESOR");
            entityBuilder.Property(c => c.ClaseSoc).HasColumnName("CLASE_SOC");
            entityBuilder.Property(c => c.SecEcoAjus).HasColumnName("SECECO_AJUS");
            entityBuilder.Property(c => c.Edad).HasColumnName("EDADACTUAL");
            entityBuilder.Property(c => c.ApeNombre).HasColumnName("APELLIDOSNOMBRES");
            entityBuilder.Property(c => c.SececoNro).HasColumnName("SECECO_NOR");
            entityBuilder.Property(c => c.CodPromotora).HasColumnName("CODPROMOTORA_IND");
            entityBuilder.Property(c => c.Nompromotora).HasColumnName("NOMPROMOTORA_IND");
            entityBuilder.Property(c => c.Codgrado).HasColumnName("CODGRADO");
            entityBuilder.Property(c => c.DesGrado).HasColumnName("DESGRADO");
            entityBuilder.Property(c => c.ConciiuCredi).HasColumnName("CONCIIU_CREDI");
            entityBuilder.Property(c => c.Celular).HasColumnName("CELULAR");
            entityBuilder.Property(c => c.NomSucursal).HasColumnName("NOMSUCURSAL_SOC");
            entityBuilder.Property(c => c.NroDep).HasColumnName("NRODEP");
            entityBuilder.Property(c => c.TelefFijo).HasColumnName("TLF_FIJO");
    }
    }
}
