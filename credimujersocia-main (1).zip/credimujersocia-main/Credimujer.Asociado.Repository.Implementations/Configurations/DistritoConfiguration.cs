﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Implementations.Configurations.Base;
using Credimujer.Asociado.Repository.Interfaces.Configuration.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations.Configurations
{
    public class DistritoConfiguration : IEntityConfiguration<DistritoEntity>
    {
        //public DistritoConfiguration(ModelBuilder modelBuilder)
        //{
        //    var entityBuilder = modelBuilder.Entity<DistritoEntity>();
        //    entityBuilder.ToTable("DISTRITO");
        //    entityBuilder.HasNoKey();
        //    entityBuilder.Property(c => c.Codigo).HasColumnName("VC_CODIGO");
        //    entityBuilder.Property(c => c.DepartamentoCodigo).HasColumnName("VC_DEPARTAMENTO_CODIGO");
        //    entityBuilder.Property(c => c.ProvinciaCodigo).HasColumnName("VC_PROVINCIA_CODIGO");
        //    entityBuilder.Property(c => c.Descripcion).HasColumnName("VC_DESCRIPCION");

        //    Configure(entityBuilder);
        //}
        public void Configure(
            Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<DistritoEntity> entityBuilder)
        {
            entityBuilder.ToTable("DISTRITO");
            entityBuilder.HasNoKey();
            entityBuilder.Property(c => c.Codigo).HasColumnName("VC_CODIGO");
            entityBuilder.Property(c => c.DepartamentoCodigo).HasColumnName("VC_DEPARTAMENTO_CODIGO");
            entityBuilder.Property(c => c.ProvinciaCodigo).HasColumnName("VC_PROVINCIA_CODIGO");
            entityBuilder.Property(c => c.Descripcion).HasColumnName("VC_DESCRIPCION");
        }
    }
}
