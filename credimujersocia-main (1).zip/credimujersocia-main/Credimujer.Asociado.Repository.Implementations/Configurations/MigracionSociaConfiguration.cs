﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Interfaces.Configuration.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations.Configurations
{
    public class MigracionSociaConfiguration : IEntityConfiguration<MigracionSociaEntity>
    {
        public void Configure(
            Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<MigracionSociaEntity> entityBuilder)
        {
            entityBuilder.ToTable("PROVINCIA");
            entityBuilder.HasNoKey();
            entityBuilder.Property(c => c.CodSocia).HasColumnName("CODSOCIA");
            entityBuilder.Property(c => c.NroDni).HasColumnName("NRODNI");
            
        }
    }
}
