﻿using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Dto.PreSolicitud;
using Credimujer.Asociado.Repository.Implementations.Data;
using Credimujer.Asociado.Repository.Implementations.Data.Base;
using Credimujer.Asociado.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Repository.Implementations
{
    public class PreSolicitudRepository : BaseRepository<PreSolicitudEntity>, IPreSolicitudRepository
    {
        private readonly DataContext _context;

        public PreSolicitudRepository(DataContext context) : base(context)
        {
            _context = context;
        }

        public async Task<List<MostrarPresolicitudDto>> ListarPorSociaId(int id)
        {
            return await _context.PreSolicitud.Where(p => p.EstadoFila && p.SociaId == id)
                .Select(s => new MostrarPresolicitudDto()
                {
                    NroSolicitud = s.Nro.ToString("D5"),
                    TipoCredito = s.TipoCredito.Descripcion,
                    MontoSolicitado = s.Monto,
                    Plazo = s.Plazo,
                    EntidadBancaria = s.EntidadBancaria.Descripcion,
                    Estado = s.Estado == null ? "Pendiente" : s.Estado.Descripcion
                }).ToListAsync();
        }
        
        public async Task<List<MostrarUltimaPresolicitudDto>> ListarPresolicitudPorMesYSocia(int id)
        {
            var diaMinima=DateTime.Now.AddDays(-5); 
            if(diaMinima.Month==DateTime.Now.Month)
                diaMinima= new DateTime( DateTime.Now.Year, DateTime.Now.Month, 1);
            return await _context.PreSolicitud
                .Where(p => p.EstadoFila && p.SociaId == id && p.FechaCreacion>= diaMinima
                && p.Estado==null
                )
                .Select(s => new MostrarUltimaPresolicitudDto()
                {
                    TipoCredito = s.TipoCredito.Descripcion,
                    Cuota = s.Plazo.ToString(),
                    Estado = s.Estado == null ? "Pendiente" : s.Estado.Descripcion,
                    //FechaDesembolso = "--"
                }).ToListAsync();
        }
    }
}