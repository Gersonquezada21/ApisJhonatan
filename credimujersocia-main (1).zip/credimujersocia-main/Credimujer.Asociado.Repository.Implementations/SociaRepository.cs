﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Threading.Tasks;
using Credimujer.Asociado.Common;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Domain.Models.Entities.Procedure;
using Credimujer.Asociado.Dto.ServicioInterno.ServicioSocia;
using Credimujer.Asociado.Dto.Socia;
using Credimujer.Asociado.Repository.Implementations.Data;
using Credimujer.Asociado.Repository.Implementations.Data.Base;
using Credimujer.Asociado.Repository.Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Asociado.Repository.Implementations
{
    public class SociaRepository : BaseRepository<SociaEntity>, ISociaRepository
    {
        private readonly DataContext _context;

        public SociaRepository(DataContext context) : base(context)
        {
            this._context = context;
        }

        public async Task<bool> SociaTieneFormulario(string nroDni)
        {
            return await _context.Socia.AnyAsync(p => p.NroDni == nroDni && p.EstadoFila
                            && p.Estado.Codigo == Constants.Core.Catalogo.DetEstadoSocia.Activa
                            && p.Formulario.Any(a => a.EstadoFila)
            );
        }

        public async Task<int> ObtenerIdPorNroDocumento(string nroDni)
        {
            return await _context.Socia.Where(p => p.EstadoFila && p.NroDni == nroDni
                        && p.Estado.Codigo == Constants.Core.Catalogo.DetEstadoSocia.Activa
                )
                .Select(s => s.Id)
                .FirstOrDefaultAsync();
        }

        public async Task<DatoPersonalDto> ObtenerDatoPersonalPorId(int idSocia)
        {

            return await _context.Socia.Where(p => p.EstadoFila && p.Estado.Codigo == Constants.Core.Catalogo.DetEstadoSocia.Activa
                && p.Id == idSocia
            ).Select(s => new DatoPersonalDto()
            {
                BancoComunal = s.Formulario.FirstOrDefault(f=>f.EstadoFila).BancoComunal,
                RegionCodigo = s.Sucursal.Descripcion,
                Nombre = s.Nombre,
                ApePaterno = s.ApellidoPaterno,
                ApeMaterno = s.ApellidoMaterno,
                Celular = s.Celular,
                NroDependiente = s.Formulario.First(f => f.EstadoFila).NroDependiente,
                ActividadEconomica = s.Formulario.First(f => f.EstadoFila).ActividadEconomica,
                ActividadEconomica2 = s.Formulario.First(f => f.EstadoFila).ActividadEconomica2,
                ActividadEconomica3 = s.Formulario.First(f => f.EstadoFila).ActividadEconomica3,
                NroDni = s.NroDni,
                
                EstadoCivilCodigo = s.Formulario.First(f => f.EstadoFila).EstadoCivil.Id.ToString(),
                GradoInstruccionCodigo = s.Formulario.First(f => f.EstadoFila).GradoInstruccion.Id.ToString(),
                
                DepartamentoCodigo = s.Formulario.First(f => f.EstadoFila).Ubicacion.Substring(0,2),
                ProvinciaCodigo = s.Formulario.First(f => f.EstadoFila).Ubicacion.Substring(2, 2),
                DistritoCodigo = s.Formulario.First(f => f.EstadoFila).Ubicacion.Substring(4, 2),

                Direccion = s.Formulario.First(f => f.EstadoFila).Direccion,
                Referencia = s.Formulario.First(f => f.EstadoFila).Referencia,
                SituacionDomicilioCodigo = s.Formulario.First(f => f.EstadoFila).SituacionDomicilio.Id.ToString(),
                EntidadBancariaCodigo = s.Formulario.First(f => f.EstadoFila).EntidadBancaria.Id.ToString(),
                NroCuenta = s.Formulario.First(f => f.EstadoFila).NroCuenta,

                DepartamentoNegocioCodigo = s.Formulario.First(f => f.EstadoFila).UbicacionNegocio.Substring(0, 2),
                ProvinciaNegocioCodigo = s.Formulario.First(f => f.EstadoFila).UbicacionNegocio.Substring(2, 2),
                DistritoNegocioCodigo = s.Formulario.First(f => f.EstadoFila).UbicacionNegocio.Substring(4, 2),
                DireccionNegocio = s.Formulario.First(f => f.EstadoFila).DireccionNegocio,
                ReferenciaNegocio = s.Formulario.First(f => f.EstadoFila).ReferenciaNegocio,
                ActividadPrincipal = s.Formulario.First(f => f.EstadoFila).ActividadPrincipal
            }).FirstOrDefaultAsync();
        }

        public async Task<SociaIdYExisteFormularioDto> ObtenerDatoParaLoginPorNumeroDocumento(string nroDocumento)
        {
            return await _context.Socia.Where(p => p.EstadoFila && p.NroDni == nroDocumento && p.Estado.Codigo == Constants.Core.Catalogo.DetEstadoSocia.Activa)
                .Select(s => new SociaIdYExisteFormularioDto()
                {
                    SociaId = s.Id,
                    TieneFormulario = s.Formulario.Any(a => a.EstadoFila),
                    Sucursal = s.Sucursal.Descripcion
                }).FirstOrDefaultAsync();
        }

        #region Procedure

        public List<SPVisualizarSolicitudes> visualizarSolicitud(string codigoSocia)
        {
            return _context.SPVisualizarSolicitudes.FromSqlInterpolated($"SP_VISUALIZAR_SOLICITUDES '{codigoSocia}'").ToList();
        }

        public List<ResumenProductoDto> ResumenProducto(string codigoSocia)
        {
            return _context.SPResumenProducto.FromSqlInterpolated($"USP_RESUMEN_PRODUCTOS_SOCIA {codigoSocia}").AsEnumerable()
            .Select(s => new ResumenProductoDto
            {
                NroCuota = s.Cuota,
                FechaDesembolso = s.FEC_DESEMBOLSO.ToString(Constants.DateTimeFormats.DD_MM_YYYY),
                Tipo = s.tipo,
                TotalPagar = s.TotalPagar,
                FechaVencimiento = s.FEC_VENCIM.ToString(Constants.DateTimeFormats.DD_MM_YYYY),
                Estado = s.Estado
            }).ToList();
        }

        #endregion Procedure
    }
}