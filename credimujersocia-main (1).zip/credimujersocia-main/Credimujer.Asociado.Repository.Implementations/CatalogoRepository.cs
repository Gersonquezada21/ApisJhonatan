﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Domain.Models.Entities;
using Credimujer.Asociado.Repository.Implementations.Data;
using Credimujer.Asociado.Repository.Implementations.Data.Base;
using Credimujer.Asociado.Repository.Interfaces;

namespace Credimujer.Asociado.Repository.Implementations
{
    public class CatalogoRepository:BaseRepository<CatalogoEntity>, ICatalogoRepository
    {
        private readonly DataContext _context;
        public CatalogoRepository(DataContext context) : base(context)
        {
            this._context = context;
        }
    }
}
