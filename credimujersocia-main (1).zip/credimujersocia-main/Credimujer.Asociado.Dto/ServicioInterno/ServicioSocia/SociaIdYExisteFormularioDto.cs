﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Dto.ServicioInterno.ServicioSocia
{
    public class SociaIdYExisteFormularioDto
    {
        public int SociaId { get; set; }
        public bool TieneFormulario { get; set; }
        public string Sucursal { get; set; }
    }
}
