﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Dto.PreSolicitud
{
    public class MostrarPresolicitudDto
    {
        public string NroSolicitud { get; set; }
        public string TipoCredito { get; set; }
        public decimal MontoSolicitado { get; set; }
        public int Plazo { get; set; }
        public string EntidadBancaria { get; set; }
        public string Estado { get; set; }

    }
}
