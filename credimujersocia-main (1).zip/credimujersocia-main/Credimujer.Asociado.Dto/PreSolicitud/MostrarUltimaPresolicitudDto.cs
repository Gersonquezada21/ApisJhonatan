﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Dto.PreSolicitud
{
    public class MostrarUltimaPresolicitudDto
    {
        public string TipoCredito { get; set; }
        public string FechaDesembolso { get; set; }
        public string Cuota { get; set; }
        public string Estado { get; set; }
    }
}
    