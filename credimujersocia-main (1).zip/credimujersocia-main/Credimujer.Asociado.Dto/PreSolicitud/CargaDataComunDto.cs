﻿using Credimujer.Asociado.Dto.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Dto.PreSolicitud
{
    public class CargaDataComunDto
    {
        public List<DropdownDto> EntidadBancaria { get; set; }
        public List<DropdownDto> TipoCredito { get; set; }
        public List<DropdownDto> Afirmacion { get; set; }
        public List<DropdownDto> SubTipoCredito { get; set; }
    }
}