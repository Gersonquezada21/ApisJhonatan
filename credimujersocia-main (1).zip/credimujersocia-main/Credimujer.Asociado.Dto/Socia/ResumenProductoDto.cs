﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Dto.Socia
{
    public class ResumenProductoDto
    {
        public string FechaDesembolso { get; set; }
        public string Tipo { get; set; }
        public decimal TotalPagar { get; set; }
        public string NroCuota { get; set; }
        public string FechaVencimiento { get; set; }
        public string Estado { get; set; }
    }
}