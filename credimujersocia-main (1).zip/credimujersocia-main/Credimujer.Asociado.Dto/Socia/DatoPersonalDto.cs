﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Dto.Socia
{
    public class DatoPersonalDto
    {
        public string BancoComunal { get; set; }
        public string Celular { get; set; }
        public string RegionCodigo { get; set; }
        public string Nombre { get; set; }
        public string ApePaterno { get; set; }
        public string ApeMaterno { get; set; }
        public string NroDependiente { get; set; }
        public string ActividadEconomica { get; set; }
        public string ActividadEconomica2 { get; set; }
        public string ActividadEconomica3 { get; set; }
        public string GradoInstruccionCodigo { get; set; }
        public string EstadoCivilCodigo { get; set; }
        public string NroDni { get; set; }
        public string DepartamentoCodigo { get; set; }
        public string ProvinciaCodigo { get; set; }
        public string DistritoCodigo { get; set; }
        public string Direccion { get; set; }
        public string Referencia { get; set; }
        public string SituacionDomicilioCodigo { get; set; }
        public string EntidadBancariaCodigo { get; set; }
        public string NroCuenta { get; set; }
        public string DepartamentoNegocioCodigo { get; set; }
        public string ProvinciaNegocioCodigo { get; set; }
        public string DistritoNegocioCodigo { get; set; }
        public string DireccionNegocio { get; set; }
        public string ReferenciaNegocio { get; set; }
        public string ActividadPrincipal { get; set; }
    }
}
