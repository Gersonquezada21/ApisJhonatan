﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Asociado.Dto.Base;

namespace Credimujer.Asociado.Dto.Socia
{
    public class CargaDataComunDto
    {
        public List<DropdownDto> EstadoCivil { get; set; }
        public List<DropdownDto> GradoInstruccion { get; set; }
        public List<DropdownDto> SituacionDomicilio { get; set; }
        public List<DropdownDto> Afirmacion { get; set; }
        public List<DropdownDto> EntidadFinanciera { get; set; }
        public List<DropdownDto> Departamento { get; set; }
        public List<DropdownDto> Sucursal { get; set; }
    }
}
