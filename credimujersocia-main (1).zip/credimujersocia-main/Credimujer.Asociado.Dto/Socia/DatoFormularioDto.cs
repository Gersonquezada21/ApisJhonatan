﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Asociado.Dto.Socia
{
    public class DatoFormularioDto
    {
       
        public int EstadoCivilId { get; set; }
        public string Celular { get; set; }
        public string ActividadEconomica { get; set; }
        public string DepartamentoCode { get; set; }
        public string ProvinciaCode { get; set; }
        public string DistritoCode { get; set; }
        public string Direccion { get; set; }
        public string Referencia { get; set; }
        public int SituacionDomicilioId { get; set; }
        public int ?EntidadBancariaId { get; set; }
        public string NroCuenta { get; set; }

        public string DepartamentoNegocioCode { get; set; }
        public string ProvinciaNegocioCode { get; set; }
        public string DistritoNegocioCode { get; set; }
        public string DireccionNegocio { get; set; }
        public string ReferenciaNegocio { get; set; }





    }
}
