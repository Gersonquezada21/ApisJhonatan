﻿using Autofac;
using Credimujer.Common;
using Credimujer.Common.Base;
using Credimujer.Common.Exceptions;
using Credimujer.Iam.Application.Interfaces.Administrar;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Interfaces;
using Credimujer.Iam.Repository.Interfaces.Data;
using Credimujer.Model.Administrar.Usuario;
using Microsoft.Extensions.Options;
using System;
using System.Security.Claims;
using System.Threading.Tasks;
using Credimujer.Model.Auth;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using Credimujer.Common.Resources;
using Credimujer.Model.ServicioInterno.Operativo;

namespace Credimujer.Iam.Application.Implementations.Administrar
{
    public class UsuarioApplication : IUsuarioApplication
    {
        private readonly Lazy<IUnitOfWork> _unitOfWork;
        private readonly AppSetting _setting;
        private readonly Lazy<IHttpContextAccessor> _httpContext;

        public UsuarioApplication(IOptions<AppSetting> settings,
            ILifetimeScope lifetimeScope

        )
        {
            _setting = settings.Value;
            _unitOfWork = new Lazy<IUnitOfWork>(() => lifetimeScope.Resolve<IUnitOfWork>());
            _httpContext = new Lazy<IHttpContextAccessor>(() => lifetimeScope.Resolve<IHttpContextAccessor>());
        }

        #region Properties

        private IUnitOfWork UnitOfWork => _unitOfWork.Value;
        private ClaimsPrincipal UserIdentity => _httpContext.Value.HttpContext.User;
        private IUsuarioRepository UsuarioRepository => UnitOfWork.Repository<IUsuarioRepository>();
        private IPersonarRepository PersonaRepository => UnitOfWork.Repository<IPersonarRepository>();

        #endregion Properties

        public async Task<ResponseDTO> CrearUsuarioTipoSocia(RegistrarUsuarioTipoSociaModel model)
        {
            //var existeCorreo = await UsuarioRepository.Any(p => p.Correo == model.Correo);
            //if (existeCorreo)
            //{
            //    throw new FunctionalException(Constants.SystemStatusCode.TechnicalError, "El correo ingresado ya se encuentra registrado.");
            //}

            var existeUsuario = await UsuarioRepository.Any(p => p.NombreUsuario == model.Dni);
            if (existeUsuario)
                throw new FunctionalException(Constants.SystemStatusCode.TechnicalError, "El usuario ingresado ya se encuentra registrado.");

            var existePersona = await PersonaRepository.FirstOrDefault(p => p.Dni == model.Dni && p.EstadoFila);
            if (existePersona==null)
                throw new FunctionalException(Constants.SystemStatusCode.TechnicalError, "No se puede crear u usuario a una persona no registrada.");

            var nuevoUsuario = new UsuarioEntity
            {
                NombreUsuario = model.Dni,
                Password = BCrypt.Net.BCrypt.EnhancedHashPassword("123456789"),
                Celular = model.Celular,
                ExpiracionPassword = DateTime.Now.AddMonths(6),
                ActualizarPasswordObligatorio = true,
                PersonaId = existePersona.Id,
                //Persona = new PersonaEntity
                //{
                //    Nombre = model.Nombre,
                //    ApellidoPaterno = model.ApellidoPaterno,
                //    ApellidoMaterno = model.ApellidoMaterno,
                //    Dni = model.Dni,
                //},
                RolUsuario = new List<RolUsuarioEntity>() {
                    new RolUsuarioEntity{
                        SistemaId=Constants.Sistema.SistemaAsociados,
                        RolId=Constants.Sistema.Asociado.Roles.RolAsociado
                    }
                }
            };

            await UnitOfWork.Set<UsuarioEntity>().AddAsync(nuevoUsuario);
            await UnitOfWork.SaveChangesAsync();

            return new ResponseDTO() { Message = "Se registro Correctamente" };
        }

        public async Task<ResponseDTO> ActualizarClave(ActualizarClaveModel model)
        {
            var usuarioId = UserIdentity.FindFirstValue(Constants.Core.UserAsociadoClaims.NombreUsuario);

            var result = await UsuarioRepository.ObtenerUsuarioParaActualizarClave(usuarioId, Constants.Sistema.SistemaAsociados, Constants.Core.TipoDispositivo.Web);
            if (result == null || result.TokenRefresco != model.Token)
            {
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Debe iniciar sesión para realizar el cambio de contraseña.");
            }
            // validar credenciales
            if (BCrypt.Net.BCrypt.Verify(model.Contrasenia, result.Password, true))
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Contraseña debe ser diferente al anterior.");

            var usuario = await UsuarioRepository.GetById(result.Id);

            usuario.Password = BCrypt.Net.BCrypt.EnhancedHashPassword(model.Contrasenia);
            usuario.ActualizarPasswordObligatorio = false;
            usuario.ExpiracionPassword = DateTime.Now.AddMonths(6);

            UnitOfWork.Set<UsuarioEntity>().Update(usuario);
            await UnitOfWork.SaveChangesAsync();

            return new ResponseDTO() { Message = "Se actualizo correctamente." };
        }

        public async Task<ResponseDTO> ActualizarContrasenia(ActualizarContraseniaModel model)
        {
            var usuarioId = UserIdentity.FindFirstValue(Constants.Core.UserAsociadoClaims.NombreUsuario);

            var result = await UsuarioRepository.ObtenerUsuarioParaActualizarClave(usuarioId, Constants.Sistema.SistemaAsociados, Constants.Core.TipoDispositivo.Web);
            if (result == null || result.TokenRefresco != model.Token)
            {
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Debe iniciar sesión para realizar el cambio de contraseña.");
            }
            // validar credenciales
            if (!BCrypt.Net.BCrypt.Verify(model.Contrasenia, result.Password, true))
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Ingresar correctamente la contraseña actual.");

            if (BCrypt.Net.BCrypt.Verify(model.ContraseniaNueva, result.Password, true))
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Contraseña debe ser diferente al anterior.");

            var usuario = await UsuarioRepository.GetById(result.Id);

            usuario.Password = BCrypt.Net.BCrypt.EnhancedHashPassword(model.ContraseniaNueva);
            usuario.ActualizarPasswordObligatorio = false;
            usuario.ExpiracionPassword = DateTime.Now.AddMonths(6);

            UnitOfWork.Set<UsuarioEntity>().Update(usuario);
            await UnitOfWork.SaveChangesAsync();

            return new ResponseDTO() { Message = "Se actualizo correctamente." };
        }
        public async Task<ResponseDTO> ObtenerDatosUsuario(string usuario)
        {
            var datosUsuario = await UsuarioRepository.ObtenerConSucursal(usuario, Constants.Core.Sistema.OperativoPersonal);
            return new ResponseDTO
            {
                Data = datosUsuario
            };
        }

        public async Task<ResponseDTO> ActualizarCelularUsuario(ActualizarCelularUsuarioModel model)
        {
            var entity =
                await UsuarioRepository.ObtenerUsuarioPorSistema(model.Usuario, Constants.Core.Sistema.OperativoPersonal);
            entity.Celular = model.Celular;
            UnitOfWork.Set<UsuarioEntity>().Update(entity);
            await UnitOfWork.SaveChangesAsync();
            return new ResponseDTO
            {
                Message = CommonResource.update_ok
            };
        }

        public async Task<ResponseDTO> ActualizarContraseniaUsuario(ActualizarPasswordModel model)
        {
             // validar credenciales
            
            var usuario = await UsuarioRepository.ObtenerUsuarioPorSistema(model.Usuario, Constants.Core.Sistema.OperativoPersonal);
            if (usuario == null)
            {
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Ingresar correctamente sus credenciales.");
            }
            if ( !BCrypt.Net.BCrypt.Verify(model.Contrasenia, usuario.Password, true))
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Usuario o Paswword son incorrectos.");
            if (BCrypt.Net.BCrypt.Verify(model.NuevaContrasenia, usuario.Password, true))
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Contraseña debe ser diferente al anterior.");

            usuario.Password = BCrypt.Net.BCrypt.EnhancedHashPassword(model.NuevaContrasenia);
            UnitOfWork.Set<UsuarioEntity>().Update(usuario);
            await UnitOfWork.SaveChangesAsync();
            return new ResponseDTO
            {
                Message = CommonResource.update_ok
            };

        }
    }
}