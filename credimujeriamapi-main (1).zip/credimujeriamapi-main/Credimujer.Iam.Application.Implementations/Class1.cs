﻿using System;

namespace Credimujer.Iam.Application.Implementations
{
    public class Class1
    {
    }
}
