﻿using Autofac;
using Credimujer.Common;
using Credimujer.Common.Base;
using Credimujer.Common.Exceptions;
using Credimujer.Dto.Auth;
using Credimujer.Dto.Auth.Asociado;
using Credimujer.Dto.Auth.OperativoPersonal;
using Credimujer.Dto.Auth.RolMenu;
using Credimujer.Iam.Repository.Interfaces;
using Credimujer.Iam.Repository.Interfaces.Data;
using Credimujer.Iam.Service.Interfaces;
using Credimujer.Model.Auth.OperativoPersonal;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Iam.Application.Interfaces.Auth;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Model.Auth;
using Credimujer.Model.Service.Socia;
using Credimujer.Model.ServicioInterno.Operativo;

namespace Credimujer.Iam.Application.Implementations.Auth
{
    public class AuthOpePersonalApplication: IAuthOpePersonalApplication
    {
        private readonly Lazy<IUnitOfWork> _unitOfWork;
        private readonly AppSetting _setting;
        private readonly TokenValidationParameters _tokenValidationParameters;
        private readonly Lazy<IHttpContextAccessor> _httpContext;
        private readonly Lazy<ISociaService> _sociaService;

        public AuthOpePersonalApplication(IOptions<AppSetting> settings,
            ILifetimeScope lifetimeScope,
            TokenValidationParameters tokenValidationParameters
        )
        {
            _setting = settings.Value;
            _unitOfWork = new Lazy<IUnitOfWork>(() => lifetimeScope.Resolve<IUnitOfWork>());
            _tokenValidationParameters = tokenValidationParameters;
            _httpContext = new Lazy<IHttpContextAccessor>(() => lifetimeScope.Resolve<IHttpContextAccessor>());
            _sociaService = new Lazy<ISociaService>(() => lifetimeScope.Resolve<ISociaService>());
        }

        #region Properties

        private ClaimsPrincipal UserIdentity => _httpContext.Value.HttpContext.User;
        private IUnitOfWork UnitOfWork => _unitOfWork.Value;
        private IUsuarioRepository UsuarioRepository => UnitOfWork.Repository<IUsuarioRepository>();
        private IPersonarRepository PersonaRepository => UnitOfWork.Repository<IPersonarRepository>();
        private IUsuarioTokenRepository UsuarioTokenRepository => UnitOfWork.Repository<IUsuarioTokenRepository>();
        private IPermisoRolRepository PermisoRolRepository => UnitOfWork.Repository<IPermisoRolRepository>();
        private ISociaService SociaService => _sociaService.Value;

        #endregion Properties

        public async Task<ResponseDTO> Ingresar(AuthOpePersonalModel model)
        {
            var data = await ObtenerUsuario(model.Usuario, model.Contrasenia,
                Constants.Core.Sistema.OperativoPersonal);

            //var listaMenu = ObtenerMenu(usuario);

            //var informacionAsociado = SetInformacionAsociado(usuario, listaMenu);

            //informacionAsociado.Guid = System.Guid.NewGuid().ToString();
            var claims = new ClaimsIdentity(new Claim[]
            {
                new(Constants.Core.UserAsociadoClaims.NombreUsuario,data.Item1.Usuario),
                new(Constants.Core.UserAsociadoClaims.NombreCompleto,$"{data.Item1.Nombre} {data.Item1.Apellidos}"),
                new(Constants.Core.UserAsociadoClaims.Sucursal,string.Join(",", data.Item1.ListaSucursalCodigo)),
            });

            data.Item1.Token=GenerarToken(claims);
            data.Item1.RefrescarToken=RefrescarToken(claims);
            await ActualizarTokenUsuario(data.Item1.RefrescarToken, model.TipoDispositivo, data.Item2);
            return new ResponseDTO() { Data = data.Item1 };
        }
        public async Task<ResponseDTO> RefrescarTokenDeAcceso(TokenModel model)
        {
            string sistema = Constants.Core.Sistema.OperativoPersonal;
            if (string.IsNullOrEmpty(model.RefreshToken))
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Debe ingresar el token de refresco.");

            var validarTokenAccesoAntiguo = await ValidarTokenAcceso(model.Token, model.RefreshToken, sistema);

            if (validarTokenAccesoAntiguo!=null && !string.IsNullOrEmpty(validarTokenAccesoAntiguo.Nombre))
            {
                return new ResponseDTO() { Data = validarTokenAccesoAntiguo };
            }

            var data = await UsuarioRepository.ObtenerOperativoPersonalPorTokenRefresco(model.RefreshToken,Constants.Core.Sistema.OperativoPersonal);
            if (data == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El token ingresado no es el correcto.");
            if (data.UsuarioToken.First().FechaExpiracion < DateTime.Now)
            {
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El token de refresco ha caducado.");
            }

            var claims= new ClaimsIdentity(new Claim[]
            {
                new(Constants.Core.UserAsociadoClaims.NombreUsuario,data.NombreUsuario),
                new(Constants.Core.UserAsociadoClaims.NombreCompleto,$"{data.Persona.Nombre} {data.Persona.ApellidoPaterno} {data.Persona.ApellidoMaterno}"),
                new(Constants.Core.UserAsociadoClaims.Sucursal,string.Join(",", data.Sucursal.Select(s=>s.Sucursal.Codigo).ToList())),
            });


            var usuario = new InforamacionPersonalDto
            {
                Usuario = data.NombreUsuario,
                Nombre = data.Persona.Nombre,
                Apellidos = $"{data.Persona.ApellidoPaterno} {data.Persona.ApellidoMaterno}",
                FechaExpiracionContrasenia = data.ExpiracionPassword,
                Email = data.Correo,
                Celular = data.Celular,
                ActualizarPasswordObligatorio = data.ActualizarPasswordObligatorio,
                Roles = data.RolUsuario.Where(r => r.EstadoFila && r.SistemaId == Constants.Core.Sistema.OperativoPersonal)
                    .Select(sr => new Rol()
                    {
                        Id = sr.RolId,
                        Descripcion = sr.Rol.Descripcion
                    }).ToList(),
                Token = GenerarToken(claims),
                RefrescarToken = RefrescarToken(claims),
                ListaSucursalCodigo=data.Sucursal.Select(s=>s.Sucursal.Descripcion).ToList()
            };
            await ActualizarTokenUsuario(usuario.RefrescarToken, Constants.Core.TipoDispositivo.Web,data.Id, true);

            return new ResponseDTO() { Data = usuario };
        }


        #region methods
        private async Task<(InforamacionPersonalDto,int)> ObtenerUsuario(string usuarioId, string contrasenia, string sistemaId)
        {
            InforamacionPersonalDto usuario=null;

            var data = await UsuarioRepository.ObtenerCredencialParaOperativoPersonal(usuarioId,
                sistemaId);
            if(data!=null)
                usuario = new InforamacionPersonalDto()
                {

                    Usuario = data.NombreUsuario,
                    Nombre = data.Persona.Nombre,
                    Apellidos = $"{data.Persona.ApellidoPaterno} {data.Persona.ApellidoMaterno}",
                    FechaExpiracionContrasenia = data.ExpiracionPassword,
                    Email = data.Correo,
                    Celular = data.Celular,
                    ActualizarPasswordObligatorio = data.ActualizarPasswordObligatorio,
                    Roles = data.RolUsuario.Where(r => r.EstadoFila && r.SistemaId == sistemaId)
                            .Select(sr => new Rol()
                            {
                                Id = sr.RolId,
                                Descripcion = sr.Rol.Descripcion
                            }).ToList(),
                    ListaSucursalCodigo = data.Sucursal.Where(p=>p.EstadoFila).Select(s=>s.Sucursal.Codigo).ToList()
                };
            // validar credenciales
            if (usuario == null || !BCrypt.Net.BCrypt.Verify(contrasenia, data.Password, true))
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Usuario o Paswword son incorrectos.");

            if (!usuario.Roles.Any())
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El usuario no tiene rol asignado.");

            var permisoMenu = await PermisoRolRepository.ObtenerMenuPorUsuarioSistema(
                sistemaId, usuario.Roles.Select(s => s.Id).ToList());

            usuario.Menus = ObtenerMenu(permisoMenu);

            if (usuario.Menus == null || !usuario.Menus.Any())
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El usuario no tiene acceso a ningun módulo del sistema.");

            return (usuario,data.Id);
            
        }

        private List<NavItem> ObtenerMenu(List<Menu> menus)
        {
            var lista = menus.Where(p => string.IsNullOrEmpty(p.Padre)).Distinct().ToList()
                .Select(s => new NavItem()
                {
                    Id = s.Id,
                    Title = s.Descripcion,
                    Icon = s.Icono,
                    Link = s.Route,
                    Image = s.Imagen
                }).ToList();
            lista.ForEach(f =>
            {
                f.Children = menus.Where(p => p.Padre == f.Id)
                    .Select(s => new Option()
                    {
                        Title = s.Descripcion,
                        Link = s.Route,
                        Icon = s.Icono
                    }).Distinct().ToList();
            });
            return lista;
        }

        private string GenerarToken(ClaimsIdentity claims)
        {
            var jwtConfig = _setting.JWTApiOperativoPersonal;

            var expire = DateTime.UtcNow.AddHours(jwtConfig.ExpirationTimeHours);


            var key = Encoding.ASCII.GetBytes(jwtConfig.Secret);
            var tokenHandler = new JwtSecurityTokenHandler();
            var JWT = new SecurityTokenDescriptor()
            {
                Subject = claims,
                Expires = expire,
                NotBefore = DateTime.UtcNow,
                Audience = jwtConfig.Aud,
                Issuer = jwtConfig.Iss,
                SigningCredentials = new SigningCredentials
                    (new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(JWT);
            return tokenHandler.WriteToken(token);

        }
        private string RefrescarToken(ClaimsIdentity claims)
        {
            var jwtConfig = _setting.JWTApiOperativoPersonal;

            var expire = DateTime.Now.AddDays(jwtConfig.ExpitarionTimeDay);

            var key = Encoding.ASCII.GetBytes(jwtConfig.Secret);
            var tokenHandler = new JwtSecurityTokenHandler();
            var JWT = new SecurityTokenDescriptor()
            {
                Subject = claims,
                Expires = expire,
                NotBefore = DateTime.Now,
                Audience = jwtConfig.Aud,
                Issuer = jwtConfig.Iss,
                SigningCredentials = new SigningCredentials
                    (new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(JWT);
            return tokenHandler.WriteToken(token);
        }
        private async Task ActualizarTokenUsuario(string refrescarToken,
            string tipoDispositivo,int usuarioId, bool esRefrescarToken = false)
        {

            var config = _setting.JWTApiOperativoPersonal;

            var data = await UsuarioRepository.ObtenerTokenPorId(usuarioId);

            var listaToken = data.UsuarioToken.Where(p => p.TipoDispositivo == tipoDispositivo.ToUpper()).ToList();
            var nuevoUsuarioToken = new UsuarioTokenEntity()
            {
                UsuarioId = usuarioId,
                Guid = System.Guid.NewGuid().ToString(),
                Token = refrescarToken,
                FechaCreado = DateTime.Now,
                FechaExpiracion = esRefrescarToken ? listaToken.First().FechaExpiracion : DateTime.Now.AddDays(config.ExpitarionTimeDay),
                TipoDispositivo = tipoDispositivo.ToUpper()
            };
            listaToken.ForEach(f =>
            {
                f.FechaAnulado = DateTime.Now;
                f.EstadoFila = false;
                f.ReemplazadoPorToken = nuevoUsuarioToken.Token;
            });
            UnitOfWork.Set<UsuarioTokenEntity>().UpdateRange(listaToken);
            await UnitOfWork.SaveChangesAsync();

            UnitOfWork.Set<UsuarioTokenEntity>().Add(nuevoUsuarioToken);
            await UnitOfWork.SaveChangesAsync();


        }
        private async Task<InforamacionPersonalDto> ValidarTokenAcceso(string token, string refrescarToken,string sistema)
        {

            InforamacionPersonalDto usuario=null;
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var principal = jwtTokenHandler.ReadJwtToken(token);
            var result = principal.Header.Alg.Equals(SecurityAlgorithms.HmacSha256);
            if (result == false)
            {
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "El token ingresado es incorrecto.");
            }

            var claim = principal.Claims.FirstOrDefault(x => x.Type == JwtRegisteredClaimNames.Exp);
            if (claim == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El token ingresado es incorrecto.");

            var utcExpiryDate = long.Parse(claim.Value);

            var expDate = UnixTimeStampToDateTime(utcExpiryDate);

            if (expDate > DateTime.UtcNow)
            {

                var usuarioId = principal.Claims
                    .FirstOrDefault(p => p.Type == Constants.Core.UserAsociadoClaims.NombreUsuario)?.Value;
                //var nombre = principal.Claims
                //    .FirstOrDefault(p => p.Type == Constants.Core.UserAsociadoClaims.NombreCompleto)?.Value;
                var guid = principal.Claims.FirstOrDefault(p => p.Type == Constants.Core.UserAsociadoClaims.GuiId)
                    ?.Value;

                var data = await UsuarioRepository.ObtenerCredencialParaOperativoPersonal(usuarioId, sistema);
                usuario = new InforamacionPersonalDto()
                {

                    Usuario = data.NombreUsuario,
                    Nombre = data.Persona.Nombre,
                    Apellidos = $"{data.Persona.ApellidoPaterno} {data.Persona.ApellidoMaterno}",
                    FechaExpiracionContrasenia = data.ExpiracionPassword,
                    Email = data.Correo,
                    Celular = data.Celular,
                    ActualizarPasswordObligatorio = data.ActualizarPasswordObligatorio,
                    Roles = data.RolUsuario.Where(r => r.EstadoFila && r.SistemaId == sistema)
                        .Select(sr => new Rol()
                        {
                            Id = sr.RolId,
                            Descripcion = sr.Rol.Descripcion
                        }).ToList(),
                    ListaSucursalCodigo = data.Sucursal.Where(p => p.EstadoFila).Select(s => s.Sucursal.Codigo).ToList()
                };
                
                var permisoMenu = await PermisoRolRepository.ObtenerMenuPorUsuarioSistema(
                    sistema, usuario.Roles.Select(s => s.Id).ToList());

                usuario.Menus = ObtenerMenu(permisoMenu);
                usuario.Token = token;
                usuario.RefrescarToken = refrescarToken;

            }
            
            return usuario;
        }
        private DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToUniversalTime();
            return dtDateTime;
        }
        #endregion
    }
}