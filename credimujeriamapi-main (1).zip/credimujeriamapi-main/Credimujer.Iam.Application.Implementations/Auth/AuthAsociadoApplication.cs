﻿using Autofac;
using Credimujer.Common;
using Credimujer.Common.Base;
using Credimujer.Common.Exceptions;
using Credimujer.Dto.Auth;
using Credimujer.Dto.Auth.Asociado;
using Credimujer.Dto.Auth.RolMenu;
using Credimujer.Iam.Application.Interfaces.Auth;
using Credimujer.Iam.Repository.Interfaces;
using Credimujer.Iam.Repository.Interfaces.Data;
using Credimujer.Model.Auth;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Iam.Domain.Models.Entities;
using Microsoft.AspNetCore.Http;
using Credimujer.Iam.Service.Interfaces;
using Credimujer.Model.Service.Socia;

namespace Credimujer.Iam.Application.Implementations.Auth
{
    public class AuthAsociadoApplication : IAuthAsociadoApplication
    {
        private readonly Lazy<IUnitOfWork> _unitOfWork;
        private readonly AppSetting _setting;
        private readonly TokenValidationParameters _tokenValidationParameters;
        private readonly Lazy<IHttpContextAccessor> _httpContext;
        private readonly Lazy<ISociaService> _sociaService;

        public AuthAsociadoApplication(IOptions<AppSetting> settings,
            ILifetimeScope lifetimeScope,
            TokenValidationParameters tokenValidationParameters
        )
        {
            _setting = settings.Value;
            _unitOfWork = new Lazy<IUnitOfWork>(() => lifetimeScope.Resolve<IUnitOfWork>());
            _tokenValidationParameters = tokenValidationParameters;
            _httpContext = new Lazy<IHttpContextAccessor>(() => lifetimeScope.Resolve<IHttpContextAccessor>());
            _sociaService = new Lazy<ISociaService>(() => lifetimeScope.Resolve<ISociaService>());
        }

        #region Properties

        private ClaimsPrincipal UserIdentity => _httpContext.Value.HttpContext.User;
        private IUnitOfWork UnitOfWork => _unitOfWork.Value;
        private IUsuarioRepository UsuarioRepository => UnitOfWork.Repository<IUsuarioRepository>();
        private IPersonarRepository PersonaRepository => UnitOfWork.Repository<IPersonarRepository>();
        private IUsuarioTokenRepository UsuarioTokenRepository => UnitOfWork.Repository<IUsuarioTokenRepository>();
        private IPermisoRolRepository PermisoRolRepository => UnitOfWork.Repository<IPermisoRolRepository>();
        private ISociaService SociaService => _sociaService.Value;

        #endregion Properties

        public async Task<ResponseDTO> IniciarAsociado(AuthAsociadoModel model)
        {
            var usuario = await ObtenerUsuario(model.NumeroDocumento, model.Contrasenia,
                Constants.Core.Sistema.SistemaAsociados);

            var listaMenu = ObtenerMenu(usuario);

            var informacionAsociado = SetInformacionAsociado(usuario, listaMenu);

            informacionAsociado.Guid = System.Guid.NewGuid().ToString();

            var dataSocia = await SociaService.ObtnerSociaIdPorNroDocumento(new UsuarioModel { NroDocumento = model.NumeroDocumento });

            informacionAsociado.SociaId = dataSocia.SociaId.ToString();
            informacionAsociado.TieneFormulario = dataSocia.TieneFormulario;
            informacionAsociado.Sucursal = dataSocia.Sucursal;
            await GenerarToken(informacionAsociado);
            await RefrescarToken(informacionAsociado);
            await ActualizarTokenUsuario(usuario.Id, informacionAsociado, model.TipoDispositivo);
            return new ResponseDTO() { Data = informacionAsociado };
        }

        public InformacionAsociadoDto SetInformacionAsociado(InformacionUsuarioDto model, List<NavItem> listaMenu)
        {
            var actualizarPassword = model.ActualizarPasswordObligatorio;
            if (!model.ActualizarPasswordObligatorio)
                actualizarPassword = model.FechaExpiracionContrasenia < DateTime.Now;
            return new InformacionAsociadoDto()
            {
                Usuario = model.Usuario,
                Nombre = model.Nombre,
                Apellido = model.Apellidos,
                NumeroDocumento = model.NumeroDocumento,
                Roles = model.Roles,
                Menus = listaMenu,
                ActualizarPasswordObligatorio = actualizarPassword
            };
        }

        public async Task<ResponseDTO> RefrescarTokenDeAcceso(TokenModel model)
        {
            if (string.IsNullOrEmpty(model.RefreshToken))
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Debe ingresar el token de refresco.");

            var validarTokenAccesoAntiguo = await ValidarTokenAcceso(model.Token, model.RefreshToken);

            //if(!string.IsNullOrEmpty(validarTokenAccesoAntiguo.msg))
            //    throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, validarTokenAccesoAntiguo.msg);

            //if (!string.IsNullOrEmpty(validarTokenAccesoAntiguo.token))
            //    return new ResponseDTO()
            //    {
            //        Data = new InformacionAsociadoDto()
            //        {
            //            Token = validarTokenAccesoAntiguo.token,
            //            RefrescarToken = model.RefreshToken
            //        }
            //    };
            if (!string.IsNullOrEmpty(validarTokenAccesoAntiguo.Nombre))
            {
                return new ResponseDTO() { Data = validarTokenAccesoAntiguo };
            }

            var data = await UsuarioTokenRepository.ObtenerUsuarioPorTokenDeRefrescar(model.RefreshToken);
            if (data == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El token ingresado no es el correcto.");
            if (data.FechaExpiracionTokenDeRefresco < DateTime.Now)
            {
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El token de refresco ha caducado.");
            }

            var informacionAsociado = new InformacionAsociadoDto()
            {
                Guid = Guid.NewGuid().ToString(),
                Usuario = data.Usuario,
                Nombre = data.Nombre,
                Apellido = data.Apellidos,
            };
            var dataSocia = await SociaService.ObtnerSociaIdPorNroDocumento(new UsuarioModel { NroDocumento = informacionAsociado.Usuario });

            informacionAsociado.SociaId = dataSocia.SociaId.ToString();
            informacionAsociado.TieneFormulario = dataSocia.TieneFormulario;

            await GenerarToken(informacionAsociado);
            await RefrescarToken(informacionAsociado);
            await ActualizarTokenUsuario(data.Id, informacionAsociado, model.TipoDispositivo, true);

            return new ResponseDTO() { Data = informacionAsociado };
        }

        #region private

        private async Task<ClaimsIdentity> GenerarClaim(InformacionAsociadoDto model)
        {
            return new ClaimsIdentity(new Claim[]
            {
                new Claim(Constants.Core.UserAsociadoClaims.NombreUsuario,model.Usuario),
                new Claim(Constants.Core.UserAsociadoClaims.NombreCompleto,$"{model.Nombre} {model.Apellido}"),
                new Claim(Constants.Core.UserAsociadoClaims.GuiId,model.Guid),
                new Claim(Constants.Core.UserAsociadoClaims.SociaId,model.SociaId),
            });
        }

        private async Task GenerarToken(InformacionAsociadoDto model)
        {
            var jwtConfig = _setting.JWTConfigurations;

            var expire = DateTime.UtcNow.AddHours(jwtConfig.ExpirationTimeHours);

            var key = Encoding.ASCII.GetBytes(jwtConfig.Secret);
            var tokenHandler = new JwtSecurityTokenHandler();
            var JWT = new SecurityTokenDescriptor()
            {
                Subject = await GenerarClaim(model),
                Expires = expire,
                NotBefore = DateTime.UtcNow,
                Audience = jwtConfig.Aud,
                Issuer = jwtConfig.Iss,
                SigningCredentials = new SigningCredentials
                    (new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(JWT);
            model.Token = tokenHandler.WriteToken(token);
        }

        private async Task RefrescarToken(InformacionAsociadoDto model)
        {
            var jwtConfig = _setting.JWTConfigurations;

            var expire = DateTime.Now.AddDays(jwtConfig.ExpitarionTimeDay);

            var key = Encoding.ASCII.GetBytes(jwtConfig.Secret);
            var tokenHandler = new JwtSecurityTokenHandler();
            var JWT = new SecurityTokenDescriptor()
            {
                Subject = await GenerarClaim(model),
                Expires = expire,
                NotBefore = DateTime.Now,
                Audience = jwtConfig.Aud,
                Issuer = jwtConfig.Iss,
                SigningCredentials = new SigningCredentials
                    (new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(JWT);
            model.RefrescarToken = tokenHandler.WriteToken(token);
        }

        private async Task ActualizarTokenUsuario(int usuarioId, InformacionAsociadoDto informacionAsociado,
            string tipoDispositivo, bool esRefrescarToken = false)
        {
            try
            {
                var config = _setting.JWTConfigurations;

                var data = await UsuarioRepository.ObtenerTokenPorId(usuarioId);

                var listaToken = data.UsuarioToken.Where(p => p.TipoDispositivo == tipoDispositivo.ToUpper()).ToList();
                //.Where(p => p.IsActive && p.TipoDispositivo==tipoDispositivo.ToUpper()
                //                      && p.FechaExpiracion <= DateTime.Now && p.EstadoFila)
                //.ToList();

                var nuevoUsuarioToken = new UsuarioTokenEntity()
                {
                    Guid = informacionAsociado.Guid,
                    Token = informacionAsociado.RefrescarToken,
                    UsuarioId = usuarioId,
                    FechaCreado = DateTime.Now,
                    FechaExpiracion = esRefrescarToken ? listaToken.First().FechaExpiracion : DateTime.Now.AddDays(config.ExpitarionTimeDay),
                    TipoDispositivo = tipoDispositivo.ToUpper()
                };
                listaToken.ForEach(f =>
                {
                    f.FechaAnulado = DateTime.Now;
                    f.EstadoFila = false;
                    f.ReemplazadoPorToken = nuevoUsuarioToken.Token;
                });

                UnitOfWork.Set<UsuarioTokenEntity>().UpdateRange(listaToken);
                await UnitOfWork.SaveChangesAsync();

                UnitOfWork.Set<UsuarioTokenEntity>().Add(nuevoUsuarioToken);
                await UnitOfWork.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private List<NavItem> ObtenerMenu(InformacionUsuarioDto model)
        {
            //no etniendo porque no funciona el distinct
            //var lista = model.Menus.Where(p => string.IsNullOrEmpty(p.Padre))
            //    .Select(s => new NavItem()
            //    {
            //        Id = s.Id,
            //        Title = s.Descripcion,
            //        Icon = s.Icono,
            //        Link = s.Route,
            //        Image = s.Imagen
            //    }).Distinct().ToList();

            var lista = new List<NavItem>();
            var listaPadre = model.Menus.Where(p => string.IsNullOrEmpty(p.Padre))
                .Select(s => new NavItem()
                {
                    Id = s.Id,
                    Title = s.Descripcion,
                    Icon = s.Icono,
                    Link = s.Route,
                    Image = s.Imagen
                }).Distinct().ToList();

            listaPadre.ForEach(f =>
            {
                if (!lista.Any(a => a.Id == f.Id))
                    lista.Add(f);
            });

            lista.ForEach(f =>
            {
                f.Children = model.Menus.Where(p => p.Padre == f.Id)
                    .Select(s => new Option()
                    {
                        Title = s.Descripcion,
                        Link = s.Route,
                        Icon = s.Icono
                    }).Distinct().ToList();
            });
            return lista;
        }

        private async Task<InformacionAsociadoDto> ValidarTokenAcceso(string token, string refrescarToken)
        {
            var informacionAsociado = new InformacionAsociadoDto();
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var principal = jwtTokenHandler.ReadJwtToken(token);
            var result = principal.Header.Alg.Equals(SecurityAlgorithms.HmacSha256);
            if (result == false)
            {
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError, "El token ingresado es incorrecto.");
            }

            var claim = principal.Claims.FirstOrDefault(x => x.Type == JwtRegisteredClaimNames.Exp);
            if (claim == null)
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El token ingresado es incorrecto.");

            var utcExpiryDate = long.Parse(claim.Value);

            var expDate = UnixTimeStampToDateTime(utcExpiryDate);

            if (expDate > DateTime.UtcNow)
            {
                var usuarioId = principal.Claims
                    .FirstOrDefault(p => p.Type == Constants.Core.UserAsociadoClaims.NombreUsuario)?.Value;
                //var nombre = principal.Claims
                //    .FirstOrDefault(p => p.Type == Constants.Core.UserAsociadoClaims.NombreCompleto)?.Value;
                var guid = principal.Claims.FirstOrDefault(p => p.Type == Constants.Core.UserAsociadoClaims.GuiId)
                    ?.Value;

                var usuario = await UsuarioRepository.ObtenerPorCredenciales(usuarioId, Constants.Core.Sistema.SistemaAsociados);
                var permisoMenu = await PermisoRolRepository.ObtenerMenuPorUsuarioSistema(
                    Constants.Core.Sistema.SistemaAsociados, usuario.Roles.Select(s => s.Id).ToList());

                usuario.Menus = permisoMenu;

                var listaMenu = ObtenerMenu(usuario);

                informacionAsociado = SetInformacionAsociado(usuario, listaMenu);
                informacionAsociado.Guid = guid;
                informacionAsociado.Token = token;
                informacionAsociado.RefrescarToken = refrescarToken;

                var dataSocia = await SociaService.ObtnerSociaIdPorNroDocumento(new UsuarioModel { NroDocumento = informacionAsociado.Usuario });

                informacionAsociado.SociaId = dataSocia.SociaId.ToString();
                informacionAsociado.TieneFormulario = dataSocia.TieneFormulario;
                informacionAsociado.Sucursal = dataSocia.Sucursal;
                //informacionAsociado = new InformacionAsociadoDto()
                //{
                //    Guid = guid,
                //    Usuario = usuario,
                //    Nombre = nombre,
                //    Token = token,
                //    NumeroDocumento = usuario,
                //    RefrescarToken = refrescarToken,
                //    Menus =
                //    //Apellido = data.Apellidos,
                //};
            }

            return informacionAsociado;
        }

        private DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToUniversalTime();
            return dtDateTime;
        }

        private async Task<InformacionUsuarioDto> ObtenerUsuario(string usuarioId, string contrasenia, string sistemaId)
        {
            var usuario = await UsuarioRepository.ObtenerPorCredenciales(usuarioId,
                sistemaId);

            // validar credenciales
            if (usuario == null || !BCrypt.Net.BCrypt.Verify(contrasenia, usuario.Contrasenia, true))
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "Usuario o Paswword son incorrectos.");

            if (!usuario.Roles.Any())
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El usuario no tiene rol asignado.");

            var permisoMenu = await PermisoRolRepository.ObtenerMenuPorUsuarioSistema(
                Constants.Core.Sistema.SistemaAsociados, usuario.Roles.Select(s => s.Id).ToList());

            usuario.Menus = permisoMenu;

            if (usuario.Menus == null || !usuario.Menus.Any())
                throw new FunctionalException(Constants.SystemStatusCode.FunctionalError,
                    "El usuario no tiene acceso a ningun módulo del sistema.");

            return usuario;
        }

        #endregion private
    }
}