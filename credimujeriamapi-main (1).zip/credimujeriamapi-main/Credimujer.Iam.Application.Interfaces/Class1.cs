﻿using System;

namespace Credimujer.Iam.Application.Interfaces
{
    public class Class1
    {
    }
}
