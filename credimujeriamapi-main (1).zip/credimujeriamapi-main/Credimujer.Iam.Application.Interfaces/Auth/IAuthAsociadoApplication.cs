﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Common.Base;
using Credimujer.Model.Auth;

namespace Credimujer.Iam.Application.Interfaces.Auth
{
    public interface IAuthAsociadoApplication
    {
        Task<ResponseDTO> IniciarAsociado(AuthAsociadoModel model);
        Task<ResponseDTO> RefrescarTokenDeAcceso(TokenModel model);
    }
}
