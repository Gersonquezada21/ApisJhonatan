﻿using Credimujer.Model.Administrar.Usuario;
using System.Threading.Tasks;
using Credimujer.Common.Base;
using Credimujer.Model.Auth;
using Credimujer.Model.ServicioInterno.Operativo;

namespace Credimujer.Iam.Application.Interfaces.Administrar
{
    public interface IUsuarioApplication
    {
        Task<ResponseDTO> CrearUsuarioTipoSocia(RegistrarUsuarioTipoSociaModel model);

        Task<ResponseDTO> ActualizarClave(ActualizarClaveModel model);

        Task<ResponseDTO> ActualizarContrasenia(ActualizarContraseniaModel model);
        Task<ResponseDTO> ObtenerDatosUsuario(string usuario);
        Task<ResponseDTO> ActualizarCelularUsuario(ActualizarCelularUsuarioModel model);
        Task<ResponseDTO> ActualizarContraseniaUsuario(ActualizarPasswordModel model);
    }
}