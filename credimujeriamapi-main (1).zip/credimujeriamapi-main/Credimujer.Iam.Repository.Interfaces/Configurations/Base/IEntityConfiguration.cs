﻿using Microsoft.EntityFrameworkCore;

namespace Credimujer.Iam.Repository.Interfaces.Configurations.Base
{
    public interface IEntityConfiguration<T> : IEntityTypeConfiguration<T> where T : class
    {
    }
}
