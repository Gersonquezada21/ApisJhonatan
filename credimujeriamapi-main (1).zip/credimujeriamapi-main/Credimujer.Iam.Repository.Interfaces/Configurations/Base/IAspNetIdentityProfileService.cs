﻿using Credimujer.Iam.Domain.Models.Entities;
using IdentityServer4.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Repository.Interfaces.Configurations.Base
{
    public interface IAspNetIdentityProfileService<TUser> : IProfileService where TUser : UsuarioEntity, new()
    {
        
    }
}
