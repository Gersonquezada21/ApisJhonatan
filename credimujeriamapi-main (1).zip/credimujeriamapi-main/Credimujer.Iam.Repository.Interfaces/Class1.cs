﻿using System;

namespace Credimujer.Iam.Repository.Interfaces
{
    public class Class1
    {
    }
}
