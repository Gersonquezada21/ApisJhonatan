﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Interfaces.Data;

namespace Credimujer.Iam.Repository.Interfaces
{
    public interface IMenuRepository:IBaseRepository<MenuEntity>
    {
        
    }
}
