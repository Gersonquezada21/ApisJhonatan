﻿using Credimujer.Dto.Auth;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Interfaces.Data;
using System.Threading.Tasks;
using Credimujer.Dto.Auth.Asociado;
using Credimujer.Dto.Auth.OperativoPersonal;

namespace Credimujer.Iam.Repository.Interfaces
{
    public interface IUsuarioRepository : IBaseRepository<UsuarioEntity>
    {
        Task<InformacionUsuarioDto> ObtenerPorCredenciales(string usuario, string sistemaId);

        Task<UsuarioEntity> ObtenerCredencialParaOperativoPersonal(string usuario, string sistemaId);

        Task<UsuarioEntity> ObtenerTokenPorId(int usuarioId);

        Task<UsuarioTokenDto> ObtenerUsuarioParaActualizarClave(string usuario, string sistemaId,
            string tipoDispositivo);

        Task<UsuarioEntity> ObtenerOperativoPersonalPorTokenRefresco(string tokenDeRefresco, string sistemaId);
        Task<DatoUsuarioDto> ObtenerConSucursal(string usuario, string sistemaId);
        Task<UsuarioEntity> ObtenerUsuarioPorSistema(string usuario, string sistemaId);
        
    }
}