﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Dto.Auth;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Interfaces.Data;

namespace Credimujer.Iam.Repository.Interfaces
{
    public interface IUsuarioTokenRepository:IBaseRepository<UsuarioTokenEntity>
    {
        Task<InformacionUsuarioDto> ObtenerUsuarioPorTokenDeRefrescar(string tokenDeRefresco);
        Task<RefreshTokenDto> ObtenerUsuarioPorTokenRefrescar(string tokenDeRefresco);
    }
}
