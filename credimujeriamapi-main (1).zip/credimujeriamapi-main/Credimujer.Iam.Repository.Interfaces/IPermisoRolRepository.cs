﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Credimujer.Dto.Auth.RolMenu;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Interfaces.Data;

namespace Credimujer.Iam.Repository.Interfaces
{
    public interface IPermisoRolRepository:IBaseRepository<PermisoRolEntity>
    {
        Task<List<Menu>> ObtenerMenuPorUsuarioSistema(string sistemaId, List<string> listRolId);
    }
}
