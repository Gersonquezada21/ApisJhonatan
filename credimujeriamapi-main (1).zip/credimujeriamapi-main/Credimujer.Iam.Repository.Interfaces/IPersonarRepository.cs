﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Interfaces.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Repository.Interfaces
{
    public interface IPersonarRepository:IBaseRepository<PersonaEntity>
    {
        
    }
}
