﻿using Credimujer.Dto.Auth.RolMenu;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace Credimujer.Dto.Auth.OperativoPersonal
{
    [Serializable()]
    public class InforamacionPersonalDto
    {
        public string Usuario { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Email { get; set; }
        public string Celular { get; set; }
       
        public DateTime FechaExpiracionContrasenia { get; set; }
        public string Token { get; set; }
        public string RefrescarToken { get; set; }
        public List<Rol> Roles { get; set; }
        public List<NavItem> Menus { get; set; }
        public List<string> ListaSucursalCodigo { get; set; }
        public bool ActualizarPasswordObligatorio { get; set; }
    }
}