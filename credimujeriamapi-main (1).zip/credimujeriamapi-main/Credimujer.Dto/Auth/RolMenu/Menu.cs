﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Dto.Auth.RolMenu
{
    public class Menu
    {
        public string Id { get; set; }
        public string Descripcion { get; set; }
        public string Route { get; set; }
        public string Padre { get; set; }
        public string Imagen { get; set; }
        public string Icono { get; set; }

    }
}
