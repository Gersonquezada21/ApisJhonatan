﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Dto.Auth.RolMenu
{
    public class NavItem
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Subtitle { get; set; }
        public string Icon { get; set; }
        public string Image { get; set; }
        public string Link { get; set; }
        public List<Option> Children { get; set; }
        public string Type => Children==null||Children.Count == 0 ? "basic" : "group";
    }
}
