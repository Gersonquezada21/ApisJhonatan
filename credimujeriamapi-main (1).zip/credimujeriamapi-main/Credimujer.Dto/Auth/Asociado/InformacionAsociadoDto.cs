﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Credimujer.Dto.Auth.RolMenu;

namespace Credimujer.Dto.Auth.Asociado
{
    public class InformacionAsociadoDto
    {

        public string Usuario { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string NumeroDocumento { get; set; }
        public string SociaId { get; set; }
        public string Token { get; set; }
        public string RefrescarToken { get; set; }
        public List<Rol> Roles { get; set; }
        public List<NavItem> Menus { get; set; }
        public bool ActualizarPasswordObligatorio { get; set; }
        public bool TieneFormulario { get; set; }
        [JsonIgnore]
        public string Guid { get; set; } = "";
        public string Sucursal { get; set; }
    }
}
