﻿using System;
using System.Text.Json.Serialization;

namespace Credimujer.Dto.Auth
{
    public class RefreshTokenDto
    {
        public int Id { get; set; }
        public string Usuario { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }

        [JsonIgnore]
        public DateTime FechaExpiracionTokenDeRefresco { get; set; }
    }
}
