﻿using Credimujer.Dto.Auth.RolMenu;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Credimujer.Dto.Auth
{
    public class InformacionUsuarioDto
    {
        public int Id { get; set; }
        public string Usuario { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string NumeroDocumento { get; set; }
        public string Email { get; set; }
        public string Celular { get; set; }
        public DateTime FechaExpiracionContrasenia { get; set; }
        public string Contrasenia { get; set; }
        public bool ActualizarPasswordObligatorio { get; set; }

        public List<Rol> Roles { get; set; }
        public List<Menu> Menus { get; set; }
        public string Sucursal { get; set; }//sucursal o region o departamento

        [JsonIgnore]
        public DateTime FechaExpiracionTokenDeRefresco { get; set; }
    }

   

   

   
   
}
