﻿using System;

namespace Credimujer.Common
{
    public class AppSetting
    {
        public ConnectionString ConnectionStrings { get; set; }
        public JWTConfiguration JWTConfigurations { get; set; }
        public JWTApiOperativoPersonals JWTApiOperativoPersonal { get; set; }
        public Api Apis { get; set; }
        public class ConnectionString
        {
            public string DefaultConnection { get; set; }
            
        }
        public class JWTConfiguration { 
            public string Secret { get; set; }
            public int ExpirationTimeHours { get; set; }
            public int ExpitarionTimeDay { get; set; }
            public string Iss { get; set; }
            public string Aud { get; set; }
        }
        public class JWTApiOperativoPersonals
        {
            public string Secret { get; set; }
            public int ExpirationTimeHours { get; set; }
            public int ExpitarionTimeDay { get; set; }
            public string Iss { get; set; }
            public string Aud { get; set; }
        }
        public class Api { 
            public string Name { get; set; }
            public string Key { get; set; } 
            public string Socia { get; set; }
            public Path Paths { get; set; }
        
        }
        public class Path { 
        
            public string ObtenerSociaId { get; set; } 
        }
    }
   
}
