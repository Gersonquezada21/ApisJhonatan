﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic.CompilerServices;

namespace Credimujer.Common
{
    public class Constants
    {
        
        public struct SystemStatusCode {
            public const int Ok = 0;
            public const int Required = 1;
            public const int TechnicalError = -1;
            public const int FunctionalError = -2;
        }
        public struct DateTimeFormats
        {
            public const string DD_MM_YYYY = "dd/MM/yyyy";
            public const string DD_MM_YYYY_HH_MM_SS = "dd/MM/yyyy HH:mm:ss";
            public const string DD_MM_YYYY_HH_MM_TT_12 = "dd/MM/yyyy hh:mm tt";
            public const string DD_MM_YYYY_HH_MM_SS_TT_12 = "dd/MM/yyyy hh:mm:ss tt";
            public const string DD_MM_YYYY_HH_MM_24 = "dd/MM/yyyy HH:mm";
            public const string DD_MM_YYYY_HH_MM_SS_FFF = "yyyyMMddHHmmssFFF";
            public const string DD_MM_YYY_HH_MM_SS = "ddMMyyyHHmmss";
            public const string YYYY_MM_DD = "yyyyMMdd";
        }
        public struct Core {
            public struct Audit {
                public const string CreationUser = "UsuarioCreacion";
                public const string CreationDate = "FechaCreacion";
                public const string ModificationUser = "UsuarioModificacion";
                public const string ModificationDate = "FechaModificacion";
                public const string RowStatu = "EstadoFila";
                public const string System = "CrediMujerSystem";

            }
            public struct UserAsociadoClaims
            {
                public const string NombreUsuario = "NombreUsuario";
                public const string NombreCompleto = "NombreCompleto";
                public const string Sucursal = "Sucursal";
                public const string GuiId = "GuiId";//en caso el usuario se logea en 2 dispositivos.
                public const string SociaId = "SociaId";
            }

            public struct TipoDispositivo
            {
                public const string Web = "WEB";
                public const string Mobil = "MOBIL";
            }

            public struct Sistema
            {
                public const string SistemaAsociados = "SIASO";
                public const string OperativoPersonal = "SIOP";
            }
        }

        public struct Sistema
        {
            public const string SistemaAsociados = "SIASO";
            public struct Asociado
            {
                public struct Roles
                {
                    public const string RolAsociado = "001";
                }
            }

        }
    }
}
