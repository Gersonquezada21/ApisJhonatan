﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Model.ServicioInterno.Operativo
{
    public class ActualizarCelularUsuarioModel
    {
        public string Usuario { get; set; }
        public string Celular { get; set; }
    }
}
