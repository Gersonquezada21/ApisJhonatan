﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Credimujer.Model.Auth
{
    public class AuthAsociadoModel
    {
        [Required]
        public string NumeroDocumento { get; set; }
        [Required]
        public string Contrasenia { get; set; }
        [JsonIgnore]
        public string TipoDispositivo { get; set; } //WEB,MOBIL
    }
}
