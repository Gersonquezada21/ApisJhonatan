﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Credimujer.Model.Auth
{
    public class TokenModel
    {

            [Required]
            public string Token { get; set; }

            public string RefreshToken { get; set; }
            
            [JsonIgnore]
            public string TipoDispositivo { get; set; }

    }
}
