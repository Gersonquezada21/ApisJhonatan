﻿using System.ComponentModel.DataAnnotations;

namespace Credimujer.Model.Auth
{
    public class ActualizarContraseniaModel
    {
        [Required]
        public string Contrasenia { get; set; }

        [Required]
        public string ContraseniaNueva { get; set; }

        [Required]
        public string Token { get; set; }
    }
}