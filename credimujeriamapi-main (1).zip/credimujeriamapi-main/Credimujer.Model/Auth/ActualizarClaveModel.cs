﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Model.Auth
{
    public class ActualizarClaveModel
    {
        [Required]
        public string Contrasenia { get; set; }
        [Required]
        public string Token { get; set; }
    }
}
