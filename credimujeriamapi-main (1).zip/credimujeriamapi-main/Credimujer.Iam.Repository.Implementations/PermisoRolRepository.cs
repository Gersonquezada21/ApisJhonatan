﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Dto.Auth.RolMenu;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Data;
using Credimujer.Iam.Repository.Implementations.Data.Base;
using Credimujer.Iam.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Iam.Repository.Implementations
{
    public class PermisoRolRepository : BaseRepository<PermisoRolEntity>, IPermisoRolRepository
    {
        private readonly DataContext _context;

        public PermisoRolRepository(DataContext context) : base(context)
        {
            this._context = context;
        }

        public async Task<List<Menu>> ObtenerMenuPorUsuarioSistema(string sistemaId, List<string> listRolId)
        {
            return await _context.PermisoRol.Where(p => p.Habilitado && p.Visible && p.EstadoFila
                                                        && p.SistemaId == sistemaId && listRolId.Contains(p.RolId)
            ).OrderBy(o => o.Menu.Orden).Select(me => new Menu()
            {
                Id = me.MenuId,
                Descripcion = me.Menu.Descripcion,
                Route = me.Menu.Url,
                Padre = me.Menu.Padre,
                Imagen = me.Menu.Imagen,
                Icono = me.Menu.Icono
            }).ToListAsync();
        }
    }
}