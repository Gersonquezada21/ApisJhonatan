﻿using System.Collections.Generic;
using Credimujer.Dto.Auth;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Data;
using Credimujer.Iam.Repository.Implementations.Data.Base;
using Credimujer.Iam.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using Credimujer.Dto.Auth.Asociado;
using Credimujer.Dto.Auth.RolMenu;
using Credimujer.Dto.Auth.OperativoPersonal;

namespace Credimujer.Iam.Repository.Implementations
{
    public class UsuarioRepository : BaseRepository<UsuarioEntity>, IUsuarioRepository
    {
        private readonly DataContext _context;

        public UsuarioRepository(DataContext context) : base(context)
        {
            this._context = context;
        }

        public async Task<InformacionUsuarioDto> ObtenerPorCredenciales(string usuario, string sistemaId)
        {
            var query = _context.Usuario.Where(p => p.EstadoFila && p.NombreUsuario == usuario
            //&& p.RolUsuario.Any(a=>a.SistemaId==sistemaId)
            ).Select(s => new InformacionUsuarioDto()
            {
                Id = s.Id,
                Usuario = s.NombreUsuario,
                Nombre = s.Persona.Nombre,
                Apellidos = $"{s.Persona.ApellidoPaterno} {s.Persona.ApellidoMaterno}",
                NumeroDocumento = s.Persona.Dni,
                FechaExpiracionContrasenia = s.ExpiracionPassword,
                Contrasenia = s.Password,
                Email = s.Correo,
                Celular = s.Celular,
                Roles = s.RolUsuario.Where(r => r.EstadoFila && r.SistemaId == sistemaId)
                    .Select(sr => new Rol()
                    {
                        Id = sr.RolId,
                        Descripcion = sr.Rol.Descripcion
                    }).ToList(),
                ActualizarPasswordObligatorio = s.ActualizarPasswordObligatorio
            });
            return await query.FirstOrDefaultAsync();
        }

        public async Task<UsuarioEntity> ObtenerCredencialParaOperativoPersonal(string usuario, string sistemaId)
        {
            var query = _context.Usuario.Where(p => p.EstadoFila && p.NombreUsuario == usuario
            ).Select(s => new UsuarioEntity()
            {
                Id = s.Id,
                Persona = s.Persona,
                NombreUsuario = s.NombreUsuario,
                Password = s.Password,
                Correo = s.Correo,
                Celular = s.Celular,
                ExpiracionPassword = s.ExpiracionPassword,
                ActualizarPasswordObligatorio = s.ActualizarPasswordObligatorio,
                RolUsuario = s.RolUsuario.Where(r => r.EstadoFila && r.SistemaId == sistemaId).Select(r=>new RolUsuarioEntity()
                {
                    SistemaId = r.SistemaId,
                    RolId = r.RolId,
                    Rol = r.Rol,
                    EstadoFila = r.EstadoFila
                }).ToList(),
                Sucursal = s.Sucursal.Where(p=>p.EstadoFila).Select(su=>new SucursalUsuarioEntity()
                {
                    EstadoFila = su.EstadoFila,
                    Sucursal = su.Sucursal
                }).ToList()
            });

            return await query.FirstOrDefaultAsync();
        }
        public async Task<UsuarioEntity> ObtenerOperativoPersonalPorTokenRefresco(string tokenDeRefresco,string sistemaId)
        {
            var query = _context.Usuario.Where(p => p.EstadoFila
                                                    && p.UsuarioToken.Any(a=>a.EstadoFila && a.Token==tokenDeRefresco)
            ).Select(s => new UsuarioEntity()
            {
                Id = s.Id,
                Persona = s.Persona,
                NombreUsuario = s.NombreUsuario,
                Password = s.Password,
                Correo = s.Correo,
                Celular = s.Celular,
                ExpiracionPassword = s.ExpiracionPassword,
                ActualizarPasswordObligatorio = s.ActualizarPasswordObligatorio,
                RolUsuario = s.RolUsuario.Where(r => r.EstadoFila && r.SistemaId == sistemaId).Select(r => new RolUsuarioEntity()
                {
                    SistemaId = r.SistemaId,
                    RolId = r.RolId,
                    Rol = r.Rol,
                    EstadoFila = r.EstadoFila
                }).ToList(),
                Sucursal = s.Sucursal.Where(p => p.EstadoFila).Select(su => new SucursalUsuarioEntity()
                {
                    EstadoFila = su.EstadoFila,
                    Sucursal = su.Sucursal
                }).ToList(),
                UsuarioToken = s.UsuarioToken.Where(t => t.EstadoFila).ToList()
            });

            return await query.FirstOrDefaultAsync();
        }

        public async Task<UsuarioEntity> ObtenerTokenPorId(int usuarioId)
        {
            var query = _context.Usuario.Where(p => p.EstadoFila && p.Id == usuarioId)
                .Select(s => new UsuarioEntity()
                {
                    Id = s.Id,
                    UsuarioToken = s.UsuarioToken.Where(f => f.EstadoFila).ToList()
                });
            return await query.FirstOrDefaultAsync();
        }

        public async Task<UsuarioTokenDto> ObtenerUsuarioParaActualizarClave(string usuario, string sistemaId, string tipoDispositivo)
        {
            return await _context.Usuario.Where(p => p.EstadoFila && p.NombreUsuario == usuario
                && p.RolUsuario.Any(a => a.SistemaId == sistemaId && a.EstadoFila)
            ).Select(s => new UsuarioTokenDto()
            {
                Id = s.Id,
                Password = s.Password,
                Usuario = s.NombreUsuario,
                TokenRefresco = s.UsuarioToken.FirstOrDefault(x => x.EstadoFila && x.TipoDispositivo == tipoDispositivo).Token
            }).FirstOrDefaultAsync();
        }

        public async Task<DatoUsuarioDto> ObtenerConSucursal(string usuario, string sistemaId)
        {
            return await _context.Usuario.Where(p => p.EstadoFila && p.NombreUsuario == usuario
                                                                  && p.RolUsuario.Any(r => r.EstadoFila && r.SistemaId == sistemaId)
            ).Select(s => new DatoUsuarioDto
            {
                Nombre = s.Persona.Nombre,
                ApellidoPat = s.Persona.ApellidoPaterno,
                ApellidoMat = s.Persona.ApellidoMaterno,
                Celular = s.Celular,
                Correo = s.Correo,
                Sucursal = s.Sucursal.Where(p=>p.EstadoFila).Select(su => su.Sucursal.Descripcion).ToList()
            }).FirstOrDefaultAsync();
        }
        public async Task<UsuarioEntity> ObtenerUsuarioPorSistema(string usuario, string sistemaId)
        {
            var query = _context.Usuario.Where(p => p.EstadoFila && p.NombreUsuario == usuario
                                                                 && p.RolUsuario.Any(r =>
                                                                     r.EstadoFila && r.SistemaId == sistemaId)
            );

            return await query.FirstOrDefaultAsync();
        }
    }
}