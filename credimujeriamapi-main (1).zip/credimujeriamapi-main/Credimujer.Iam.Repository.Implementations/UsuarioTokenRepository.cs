﻿using System.Linq;
using System.Threading.Tasks;
using Credimujer.Dto.Auth;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Data;
using Credimujer.Iam.Repository.Implementations.Data.Base;
using Credimujer.Iam.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Iam.Repository.Implementations
{
    public class UsuarioTokenRepository : BaseRepository<UsuarioTokenEntity>, IUsuarioTokenRepository
    {
        private readonly DataContext _context;
        public UsuarioTokenRepository(DataContext context) : base(context)
        {
            this._context = context;
        }
        public async Task<InformacionUsuarioDto> ObtenerUsuarioPorTokenDeRefrescar(string tokenDeRefresco)
        {
            var query = _context.UsuarioToken.Where(p =>p.EstadoFila && p.Token == tokenDeRefresco)
                .Select(s => new InformacionUsuarioDto()
                {
                    Id = s.Usuario.Id,
                    Usuario = s.Usuario.NombreUsuario,
                    Nombre = s.Usuario.Persona.Nombre,
                    Apellidos = $"{s.Usuario.Persona.ApellidoPaterno} {s.Usuario.Persona.ApellidoMaterno}",
                    FechaExpiracionTokenDeRefresco = s.FechaExpiracion
                })
                .FirstOrDefaultAsync();
            return await query;
        }
        public async Task<RefreshTokenDto> ObtenerUsuarioPorTokenRefrescar(string tokenDeRefresco)
        {
            var query = _context.UsuarioToken.Where(p => p.EstadoFila && p.Token == tokenDeRefresco)
                .Select(s => new RefreshTokenDto()
                {
                    Id = s.Usuario.Id,
                    Usuario = s.Usuario.NombreUsuario,
                    Nombre = s.Usuario.Persona.Nombre,
                    Apellidos = $"{s.Usuario.Persona.ApellidoPaterno} {s.Usuario.Persona.ApellidoMaterno}",
                    FechaExpiracionTokenDeRefresco = s.FechaExpiracion
                })
                .FirstOrDefaultAsync();
            return await query;
        }
    }
}
