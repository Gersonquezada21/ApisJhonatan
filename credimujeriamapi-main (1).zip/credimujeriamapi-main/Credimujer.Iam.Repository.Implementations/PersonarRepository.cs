﻿using System.Threading.Tasks;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Data;
using Credimujer.Iam.Repository.Implementations.Data.Base;
using Credimujer.Iam.Repository.Interfaces;

namespace Credimujer.Iam.Repository.Implementations
{
    public class PersonarRepository : BaseRepository<PersonaEntity>, IPersonarRepository
    {
        private readonly DataContext _context;
        public PersonarRepository(DataContext context) : base(context)
        {
            this._context = context;
        }


    }
}
