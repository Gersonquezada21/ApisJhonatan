﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configurations;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
namespace Credimujer.Iam.Repository.Implementations.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            
            builder.ApplyConfiguration(new SistemaConfiguration(builder));
            builder.ApplyConfiguration(new RolConfiguration(builder));
            builder.ApplyConfiguration(new UsuarioConfiguration(builder));
            builder.ApplyConfiguration(new PersonaConfiguration(builder));
            builder.ApplyConfiguration(new RolUsuarioConfiguration(builder));
            builder.ApplyConfiguration(new MenuConfiguration(builder));
            builder.ApplyConfiguration(new PermisoRolConfiguration(builder));
            builder.ApplyConfiguration(new UsuarioTokenConfigurarion(builder));
            builder.ApplyConfiguration(new CatalogoConfiguration(builder));
            builder.ApplyConfiguration(new CatalogoDetalleConfiguration(builder));
            builder.ApplyConfiguration(new SucursalUsuarioConfiguration(builder));
        }
        public DbSet<SistemaEntity> Sistema { get; set; }
        public DbSet<RolEntity> Rol { get; set; }
        public DbSet<UsuarioEntity> Usuario { get; set; }
        public DbSet<PersonaEntity> Persona { get; set; }
        public DbSet<RolUsuarioEntity> RolUsuario { get; set; }
        public DbSet<MenuEntity> Menu { get; set; }
        public DbSet<PermisoRolEntity> PermisoRol { get; set; }
        public DbSet<UsuarioTokenEntity> UsuarioToken { get; set; }
        public DbSet<CatalogoEntity> Catalogo { get; set; }
        public DbSet<CatalogoDetalleEntity> CatalogoDetalle { get; set; }
        public DbSet<SucursalUsuarioEntity> SucursalUsuario { get; set; }
    }
}
