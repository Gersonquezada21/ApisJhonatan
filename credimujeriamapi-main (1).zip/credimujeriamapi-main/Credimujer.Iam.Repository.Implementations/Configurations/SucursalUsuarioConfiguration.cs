﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class SucursalUsuarioConfiguration : EntityConfiguration<SucursalUsuarioEntity>
    {
        public SucursalUsuarioConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<SucursalUsuarioEntity>();
            entityBuilder.ToTable("SUCURSAL_USUARIO");
            entityBuilder.HasKey(c => c.Id);
            entityBuilder.Property(c => c.Id).HasColumnName("IN_ID");
            entityBuilder.Property(c => c.UsuarioId).HasColumnName("IN_USUARIO_ID");
            entityBuilder.Property(c => c.SucursalId).HasColumnName("VC_SUCURSAL_ID");

        
            entityBuilder.HasOne(c => c.Usuario).WithMany(m => m.Sucursal).HasForeignKey(f => f.UsuarioId);
            entityBuilder.HasOne(c => c.Sucursal)
                .WithMany(m => m.SucursalUsuario)
                .HasForeignKey(f => f.SucursalId);
            Configure(entityBuilder);
        }
    }
}
