﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class SistemaConfiguration : EntityConfiguration<SistemaEntity>
    {
        public SistemaConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<SistemaEntity>();
            entityBuilder.ToTable("SISTEMA");
            entityBuilder.HasKey(c => c.Id);
            entityBuilder.Property(c => c.Id).HasColumnName("VC_SISTEMA_ID");
            entityBuilder.Property(c => c.Descripcion).HasColumnName("VC_DESCRIPCION");
            
            Configure(entityBuilder);
        }
    }
}
