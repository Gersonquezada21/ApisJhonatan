﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class RolConfiguration : EntityConfiguration<RolEntity>
    {
        public RolConfiguration(ModelBuilder modelBuilder) {
            var entityBuilder = modelBuilder.Entity<RolEntity>();
            entityBuilder.ToTable("ROLES");
            entityBuilder.HasKey(c => new { c.Id,c.SistemaId });
            entityBuilder.Property(c => c.Id).HasColumnName("VC_ROL_ID");
            entityBuilder.Property(c => c.SistemaId).HasColumnName("VC_SISTEMA_ID");
            entityBuilder.Property(c => c.Descripcion).HasColumnName("VC_DESCRIPCION");

            entityBuilder.HasOne(c => c.Sistema).WithMany(m => m.Rol).HasForeignKey(f => f.SistemaId);
            Configure(entityBuilder);
            
        }
    }
}
