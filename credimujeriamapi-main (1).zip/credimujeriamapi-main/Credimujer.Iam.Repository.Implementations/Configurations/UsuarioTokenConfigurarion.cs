﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class UsuarioTokenConfigurarion : EntityConfiguration<UsuarioTokenEntity>
    {
        public UsuarioTokenConfigurarion(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<UsuarioTokenEntity>();
            entityBuilder.ToTable("USUARIO_TOKEN");
            entityBuilder.HasKey(c => c.Guid);
            entityBuilder.Property(c => c.Guid).HasColumnName("VC_GUID");
            entityBuilder.Property(c => c.Token).HasColumnName("VC_TOKEN");
            entityBuilder.Property(c => c.UsuarioId).HasColumnName("IN_USUARIO_ID");
            entityBuilder.Property(c => c.FechaCreado).HasColumnName("DT_FECHA_CREADO");
            entityBuilder.Property(c => c.FechaExpiracion).HasColumnName("DT_FECHA_EXPIRACION");
            entityBuilder.Property(c => c.FechaAnulado).HasColumnName("DT_FECHA_ANULADO");
            entityBuilder.Property(c => c.ReemplazadoPorToken).HasColumnName("VC_REEMPLAZADO_POR_TOKEN");
            entityBuilder.Property(c => c.TipoDispositivo).HasColumnName("VC_TIPO_DISPOSITIVO");

            entityBuilder.HasOne(c => c.Usuario).WithMany(m => m.UsuarioToken)
                .HasForeignKey(f => f.UsuarioId);
            Configure(entityBuilder);
        }
    }
}
