﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class UsuarioConfiguration : EntityConfiguration<UsuarioEntity>
    {
        public UsuarioConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<UsuarioEntity>();
            entityBuilder.ToTable("USUARIOS");
            entityBuilder.HasKey(c => c.Id);
            entityBuilder.Property(c => c.Id).HasColumnName("IN_ID");
            entityBuilder.Property(c => c.PersonaId).HasColumnName("IN_PERSONA_ID");
            entityBuilder.Property(c => c.NombreUsuario).HasColumnName("VC_NOMBRE_USUARIO");
            entityBuilder.Property(c => c.Password).HasColumnName("VC_PASSWORD");
            entityBuilder.Property(c => c.Correo).HasColumnName("VC_CORREO");
            entityBuilder.Property(c => c.Celular).HasColumnName("VC_CELULAR");
            entityBuilder.Property(c => c.ExpiracionPassword).HasColumnName("DT_EXPIRACION_PASSWORD");
            entityBuilder.Property(c => c.ActualizarPasswordObligatorio).HasColumnName("BT_ACT_PASSWORD_OBLIGATORIO");
            entityBuilder.HasOne(c => c.Persona).WithMany(m => m.Usuario).HasForeignKey(f => f.PersonaId);
            Configure(entityBuilder);
        }
    }
}
