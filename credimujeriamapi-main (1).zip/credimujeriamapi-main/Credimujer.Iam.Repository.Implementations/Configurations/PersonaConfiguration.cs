﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class PersonaConfiguration:EntityConfiguration<PersonaEntity>
    {
        public PersonaConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<PersonaEntity>();
            entityBuilder.ToTable("PERSONA");
            entityBuilder.HasKey(c => c.Id);
            entityBuilder.Property(c => c.Id).HasColumnName("IN_ID");
            entityBuilder.Property(c => c.Nombre).HasColumnName("VC_NOMBRE");
            entityBuilder.Property(c => c.ApellidoPaterno).HasColumnName("VC_APELLIDO_PATERNO");
            entityBuilder.Property(c => c.ApellidoMaterno).HasColumnName("VC_APELLIDO_MATERNO");
            entityBuilder.Property(c => c.Dni).HasColumnName("VC_DNI");

            Configure(entityBuilder);
        }
    }
}
