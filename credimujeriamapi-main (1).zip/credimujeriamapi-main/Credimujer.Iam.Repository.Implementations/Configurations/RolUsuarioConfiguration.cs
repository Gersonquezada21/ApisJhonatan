﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class RolUsuarioConfiguration:EntityConfiguration<RolUsuarioEntity>
    {
        public RolUsuarioConfiguration(ModelBuilder modelBuilder) {
            var entityBuilder = modelBuilder.Entity<RolUsuarioEntity>();
            entityBuilder.ToTable("ROLES_USUARIO");
            entityBuilder.HasKey(c => new{ c.SistemaId,c.UsuarioId,c.RolId });
            entityBuilder.Property(c => c.SistemaId).HasColumnName("VC_SISTEMA_ID");
            entityBuilder.Property(c => c.UsuarioId).HasColumnName("IN_USUARIO_ID");
            entityBuilder.Property(c => c.RolId).HasColumnName("VC_ROL_ID");

            entityBuilder.HasOne(c => c.Sistema).WithMany(m => m.RolUsuario).HasForeignKey(f => f.SistemaId);
            entityBuilder.HasOne(c => c.Usuario).WithMany(m => m.RolUsuario).HasForeignKey(f => f.UsuarioId);
            entityBuilder.HasOne(c => c.Rol).WithMany(m => m.RolUsuario)
                .HasForeignKey(f =>new { f.RolId, f.SistemaId  });
                

            Configure(entityBuilder);
        }
    }
}
