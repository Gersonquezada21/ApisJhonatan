﻿using Credimujer.Iam.Domain.Models.Entities;
using IdentityServer4.Extensions;
using IdentityServer4.Models;
using IdentityServer4.Services;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Repository.Implementations.Configurations.Base
{
    public class AspNetIdentityProfileService<TUser> : IProfileService where TUser : UsuarioEntity, new()
    {
        private readonly UserManager<TUser> _userManager;
        public AspNetIdentityProfileService(UserManager<TUser> userManager) {
            _userManager = userManager;
        }
        public async Task GetProfileDataAsync(ProfileDataRequestContext context)
        {
            var user = await _userManager.FindByIdAsync(context.Subject.GetSubjectId());
            if (user == null) {
                throw new ArgumentException($"asdasdasd");
            }
          
        }

        public Task IsActiveAsync(IsActiveContext context)
        {
            throw new NotImplementedException();
        }
    }
}
