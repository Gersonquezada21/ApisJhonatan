﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class PermisoRolConfiguration : EntityConfiguration<PermisoRolEntity>
    {
        public PermisoRolConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<PermisoRolEntity>();
            entityBuilder.ToTable("PERMISO_ROLES");
            entityBuilder.HasKey(c => new { c.SistemaId, c.RolId });
            entityBuilder.Property(c => c.SistemaId).HasColumnName("VC_SISTEMA_ID");
            entityBuilder.Property(c => c.RolId).HasColumnName("VC_ROL_ID");
            entityBuilder.Property(c => c.MenuId).HasColumnName("VC_MENU_ID");
            entityBuilder.Property(c => c.Habilitado).HasColumnName("VC_HABILITADO");
            entityBuilder.Property(c => c.Visible).HasColumnName("VC_VISIBLE");

            entityBuilder.HasOne(c => c.Menu).WithMany(m => m.PermisoRol)
                .HasForeignKey(f => new {f.SistemaId, f.MenuId });

            entityBuilder.HasOne(c => c.Rol).WithMany(m => m.PermisoRol)
                .HasForeignKey(f => new { f.SistemaId, f.RolId });

            //entityBuilder.HasOne(c => c.RolUsuario).WithMany(m => m.PermisoRol);
            Configure(entityBuilder);
        }
    }
}
