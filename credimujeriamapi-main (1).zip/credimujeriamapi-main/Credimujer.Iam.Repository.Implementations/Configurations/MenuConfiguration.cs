﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class MenuConfiguration : EntityConfiguration<MenuEntity>
    {
        public MenuConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<MenuEntity>();
            entityBuilder.ToTable("MENU");
            entityBuilder.HasKey(c => new { c.SistemaId, c.MenuId });
            entityBuilder.Property(c => c.SistemaId).HasColumnName("VC_SISTEMA_ID");
            entityBuilder.Property(c => c.MenuId).HasColumnName("VC_MENU_ID");
            entityBuilder.Property(c => c.Descripcion).HasColumnName("VC_DESCRIPCION");
            entityBuilder.Property(c => c.Url).HasColumnName("VC_URL");
            entityBuilder.Property(c => c.Padre).HasColumnName("VC_PADRE");
            entityBuilder.Property(c => c.Imagen).HasColumnName("VC_IMAGEN");
            entityBuilder.Property(c => c.Icono).HasColumnName("VC_ICONO");
            entityBuilder.Property(c => c.Orden).HasColumnName("IN_NORDEN");
            entityBuilder.HasOne(c => c.Sistema).WithMany(m => m.Menu).HasForeignKey(f => f.SistemaId);
            Configure(entityBuilder);
        }
    }
}