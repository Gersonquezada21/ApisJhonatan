﻿using Credimujer.Iam.Domain.Models.Entities;
using Credimujer.Iam.Repository.Implementations.Configuration.Base;
using Microsoft.EntityFrameworkCore;

namespace Credimujer.Iam.Repository.Implementations.Configurations
{
    public class CatalogoConfiguration : EntityConfiguration<CatalogoEntity>
    {
        public CatalogoConfiguration(ModelBuilder modelBuilder)
        {
            var entityBuilder = modelBuilder.Entity<CatalogoEntity>();
            entityBuilder.ToTable("CATALOGO");
            entityBuilder.HasKey(c => c.Id);
            entityBuilder.Property(c => c.Id).HasColumnName("IN_ID");
            entityBuilder.Property(c => c.Codigo).HasColumnName("VC_CODIGO");
            entityBuilder.Property(c => c.Descripcion).HasColumnName("VC_NOMBRE");

            Configure(entityBuilder);
        }
    }
}
