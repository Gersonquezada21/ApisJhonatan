﻿using Autofac;
using Credimujer.Common;
using Credimujer.Common.Base;
using Credimujer.Dto.Auth.Asociado;
using Credimujer.Iam.Service.Implementations.Base;
using Credimujer.Iam.Service.Interfaces;
using Credimujer.Model.Service.Socia;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Service.Implementations
{
    public class SociaService:ISociaService
    {
        private readonly AppSetting _settings;
        private ILifetimeScope _lifetimeScope;
        public SociaService(IOptions<AppSetting> settings, ILifetimeScope lifetimeScope)
        {
            
            this._settings = settings.Value;
            _lifetimeScope = lifetimeScope;
        }

        public async Task<SociaIdYExisteFormularioDto> ObtnerSociaIdPorNroDocumento(UsuarioModel usuario) {

            SociaIdYExisteFormularioDto response;
            var url = _settings.Apis.Socia + _settings.Apis.Paths.ObtenerSociaId + $"?nroDocumento={usuario.NroDocumento}";
            var client = new HttpClientService(_lifetimeScope);
            var result = await client.InvokeWithApiKeyAsync<ResponseDTO<SociaIdYExisteFormularioDto>>(HttpMethod.Get, url, _settings.Apis.Name, _settings.Apis.Key, usuario);
            response = result.Data;
            return response;
        }
    }
}
