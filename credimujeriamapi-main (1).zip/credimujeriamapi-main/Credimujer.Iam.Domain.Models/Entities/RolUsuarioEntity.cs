﻿using Credimujer.Iam.Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class RolUsuarioEntity:BaseEntity
    {
        public string SistemaId { get; set; }
        public int UsuarioId { get; set; }
        public string RolId { get; set; }

        public virtual SistemaEntity Sistema { get; set; }
        public virtual UsuarioEntity Usuario { get; set; }
        public virtual RolEntity Rol { get; set; }

        public virtual ICollection<PermisoRolEntity> PermisoRol { get; set; }
    }
}
