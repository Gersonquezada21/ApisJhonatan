﻿using Credimujer.Iam.Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class RolEntity : BaseEntity
    {
        public string Id { get; set; }
        public string SistemaId { get; set; }
        public string Descripcion { get; set; }

        public virtual SistemaEntity Sistema { get; set; }
        public virtual ICollection<RolUsuarioEntity> RolUsuario { get; set; }

        public virtual ICollection<PermisoRolEntity>PermisoRol { get; set; }
    }
}
