﻿using Credimujer.Iam.Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class MenuEntity : BaseEntity
    {
        public MenuEntity()
        {
            PermisoRol = new List<PermisoRolEntity>();
        }

        public string SistemaId { get; set; }
        public string MenuId { get; set; }
        public string Descripcion { get; set; }
        public string Url { get; set; }
        public string Padre { get; set; }
        public string Imagen { get; set; }
        public string Icono { get; set; }
        public int Orden { get; set; }
        public virtual SistemaEntity Sistema { get; set; }
        public virtual ICollection<PermisoRolEntity> PermisoRol { get; set; }
    }
}