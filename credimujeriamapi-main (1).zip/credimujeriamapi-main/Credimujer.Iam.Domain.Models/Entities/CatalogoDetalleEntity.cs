﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Iam.Domain.Models.Base;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class CatalogoDetalleEntity:BaseEntity
    {
        public CatalogoDetalleEntity()
        {
            SucursalUsuario = new List<SucursalUsuarioEntity>();
        }

        public int Id { get; set; }
        public int CatalogoId { get; set; }
        public string Codigo { get; set; }
        public string Valor { get; set; }
        public string Descripcion { get; set; }
        public int Orden { get; set; }

        public virtual CatalogoEntity Catalogo { get; set; }
        public virtual ICollection<SucursalUsuarioEntity> SucursalUsuario { get; set; }
    }
}
