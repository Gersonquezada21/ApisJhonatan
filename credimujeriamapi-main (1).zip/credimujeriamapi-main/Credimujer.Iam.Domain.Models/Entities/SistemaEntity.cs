﻿using Credimujer.Iam.Domain.Models.Base;
using System.Collections.Generic;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class SistemaEntity : BaseEntity
    {
        public SistemaEntity()
        {
            Rol = new List<RolEntity>();
        }
        public string Id { get; set; }
        public string Descripcion { get; set; }
        public virtual ICollection<RolEntity> Rol { get; set; }
        public virtual ICollection<RolUsuarioEntity> RolUsuario { get; set; }
        public virtual ICollection<MenuEntity> Menu { get; set; }
    }
}
