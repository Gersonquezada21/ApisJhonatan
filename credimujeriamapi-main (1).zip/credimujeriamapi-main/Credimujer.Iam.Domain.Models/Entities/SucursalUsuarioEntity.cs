﻿using Credimujer.Iam.Domain.Models.Base;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class SucursalUsuarioEntity:BaseEntity
    {
        public int Id { get; set; }
        public int UsuarioId { get; set; }
        public int SucursalId { get; set; }
        public virtual CatalogoDetalleEntity Sucursal { get; set; }
        public virtual UsuarioEntity Usuario { get; set; }
    }
}
