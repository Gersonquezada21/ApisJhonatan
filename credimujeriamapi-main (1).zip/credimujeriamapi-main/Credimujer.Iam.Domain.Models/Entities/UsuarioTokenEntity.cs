﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credimujer.Iam.Domain.Models.Base;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class UsuarioTokenEntity : BaseEntity
    {
        public string Guid { get; set; }
        public string Token { get; set; }
        public int UsuarioId { get; set; }
        public DateTime FechaCreado { get; set; }
        public DateTime FechaExpiracion { get; set; }
        public DateTime? FechaAnulado { get; set; }
        public virtual UsuarioEntity Usuario { get; set; }
        public string ReemplazadoPorToken { get; set; }
        public string TipoDispositivo { get; set; }//MOBIL,WEB
        [NotMapped]
        public bool IsExpired => DateTime.Now >= FechaExpiracion;
        [NotMapped]
        public bool IsRevoked => FechaAnulado != null;
        [NotMapped]
        public bool IsActive => FechaAnulado==null && DateTime.Now < FechaExpiracion;
    }
}
