﻿using Credimujer.Iam.Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class PermisoRolEntity:BaseEntity
    {
        public string SistemaId { get; set; }
        public string RolId { get; set; }
        public string MenuId { get; set; }
        public bool Habilitado { get; set; }
        public bool Visible { get; set; }
        public virtual MenuEntity Menu { get; set; }
        public virtual RolEntity Rol { get; set; }

        public virtual RolUsuarioEntity RolUsuario { get; set; }

    }
}
