﻿using System.Collections.Generic;
using Credimujer.Iam.Domain.Models.Base;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class CatalogoEntity:BaseEntity
    {
    public CatalogoEntity()
    {
        CatalogoDetalle = new List<CatalogoDetalleEntity>();
    }

    public int Id { get; set; }
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public virtual ICollection<CatalogoDetalleEntity> CatalogoDetalle { get; set; }
    }
}
