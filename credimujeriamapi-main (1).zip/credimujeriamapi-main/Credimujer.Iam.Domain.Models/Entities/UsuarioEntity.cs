﻿using Credimujer.Iam.Domain.Models.Base;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace Credimujer.Iam.Domain.Models.Entities
{
    public class UsuarioEntity :BaseEntity
    {
        public UsuarioEntity()
        {
            RolUsuario = new List<RolUsuarioEntity>();
            UsuarioToken = new List<UsuarioTokenEntity>();
            Sucursal = new List<SucursalUsuarioEntity>();
        }
        public int Id { get; set; }
        public int PersonaId { get; set; }
        public string NombreUsuario { get; set; }
        public string Password { get; set; }
        public string Correo { get; set; }
        public string Celular { get; set; }
        public DateTime ExpiracionPassword { get; set; }
        public bool ActualizarPasswordObligatorio { get; set; }
        public virtual PersonaEntity Persona { get; set; }
        public virtual ICollection<RolUsuarioEntity> RolUsuario { get; set; }
        public virtual ICollection<UsuarioTokenEntity> UsuarioToken { get; set; }
        public virtual ICollection<SucursalUsuarioEntity> Sucursal { get; set; }
    }
}
