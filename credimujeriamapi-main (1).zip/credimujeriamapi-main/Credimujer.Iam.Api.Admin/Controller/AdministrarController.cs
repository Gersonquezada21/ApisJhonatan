﻿using Autofac;
using Credimujer.Common;
using Credimujer.Common.Base;
using Credimujer.Common.Exceptions;
using Credimujer.Iam.Application.Interfaces.Administrar;
using Credimujer.Model.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Threading.Tasks;

namespace Credimujer.Iam.Api.Admin.Controller
{
    [Authorize(AuthenticationSchemes = AuthenticateScheme.Security)]
    [Route("Administrar")]
    [ApiController]
    public class AdministrarController
    {
        private readonly Lazy<IUsuarioApplication> _usuarioApplication;

        public AdministrarController(ILifetimeScope lifetimeScope, IOptions<AppSetting> appSettings)
        {
            _usuarioApplication = new Lazy<IUsuarioApplication>(() => lifetimeScope.Resolve<IUsuarioApplication>());
        }

        private IUsuarioApplication UsuarioApplication => _usuarioApplication.Value;

        [HttpPost("ActualizarPassword")]
        public async Task<JsonResult> ActualizarClave([FromBody] ActualizarClaveModel model)
        {
            ResponseDTO response = new ResponseDTO();
            try
            {
                response = await UsuarioApplication.ActualizarClave(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

        [HttpPost("ActualizarContrasenia")]
        public async Task<JsonResult> ActualizarContrasenia([FromBody] ActualizarContraseniaModel model)
        {
            ResponseDTO response = new ResponseDTO();
            try
            {
                response = await UsuarioApplication.ActualizarContrasenia(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

    }
}