﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using Credimujer.Common;
using Credimujer.Common.Base;
using Credimujer.Common.Exceptions;
using Credimujer.Iam.Application.Interfaces.Administrar;
using Credimujer.Iam.Application.Interfaces.Auth;
using Credimujer.Model.Auth;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Credimujer.Iam.Api.Admin.Controller
{
    [Route("AuthAsociado")]
    [ApiController]
    public class AuthAsociadoController:ControllerBase
    {
        private readonly Lazy<IUsuarioApplication> _usuarioApplication;
        private readonly Lazy<IAuthAsociadoApplication> _authAsociadoApplication;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AuthAsociadoController(ILifetimeScope lifetimeScope, IHttpContextAccessor httpContextAccessor)
        {
            _usuarioApplication = new Lazy<IUsuarioApplication>(() => lifetimeScope.Resolve<IUsuarioApplication>());
            _authAsociadoApplication= new Lazy<IAuthAsociadoApplication>(() => lifetimeScope.Resolve<IAuthAsociadoApplication>());
            this._httpContextAccessor = httpContextAccessor;
        }

        #region Properties
        private IUsuarioApplication UsuarioApplication => _usuarioApplication.Value;
        private IAuthAsociadoApplication AuthAsociadoApplication => _authAsociadoApplication.Value;
        #endregion
        /// <summary>
        /// Login , solamente asociados
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("IniciarAsociado")]
        public async Task<ActionResult> IniciarAsociado(AuthAsociadoModel model)
        {
            ResponseDTO response;
            try
            {
                model.TipoDispositivo = Constants.Core.TipoDispositivo.Web;
                response = await AuthAsociadoApplication.IniciarAsociado(model);
                SetTokenCookie(response.Data.RefrescarToken);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };

            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };

            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };

            }
            return new JsonResult(response);
        }

        [HttpPost("RefrescarToken")]
        public async Task<JsonResult> RefrescarToken([FromBody] TokenModel model)
        {

            ResponseDTO response= new ResponseDTO();
            try
            {
                
                model.RefreshToken = _httpContextAccessor.HttpContext?.Request.Cookies["refreshToken"]??model.RefreshToken;
                model.TipoDispositivo = Constants.Core.TipoDispositivo.Web;

                response=await AuthAsociadoApplication.RefrescarTokenDeAcceso(model);
                SetTokenCookie(response.Data.RefrescarToken);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };

            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };

            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };

            }
            return new JsonResult(response);
        }

        //[HttpPost("RevocarToken")]
        //public async Task<JsonResult> RevocarToken()
        //{

        //}

        #region private

        private void SetTokenCookie(string token)
        {
            
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                SameSite = SameSiteMode.Strict,
                Expires = DateTime.Now.AddMinutes(15),
                Secure = true

            };
            if (_httpContextAccessor.HttpContext != null)
                _httpContextAccessor.HttpContext.Response.Cookies.Append("refreshToken", token, cookieOptions);

            Response.Cookies.Append("X-Access-Token", token, new CookieOptions()
                { HttpOnly = false, SameSite = SameSiteMode.Strict });
            Response.Cookies.Append("X-Username", "jhonatan", new CookieOptions()
                { HttpOnly = true, SameSite = SameSiteMode.Strict });
            Response.Cookies.Append("X-Refresh-Token", token, new CookieOptions()
                { HttpOnly = true, SameSite = SameSiteMode.Strict });

        }
        #endregion
    }
}
