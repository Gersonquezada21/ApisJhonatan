﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using Credimujer.Common;
using Credimujer.Common.Base;
using Credimujer.Common.Exceptions;
using Credimujer.Iam.Api.Admin.Attributes;
using Credimujer.Iam.Application.Interfaces.Administrar;
using Credimujer.Model.Administrar.Usuario;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Credimujer.Iam.Api.Admin.Controller.ServicioInterno
{
    [Route("ServicioSocia")]
    [ApiKey]
    public class SociaController
    {
        private readonly Lazy<IUsuarioApplication> _usuarioApplication;

        public SociaController(ILifetimeScope lifetimeScope, IOptions<AppSetting> appSettings)
        {
            _usuarioApplication = new Lazy<IUsuarioApplication>(() => lifetimeScope.Resolve<IUsuarioApplication>());
        }

        private IUsuarioApplication UsuarioApplication => _usuarioApplication.Value;

        [HttpPost("CrearUsuarioTipoSocia")]
        public async Task<JsonResult> CrearUsuarioTipoSocia([FromBody] RegistrarUsuarioTipoSociaModel model)
        {
            ResponseDTO response;
            try
            {
                response = await UsuarioApplication.CrearUsuarioTipoSocia(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }
    }
}