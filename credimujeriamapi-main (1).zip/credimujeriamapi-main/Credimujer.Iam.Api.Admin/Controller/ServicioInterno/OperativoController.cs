﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using Credimujer.Common;
using Credimujer.Common.Base;
using Credimujer.Common.Exceptions;
using Credimujer.Iam.Api.Admin.Attributes;
using Credimujer.Iam.Application.Interfaces.Administrar;
using Credimujer.Model.ServicioInterno.Operativo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Credimujer.Iam.Api.Admin.Controller.ServicioInterno
{
    [Route("ServicioOperativo")]
    [ApiKey]
    public class OperativoController
    {
        private readonly Lazy<IUsuarioApplication> _usuarioApplication;

        public OperativoController(ILifetimeScope lifetimeScope, IOptions<AppSetting> appSettings)
        {
            _usuarioApplication = new Lazy<IUsuarioApplication>(() => lifetimeScope.Resolve<IUsuarioApplication>());
        }

        private IUsuarioApplication UsuarioApplication => _usuarioApplication.Value;
        [HttpGet("ObtenerDatosUsuario/{usuario}")]
        public async Task<JsonResult> ObtenerDatosUsuario(string usuario)
        {
            ResponseDTO response;
            try
            {
                response = await UsuarioApplication.ObtenerDatosUsuario(usuario);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }
        [HttpPost("ActualizarCelularUsuario")]
        public async Task<JsonResult> ActualizarCelularUsuario([FromBody]ActualizarCelularUsuarioModel model)
        {
            ResponseDTO response;
            try
            {
                response = await UsuarioApplication.ActualizarCelularUsuario(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }
        [HttpPost("ActualizarContraseniaUsuario")]
        public async Task<JsonResult> ActualizarContraseniaUsuario([FromBody] ActualizarPasswordModel model)
        {
            ResponseDTO response;
            try
            {
                response = await UsuarioApplication.ActualizarContraseniaUsuario(model);
            }
            catch (FunctionalException ex)
            {
                response = new ResponseDTO { Status = ex.FuntionalCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (TechnicalException ex)
            {
                response = new ResponseDTO { Status = ex.ErrorCode, Message = ex.Message, Data = ex.Data, TransactionId = ex.TransactionId };
            }
            catch (Exception ex)
            {
                response = new ResponseDTO { Status = Constants.SystemStatusCode.TechnicalError, Message = ex.StackTrace.ToString() };
            }
            return new JsonResult(response);
        }

    }
}
