using Autofac;
using Credimujer.Common;
using Credimujer.Extensions;
//using Credimujer.Extensions;
using Credimujer.Iam.Repository.Implementations.Data;
using Credimujer.Iam.Repository.Implementations.Data.Base;
using Credimujer.Iam.Repository.Interfaces.Data;
using Credimujer.Iam.Service.Implementations.Base;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyModel;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using static Credimujer.Extensions.SwaggerExtension;
//using static Credimujer.Extensions.SwaggerExtension

namespace Credimujer.Iam.Api.Admin
{
    public class Startup
    {
        public IWebHostEnvironment Environment { get; }
        public IConfiguration Configuration { get; }
        public IServiceCollection services { get; private set; }
        //public Startup(IWebHostEnvironment environment, IConfiguration configuration)
        //{
        //    Environment = environment;
        //    Configuration = configuration;
        //}
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddDbContext<DataContext>(options =>
            //    {
            //        options.
            //    UseSqlServer("Data Source=.;Initial Catalog=pruebas;Integrated Security=True");
            //    });
            //var coneccion = Configuration["AppSettings:ConnectionStrings:DefaultConnection"];
            //services.AddDbContext<DataContext>(options =>
            //options.UseSqlServer(coneccion));
            //------------------------------------

            services.AddAppSettingExtesion(Configuration);
            services.AddJWTExtesion(Configuration, AuthenticateScheme.Security);
            //services.AddJWTExtesion(Configuration, "CrediMujerAsociado");
            services.AddSwaggerExtesion("CrediMujer IAM API");

            services.AddControllers()
             .AddNewtonsoftJson(options =>
             options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
            );
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            //var appSettingsSection = Configuration.GetSection("AppSettings");
            //var appSettings = appSettingsSection.Get<AppSetting>();

            //services.AddCacheExtension(new CacheOptions
            //{
            //    Enabled = appSettings.LineaCarreraConfiguration.CacheConfiguration.Enabled,
            //    ConnectionString = appSettings.LineaCarreraConfiguration.CacheConfiguration.DefaultConnection
            //});


            //esto es para consultar un servicio Externo
            services.AddHttpClient<HttpClientService>().ConfigureHttpMessageHandlerBuilder(builder =>
            {
                builder.PrimaryHandler = new HttpClientHandler
                {
                    ServerCertificateCustomValidationCallback = (m, c, ch, e) => true
                };
            });


            services.AddSwaggerGen(cfg =>
            {
                cfg.CustomSchemaIds(type => type.ToString());
                cfg.DocumentFilter<HideOcelotControllersFilter>();
            });


            //services.AddLoggingExtension(new LoggingOptions
            //{
            //    AccountService = Path.GetFullPath("pe-ferreyros-gcp-lms.json", Directory.GetCurrentDirectory()),
            //    LogName = Assembly.GetEntryAssembly().GetName().Name,
            //    ProjectId = appSettings.GoogleResource.Logging.ProjectId
            //});
            this.services = services;

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(x => x
             .AllowAnyOrigin()
             .AllowAnyMethod()
             .AllowAnyHeader()
            );


            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseStaticFiles();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            //app.UseCache();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "V1");
                c.InjectStylesheet("/swagger/header.css");
                c.DocumentTitle = "CrediMujer";
            });
        }
        public void ConfigureContainer(ContainerBuilder builder)
        {
            var assemblies = new List<Assembly>();
            var dependencies = DependencyContext.Default.RuntimeLibraries;
            foreach (var library in dependencies)
            {
                if (library.Name.StartsWith("Credimujer"))
                {
                    var assembly = Assembly.Load(new AssemblyName(library.Name));
                    assemblies.Add(assembly);
                }
            }

            var assembliesArray = assemblies.ToArray();

            builder.RegisterAssemblyTypes(assembliesArray).Where(t => t.Name.EndsWith("Service")).AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterAssemblyTypes(assembliesArray).Where(t => t.Name.EndsWith("Repository")).AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterAssemblyTypes(assembliesArray).Where(t => t.Name.EndsWith("Application")).AsImplementedInterfaces().InstancePerLifetimeScope();
           
            Autofac.IContainer container = null;
            builder.Register(c => container).AsSelf().SingleInstance();

            builder.RegisterGeneric(typeof(BaseRepository<>)).As(typeof(IBaseRepository<>)).InstancePerDependency();
            builder.RegisterType<UnitOfWork>().As<IUnitOfWork>().InstancePerLifetimeScope();
            builder.RegisterType<HttpContextAccessor>().As<IHttpContextAccessor>().SingleInstance();

            //builder.RegisterType<Logger>()
            //    .As<ILoggerApplication>()
            //    .WithParameter(new NamedParameter("projectName", System.Reflection.Assembly.GetEntryAssembly().GetName().Name))
            //    .SingleInstance(); ;

        }
        //public void InitializeDataBase(IApplicationBuilder app)
        //{
        //    using (var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope())
        //    {
        //        try
        //        {
        //            var context = serviceScope.ServiceProvider.GetRequiredService<IUnitOfWork>();
        //            //DBInitilizer.Initialize(context).Wait();
        //        }
        //        catch (Exception ex)
        //        {
        //            //TODO: Implementar LOG
        //        }
        //    }
        //}

    }
}
