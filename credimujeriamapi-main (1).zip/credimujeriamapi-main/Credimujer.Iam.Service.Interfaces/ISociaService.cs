﻿using Credimujer.Dto.Auth.Asociado;
using Credimujer.Model.Service.Socia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credimujer.Iam.Service.Interfaces
{
    public interface ISociaService
    {
        Task<SociaIdYExisteFormularioDto> ObtnerSociaIdPorNroDocumento(UsuarioModel usuario);
        
    }
}
